package com.barclays.algothims.mine.dp;

import java.util.Arrays;

public class Factorial {
	
	static int factorialDpTable[];

	//normal factorial function cannot benefit from DP as there are no overlapping values but in case like
	// we have to calculate series of m! then we DP can help.
	public static void main(String[] args) {
		int n =10;
		factorial(n-1);
		System.out.println(Arrays.toString(factorialDpTable));
	}
	public static int factorial(int n) {
		factorialDpTable = new int[n+1];
		if(n==0) {
			factorialDpTable[0] =1;
			return 1;
		}
		if(n==1){
			factorialDpTable[1] = 1;
			return 1;
		}
		if(factorialDpTable[n]!=0) {
			return factorialDpTable[n];//reusing the value
		}
		return factorialDpTable[n] = n * factorial(n-1);
	}
	
}
