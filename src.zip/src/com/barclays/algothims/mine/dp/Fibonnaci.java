package com.barclays.algothims.mine.dp;

import java.util.Arrays;

public class Fibonnaci {
	
	//dp table
	static int fb[];

	public static void main(String[] args) {
		int n = 20;
		fb = new int[n];
		fibonaciBottomUp(n);
		System.out.println(Arrays.toString(fb));
		//reset array
		fb = new int[n];
		fibonacciTopDown(n-1);//array size n but index is from 0
		System.out.println(Arrays.toString(fb));
		bestFibonacci(n-1);
	}

	static void fibonaciBottomUp(int n) {
		fb[0] = 1;
		fb[1] = 1;
		for (int i = 2; i < n; i++) {
			fb[i] = fb[i-1] + fb[i-2];
		}
	}
	static int fibonacciTopDown(int n) {
		if(n==0) {
			return fb[0] =1;
		}
		if(n==1) {
			return fb[1] =1;
		}
		if(fb[n] != 0) {
			return fb[n]; 
		}
		return fb[n] = fibonacciTopDown(n-1)+fibonacciTopDown(n-2);
	}
	static void bestFibonacci(int n) {
		int a =0,b=1,sum =0;
		System.out.print("["+b+",");
		for (int i = 0; i < n; i++) {
			sum = a+b;
			System.out.print(" "+sum+",");
			a=b;
			b= sum;
		}
		System.out.println("]");
	}
	
}
