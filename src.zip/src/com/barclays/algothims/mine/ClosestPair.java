package com.barclays.algothims.mine;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class ClosestPair {

	public static void main(String[] args) {
		
		int numPoints = (args.length == 0) ? 1000 : Integer.parseInt(args[0]);
		List<Point> points = new ArrayList<Point>();
		Random r = new Random();
		
		for (int i = 0; i < numPoints; i++) {
			points.add(new Point(r.nextDouble(), r.nextDouble()));
		}
		
		System.out.println("Generated " + numPoints + " random points");
		long startTime = System.currentTimeMillis();
		
		Pair bruteForceClosestPair = bruteForce(points);
		
		long elapsedTime = System.currentTimeMillis() - startTime;
		System.out.println("Brute force (" + elapsedTime + " ms): " + bruteForceClosestPair);
		
		startTime = System.currentTimeMillis();
		Pair dqClosestPair = divideAndConquer(points);
		
		elapsedTime = System.currentTimeMillis() - startTime;
		System.out.println("Divide and conquer (" + elapsedTime + " ms): " + dqClosestPair);
		
		if (bruteForceClosestPair.distance != dqClosestPair.distance) {
			System.out.println("MISMATCH");
		}
	}

	private static Pair divideAndConquer(List<Point> points) {
		List<Point> sortedByXPoints = new ArrayList<Point>(points);
		Utils.sortByX(sortedByXPoints);
		List<Point> sortedByYPoints = new ArrayList<Point>(points);
		Utils.sortByY(sortedByYPoints);
		return divideNConquer(sortedByXPoints, sortedByYPoints);
	}
	private static Pair divideNConquer(List<Point> sortedByXPoints,List<Point> sortedByYPoints) {
		int noOfPoints = sortedByXPoints.size();
		if(noOfPoints<=3) {
			return bruteForce(sortedByXPoints);
		}
		//int dividingIndex = noOfPoints >>> 1;
		
		return null;
	}

	private static Pair bruteForce(List<Point> points) {
		
		int noOfPoints = points.size();
		if(noOfPoints<2) {
			return null;
		}
		Pair closestPair = new Pair(points.get(0),points.get(1));
		if(noOfPoints>2) {
			for(int i=0;i<noOfPoints-1;i++) {
				for(int j=i+1;j<noOfPoints;j++) { // i+1 because we already compared ith with all
					if(Utils.getDistance(points.get(i),points.get(j)) < closestPair.distance) {
						closestPair.update(points.get(i), points.get(j), Utils.getDistance(points.get(i),points.get(j)));
					}
				}
			}
		}
		return closestPair;
	}
}
