package com.barclays.algothims.mine;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Utils {
	public static double getDistance(Point p1, Point p2) {
		double xdist = p2.x - p1.x;
		double ydist = p2.y - p1.y;
		return Math.hypot(xdist, ydist);
	}
	public static void sortByX(List<Point> points) {
		Collections.sort(points, new Comparator<Point>() {
			public int compare(Point point1, Point point2) {
				if (point1.x < point2.x)
					return -1;
				if (point1.x > point2.x)
					return 1;
				return 0;
			}
		});
	}

	public static void sortByY(List<Point> points) {
		Collections.sort(points, new Comparator<Point>() {
			public int compare(Point point1, Point point2) {
				if (point1.y < point2.y)
					return -1;
				if (point1.y > point2.y)
					return 1;
				return 0;
			}
		});
	}
}
