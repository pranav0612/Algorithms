package com.barclays.algothims.mine;

import java.util.Arrays;

public class FindMaxSubArray {
	
	static int arr[];
	static int lowerIndex;
	static int higherIndex;
	static int maxSum;
	private static void findMaxSubArray() {
		int maxSumUntilHere  = 0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]>maxSumUntilHere+arr[i]) {
				maxSumUntilHere = arr[i];
				lowerIndex = i;
			}
			else {
				maxSumUntilHere += arr[i];
				higherIndex++;
			}
			maxSum = Math.max(maxSumUntilHere, maxSum);
		}
		
		System.out.println("Sum  : "+maxSum);
		System.out.println(Arrays.toString(Arrays.copyOfRange(arr,lowerIndex,higherIndex)));
	}
	public static void main(String[] args) {
		//arr = new int[]{-2,1,-3,4,-1,2,1,-5,4};// answer [4,-1,2,1] sum is 6
		arr = new int[]{1,2,3,4};// answer [4,-1,2,1] sum is 6
		findMaxSubArray();
	}
}

