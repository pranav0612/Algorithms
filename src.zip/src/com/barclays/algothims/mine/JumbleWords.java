package com.barclays.algothims.mine;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class JumbleWords {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		 List<String> listOfWords = new ArrayList<>();
		 List<String> outputListOfWords = new ArrayList<>();
		 while(scanner.hasNext()) {
			 String input = scanner.next();
			 if(input.equals("quit")) {
				 break;
			 }
			 listOfWords.add(input);
		 }
		 for (String string : listOfWords) {
			String ouputStr = jumble(string);
			outputListOfWords.add(ouputStr);
		}
		scanner.close();
		//System.out.println(outputListOfWords);
	}
    private static String jumble(String s) {
    	List<Character> list = new ArrayList<>();
    	char[] arr = s.toCharArray();
    	for (int i = 0; i < arr.length; i++) {
			list.add(arr[i]);
		}
    	int length = list.size();
    	StringBuilder str = new StringBuilder();
    	for (int i = 0; i<arr.length; i++) {
			Random r = new Random();
			int index = r.nextInt(length);
			str.append(list.get(index));
			list.remove(index);
			length--;
		}
    	System.out.println(str.toString());
    	return str.toString();
    }
}
