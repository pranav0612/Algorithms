/*Given a set of coins and amount, Write an algorithm to find out how many ways we can make the 
 * change of the amount using the coins given.
 * Example :- 
 * Amount = 5
 * Coins[] = {1,2,3}
 * Ways to make change = 5
 * {1,1,1,1,1} 	{1,1,1,2} 	 {1,2,2}  	{1,1,3}  	  {2,3} */

package com.barclays.algothims.knapsackandcoin;

import java.util.Arrays;

public class CoinChange {

	static int coins[] = {1,2,3};
	static int sum = 5;
	static int dpTable [][] = new int [coins.length+1][sum+1];

	public static void main(String[] args) {

		// Solution by recursion
		System.out.println(getNoOfWays(coins, sum, coins.length-1));

		// Solution by DP
		System.out.println(getNoOfWaysByDP(coins, sum));
	}

	private static int getNoOfWays(int coins[],int sum,int currentCoinIndex) {
		// we have no money, exactly one way to solve the problem - by choosing no coin change
		if(sum == 0){
			return 1;
		}
		// negative money so can't have any solution
		if(sum<0) {
			return 0;
		}
		// no change available but we have money
		if(currentCoinIndex<0 && sum >=1){
			return 0;
		}
		// two sets, excluding and including once a coin
		return getNoOfWays(Arrays.copyOfRange(coins, 0,coins.length-1),sum, currentCoinIndex-1) 
				+ getNoOfWays(coins, sum-coins[currentCoinIndex], currentCoinIndex);
	}

	// make a DP table.Calclate no of ways step by step by adding coin one by one
	private static int getNoOfWaysByDP(int coins[],int sum) {

		// index i is coin and index j is sum
		for(int i=0;i<=coins.length;i++) {
			for(int j=0;j<=sum;j++) {
				// for coin 0 no of ways will be zero except for sum = 0 
				if(i==0)  {
					dpTable[i][j] = 0;
				}
				// for sum = 0, only 1 no of way is there by choosing no coin change
				else if(j==0) {
					dpTable[i][j] = 1;
				}
				//if coin value equals or less than sum, then total no of ways = sum of no of ways of
				// previous coin i.e. dpTable[i-1][j]) and no of ways for sum subtracted by coin value 
				// for same coin i.e. dpTable[i][j-coins[i-1]]
				else if(coins[i-1] <= j) {
					dpTable[i][j] = dpTable[i][j-coins[i-1]] + dpTable[i-1][j];

				}
				// if current coin is greater than sum, then copy the value just above i.e. no of ways 
				// will be equal to no of ways for previous coin 
				else if(coins[i-1]>j){
					dpTable[i][j] = dpTable[i-1][j]; 
				}
			}
		}
		// return the last index of dp table
		return dpTable[coins.length][sum];
	}

}
