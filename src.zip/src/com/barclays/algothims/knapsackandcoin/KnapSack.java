package com.barclays.algothims.knapsackandcoin;

public class KnapSack {

	public static void main(String args[]) {
		int prices[] = {6, 4, 5, 3, 9, 7};//{10,20,30,40};
		int weights[] = {4, 2, 3, 1, 6, 4};//{20,40,60,80};
		int knapsackCapacity = 10; 
		//track of the values that need to be selected
		boolean keep[][] = itemsToBeSelected(prices,weights,knapsackCapacity);
		printSelectedItems(prices, weights, knapsackCapacity, keep);
	}
	
	/**
	 * Create the greedy DPTable for the items that can be selected
	 * 
	 * @param prices
	 * @param weights
	 * @param knapsackCapacity
	 * @return 
	 */
	private static boolean[][] itemsToBeSelected(int prices[], int weights[], int knapsackCapacity)
	{
		int dpTable[][] = new int[weights.length+1][knapsackCapacity+1];
		boolean keep[][] = new boolean[weights.length+1][knapsackCapacity+1];
		
		
		for(int i=1;i<=weights.length; i++)
		{
			for(int w=1; w<=knapsackCapacity; w++)
			{
				/* if the selected item's weight is greater than current knapsack capacity then no need to select it
				 so will maintain the previous value in the current index 
				 */				
				if(weights[i-1] > w)
				{
					dpTable[i][w] = dpTable[i-1][w]; 
				}
				
				else
				{
					//currentValue = price of this item + price of (current sack capacity � weight of this item)
					int currentValue = prices[i-1] + dpTable[i-1][w-weights[i-1]];
					int oldValue = dpTable[i-1][w];
					
					/*if currentvalue is larger then will store it in the dpTable, else store the oldValue  
					  and will mark its keep index to true.
					 */					
					if(currentValue > oldValue)
					{
						dpTable[i][w] = currentValue;
						keep[i-1][w] = true;
					}
					else
					{
						dpTable[i][w] = oldValue;
					}
				}
			}
		}
		
		return keep;
		
	}
	
	
	/**
	 * Print the selected items, by iterating on keep from back, if finds keep = true on that index then will select that item and 
	 * subtract it from knapsack to select the next optimal weight and to maintain the constraint that total selected weight should not be greater that knapsack capacity. 
	 * @param prices
	 * @param weights
	 * @param knapsackCapacity
	 * @param keep
	 */
	public static void printSelectedItems(int prices[], int weights[], int knapsackCapacity, boolean keep[][])
	{
		int k = knapsackCapacity;
		
		for(int i=prices.length-1; i>=0; i--)
		{
			if(keep[i][k])
			{
				System.out.println(weights[i]+" "+prices[i]);
				
				k= k - weights[i];
			}
		}
	}
}
