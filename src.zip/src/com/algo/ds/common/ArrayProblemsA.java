package com.algo.ds.common;

public class ArrayProblemsA {

	public static void main(String[] args) {
		System.out.println("The first equilibrium index is: "+findEquilibriumIndexOfArray(new int[]{-7, 1, 5, 2, -4, 3, 0}));
	}
	//for equilibrium index sum of elements at lower indexes is equal to the sum of elements at higher indexes
	private static int findEquilibriumIndexOfArray(int[] a){
		//first calculate the sum
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
		}
		int leftSum = 0;
		//now iterate over to find the index if it exists
		for (int i = 0; i < a.length; i++) {
			sum = sum-a[i];
			if(sum == leftSum){
				return i;
			}
			leftSum += a[i];
		}
		//if no equilibrium index found
		return -1;
	}
}
