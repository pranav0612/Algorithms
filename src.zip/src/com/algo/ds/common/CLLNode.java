package com.algo.ds.common;

public class CLLNode {

	private int data;
	private CLLNode next;
	
	public CLLNode(int data) {
		this.data = data;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public CLLNode getNext() {
		return next;
	}
	public void setNext(CLLNode next) {
		this.next = next;
	}
	@Override
	public String toString() {
        return toString(this);
	}
	public String toString(CLLNode head) {
		String result = "CLLNode :["+data+"] ";
		if(next != null && !(next == head)){
            result += next.toString(head);
        }
		return result;
	}
}
