package com.algo.ds.common;

public class DLLNode {
	private DLLNode next;
	private DLLNode previous;
	private int data;

	public DLLNode(int data) {
		this.data = data;
	}
	
	public DLLNode getNext() {
		return next;
	}

	public void setNext(DLLNode next) {
		this.next = next;
	}

	public DLLNode getPrevious() {
		return previous;
	}

	public void setPrevious(DLLNode previous) {
		this.previous = previous;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	@Override
	public String toString() {
		String result = "DLLNode :["+data+"] ";
        if(next != null){
            result += next.toString();
        }
        return result;
	}
}
