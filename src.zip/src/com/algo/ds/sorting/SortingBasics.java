package com.algo.ds.sorting;

import java.util.Arrays;

public class SortingBasics {
	public static void main(String[] args) {
		int arrayToBeSorted[] = {1,4,2,11,6};
		System.out.println(Arrays.toString(bubbleSort(arrayToBeSorted)));
		arrayToBeSorted = new int []{1,4,2,11,6};
		System.out.println(Arrays.toString(selectionSort(arrayToBeSorted)));
		arrayToBeSorted = new int []{8,4,2,11,6};
		System.out.println(Arrays.toString(insertionSort(arrayToBeSorted)));
	}
	//This is O(n^2) worst and average case, but O(n) in best case using a flag
	public static int[] bubbleSort(int[] arrayToBeSorted){
		boolean swapInlastPass = true;
		int temp;
		for (int i = arrayToBeSorted.length-1; i >= 0 && swapInlastPass; i--) {
			swapInlastPass = false;
			for (int j = 0; j <= i-1; j++) {
				if(arrayToBeSorted[j]>arrayToBeSorted[j+1]){
					//swap
					temp = arrayToBeSorted[j];
					arrayToBeSorted[j] = arrayToBeSorted[j+1];
					arrayToBeSorted[j+1] = temp;
					swapInlastPass = true;
				}
			}
		}
		return arrayToBeSorted;
	}
	public static int[] selectionSort(int[] arrayToBeSorted){
		int temp,min;
		for (int i = 0; i < arrayToBeSorted.length; i++) {
			min = i;//current element is set as min
			for (int j = i+1; j < arrayToBeSorted.length; j++) {
				if(arrayToBeSorted[j]<arrayToBeSorted[min]){
					min = j;
				}
			}
			//swap ith and min elements
			temp = arrayToBeSorted[i];
			arrayToBeSorted[i] = arrayToBeSorted[min];
			arrayToBeSorted[min] = temp;
		}
		return arrayToBeSorted;
	}
	public static int[] insertionSort(int[] arrayToBeSorted){
		int current,j;
		for (int i = 1; i < arrayToBeSorted.length; i++) {
			current = arrayToBeSorted[i];
			j = i;
			//keep on shifting elements until a smaller element is found
			while (j>=1 && current<arrayToBeSorted[j-1]) {
				arrayToBeSorted[j] = arrayToBeSorted[j-1];
				j--;
			}
			//now insert the current element
			arrayToBeSorted[j] = current;
		}
		return arrayToBeSorted;
	}
}
