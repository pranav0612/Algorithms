package com.algo.ds.sorting;
import java.util.Arrays;
import java.util.Random;

public class QuickSort {
    private static Random random = new Random();

    private static int[] partition3(int[] a, int l, int r) {
      //partition the array in 3 parts 1. less than pivot 2. equal to pivot and 3. greater than pivot
      int m1 = l;   
      int m2 = r; 
      int x = a[l];
      int i = l;
      while( i <= r) {
      	//iterate and shift all values which are less than chosen pivot to the left
          if (a[i] < x) {
              int t = a[i];
              a[i] = a[m1];
              a[m1] = t;
              m1++;
              i++;
          }
          else if(a[i]> x) {
        	  int t = a[i];
              a[i] = a[m2];
              a[m2] = t;
              m2--;
          }
          else{
        	  i++;
          }
          
      }
      int[] m = {m1, m2};
      return m;
    }

    //partition arrays
    private static int partition2(int[] a, int l, int r) {
        int x = a[l];
        int j = l;
        for (int i = l + 1; i <= r; i++) {
        	//iterate and shift all values which are less than chosen pivot to the left
            if (a[i] <= x) {
                j++;
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
        //at last interchange the chosen pivot to its correct index. Now one element is at its rightful position 
        int t = a[l];
        a[l] = a[j];
        a[j] = t;
        return j;
    }

    private static void randomizedQuickSort(int[] a, int l, int r) {
        if (l >= r) {
            return;
        }
        //choose a random pivot
        int k = random.nextInt(r - l + 1) + l;
        //interchange the element at selected random index with element at l
        int t = a[l];
        a[l] = a[k];
        a[k] = t;
        //using partition3
        int m[] = partition3(a, l, r);
        randomizedQuickSort(a, l, m[0]-1);
        randomizedQuickSort(a, m[1]+1, r);
    }
    private static void randomizedQuickSortWith2Partition(int[] a, int l, int r) {
        if (l >= r) {
            return;
        }
        //choose a random pivot
        int k = random.nextInt(r - l + 1) + l;
        //interchange the element at selected random index with element at l
        int t = a[l];
        a[l] = a[k];
        a[k] = t;
        int m = partition2(a, l, r);
        randomizedQuickSortWith2Partition(a, l, m - 1);
        randomizedQuickSortWith2Partition(a, m + 1, r);
    }

    public static void main(String[] args) {
   
        int[] a = {2,4,5,6,5,3,2,90,34,5};
        int [] copy = Arrays.copyOf(a, a.length);
        randomizedQuickSort(a, 0, a.length - 1);
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
        randomizedQuickSortWith2Partition(copy, 0, a.length - 1);
        for (int i = 0; i < a.length; i++) {
            System.out.print(copy[i] + " ");
        }
    }
}

