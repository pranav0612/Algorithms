package com.algo.ds.sorting;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.algo.ds.pqandheaps.HeapBasics;
import com.algo.ds.pqandheaps.MinHeap;

public class SortingProblems {

	public static void main(String[] args) {
		int arr[] = {1,2,2,3,4,5};
		System.out.println("Duplicates present : "+checkDuplicatesInArray(arr));
		System.out.println("Winner is : "+checkWhoWinsInElection(new int[]{1,2,3,2,2,3,3,4,4,4,4,1,1,1}));
		System.out.println("Sum = 10 is possible with elements of arrays : "+checkElementsConsitutingSum(new int[]{1,2,3,6,7},new int[]{1,3,4,1,7},10));
		System.out.println("Sorted array : "+Arrays.toString(sortNearlySortedArray(new int[]{2, 6, 3, 12, 56, 8},3)));
		// Nuts and bolts are represented as array of characters
        char nuts[] = {'@', '#', '$', '%', '^', '&'};
        char bolts[] = {'$', '%', '&', '^', '@', '#'};
        matchNutsAndBolts(nuts, bolts, 0, nuts.length-1);
		System.out.println("The matched nuts and bolts are : "+Arrays.toString(nuts)+Arrays.toString(bolts));
		nuts = new char[]{'@', '#', '$', '%', '^', '&'};
		bolts = new char[]{'$', '%', '&', '^', '@', '#'};
		matchNutsAndBoltsWithMap(nuts, bolts);
		System.out.println("The matched nuts and bolts using hashmap are : "+Arrays.toString(nuts)+Arrays.toString(bolts));
		//for sorting k sorted lists and array refer HeapProblems class
	}
	
	//one method is check each element against each other element, if there is a match then return true : O(n^2)
	//second : Heap sort and check adjacent elements - O(nlogn) with space complexity is 1
	private static boolean checkDuplicatesInArray(int [] arr){
		HeapBasics.heapSort(arr);

		//now check adjacent elements
		for (int i = 0; i < arr.length-1; i++) {
			if(arr[i]==arr[i+1]){
				return true;
			}
		}
		return false;
	}
	//input array has candidate Id's as elements and they will be repeated as obvious.
	//Do a heap sort and maintain variables to get the max repeating element. Same as finding the max repeating number
	//For further improvement use counting sort. 
	//using hash table to do in O(n) and space O(n)
	//Using binary tree(maintain an extra field count) and doing inorder traversal , O(n), space O(n)
	private static int checkWhoWinsInElection(int[] votes){
		HeapBasics.heapSort(votes);
		int currentCandidate = votes[0];
		int currentVoteCount = 0;
		int maxCandidate = votes[0],maxVoteCount = 0;
		for (int i = 0; i < votes.length-1; i++) {
			if(votes[i] == currentCandidate){
				currentVoteCount ++;
			}
			//reset the current candidate
			else{
				currentCandidate = votes[i];
				currentVoteCount = 1;
			}
			if(currentVoteCount > maxVoteCount) {
				maxVoteCount = currentVoteCount;
				maxCandidate = currentCandidate;
			}
		}
		//now check adjacent elements
		return maxCandidate;
	}
	// sort the first array, for each element of b, subtract corresponding element and find the difference using binary Search
	private static boolean checkElementsConsitutingSum(int a[],int b[],int sum){
		//sort a - O(nlogn)
		Arrays.sort(a);
		for (int i = 0; i < b.length; i++) {
			int differ = sum - a[i];
			int result = Arrays.binarySearch(a,differ);
			if(result > 0){
				return true;
			}
		}
		return false;
	}

	//here k is at most distance of inaccuracy - O(nlogk)
	private static int[] sortNearlySortedArray(int a[],int k){
		//create a min heap of size k+1
		MinHeap heap = new MinHeap(Arrays.copyOfRange(a, 0, k+1));

		//result array
		int resultArr[] = new int[a.length];
		int count = 0; 

		for (int i = k+1; i < a.length; i++) {
			resultArr[count] = heap.deleteMin();
			count++;
			heap.insert(a[i]);
		}
		while (!heap.isEmpty()) {
			resultArr[count] = heap.deleteMin();
			count++;
		}
		return resultArr;
	}
	//nuts and bolts problem
	private static void matchNutsAndBolts(char[] nuts,char[] bolts,int low,int high){
		if(low<high){
			// Choose last character of bolts array for nuts partition.
            int pivot = partition(nuts, bolts[high],low, high);
 
            // Now using the partition of nuts choose that for bolts partition.
            partition(bolts,nuts[pivot],low, high);
 
            // Recur for [low...pivot-1] & [pivot+1...high] for nuts and bolts array.
            matchNutsAndBolts(nuts, bolts, low, pivot-1);
            matchNutsAndBolts(nuts, bolts, pivot+1, high);
		}
	}
	//standard partition method
	private static int partition(char a[],char pivot,int low,int high){
		char temp;
		int i = low ;
		//shift all elements to left which are less than pivot
		for (int j = low; j < high; j++) {
			if(a[j]<pivot){
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				i++;
			}
			//if equal throw at last - we wont have more than one number equal to pivot so throwing at last can work
			else if(a[j]==pivot){
				temp = a[j];
				a[j] = a[high];
				a[high] = temp;
				j--;
			}
		}
		//put the pivot at it correct position
		temp = a[i];
		a[i] = a[high];
		a[high] = temp;

		//Return the partition index of an array based on the pivot element of other array.
		return i;
	}
	private static void matchNutsAndBoltsWithMap(char[] nuts,char[] bolts){
		Map<Character,Integer> map = new HashMap<>();
		int index = 0;
		for (char c : nuts) {
			map.put(c,index);
			index++;
		}
		for (int i= 0;i<bolts.length;i++) {
			index = map.get(bolts[i]);
			//swap the corresponding index in nuts
			nuts[i] = bolts[i];
		}
	}
}
