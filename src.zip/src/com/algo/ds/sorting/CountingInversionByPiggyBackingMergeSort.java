package com.algo.ds.sorting;

public class CountingInversionByPiggyBackingMergeSort {
    
    private static int[] array;
    private static int[] tempMergArr;
    private static int length;
    private static int totalInversions;
 
    public static void main(String a[]){
         
        int[] inputArr = {1,3,5,2,4,6};
        countInversionsAndSort(inputArr);
    }
     
    public static void countInversionsAndSort(int inputArr[]) {
        array = inputArr;
        length = inputArr.length;
        tempMergArr = new int[length];
        doMergeSortAndCount(0, length - 1);
        System.out.println("totalInversions : "+totalInversions);
    }
 
    private static void doMergeSortAndCount(int lowerIndex, int higherIndex) {
         
        if (lowerIndex < higherIndex) {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
            // Below step sorts the left side of the array
            doMergeSortAndCount(lowerIndex, middle);
            // Below step sorts the right side of the array
            doMergeSortAndCount(middle + 1, higherIndex);
            // Now merge both sides
            mergePartsAndCount(lowerIndex, middle, higherIndex);
        }
    }
 
    private static void mergePartsAndCount(int lowerIndex, int middle, int higherIndex) {
 
        for (int i = lowerIndex; i <= higherIndex; i++) {
            tempMergArr[i] = array[i];
        }
        int i = lowerIndex;
        int j = middle + 1;
        int k = lowerIndex;
        while (i <= middle && j <= higherIndex) {
            if (tempMergArr[i] <= tempMergArr[j]) {
                array[k] = tempMergArr[i];
                i++;
            }
            //this is case for finding inversions
            else {
                array[k] = tempMergArr[j];
                totalInversions = totalInversions+ (middle-i+1);
                j++;
            }
            k++;
        }
        //these are remaining unprocessed elements
        while (i <= middle) {
            array[k] = tempMergArr[i];
            k++;
            i++;
        }
 
    }
}