package com.algo.ds.searching;

import java.util.Arrays;

public class SearchingIsGood {

	public static void main(String[] args) {
		System.out.println("The first occurrence of 3 in array is :"+getFirstOccurrenceIndexInSortedArray(new int []{1,2,2,3,3,3,4,5},3));
		System.out.println("The last occurrence of 3 in array is :"+getLastOccurrenceIndexInSortedArray(new int []{1,2,2,3,3,3,4,5},3));
		System.out.println("The major element is : "+getMajorityElement(new int[]{3,1,3,2,3,4,3}));
		System.out.println("After separating odds and even : "+Arrays.toString(separateEvenAndOdd(new int []{1,2,4,3,5,7,8,9})));
		System.out.println("Sorting 0,1,2s in array : "+Arrays.toString(sortRGB(new int[]{1,1,0,1,2,2,2,0,0,1,1})));
		System.out.println("No of traling zeroes : "+getNoOfTrailingZeroesInFactorial(100));
		System.out.println("Getting max diff : "+getMaxIndexDiff(new int []{34,8,10,3,2,80,30,33,1}));
	}

	//first occurrence of element in sorted array with duplicates
	//We will accept only that element position when it is the first one, so we put extra condition. 
	private static int getFirstOccurrenceIndexInSortedArray(int a[],int elementToBeFound){
		int low=0,high= a.length-1,mid;
		while (low<high) {
			mid = low+ (high-low)/2;
			//extra added condition to find the first occurrence.Either we are out elements or it's the first one
			if((a[mid]==elementToBeFound && mid ==low) || (a[mid] == elementToBeFound && a[mid] > a[mid-1])) {
				return mid;
			}
			else if(a[mid]<elementToBeFound){
				low = mid+1;
			}
			//give preference to left half in case of equal but not first occurrence
			else if(a[mid]>=elementToBeFound){
				high =mid-1;
			}
		}
		return -1;
	}
	//last occurrence of element in sorted array with duplicates
	//We will accept only that element position when it is the last one, so we put extra condition. 
	private static int getLastOccurrenceIndexInSortedArray(int a[],int elementToBeFound){
		int low=0,high= a.length-1,mid;
		while (low<high) {
			mid = low+ (high-low)/2;
			//extra added condition to find the last occurrence.Either we are out elements or it's the last one
			if((a[mid]==elementToBeFound && mid ==high) || (a[mid] == elementToBeFound && a[mid] < a[mid+1])) {
				return mid;
			}
			//give preference to right half in case of equal but not first occurrence
			else if(a[mid]<=elementToBeFound){
				low = mid+1;
			}

			else if(a[mid]>elementToBeFound){
				high =mid-1;
			}
		}
		return -1;
	}
	//find the occurrences of an element in sorted array
	//brute force = O(n)
	//Binary search first and then move left and right of the index - O(logn +K)
	//Use above 2 functions and subtract their results

	//Majority element = an element occurring more than n/2 times
	//majority element appears at least n/2+1 times, so the algo works
	private static int getMajorityElement(int a[]){
		//since there can be only one majority element we can do it in one scan
		int element=-1,count=0;
		for (int i = 0; i < a.length; i++) {
			if(count==0){
				element = a[i];
			}
			if(a[i] == element){
				count++;
			}
			else{
				count--;
			}
		}
		return element;
	}
	//Move all even to left and all odds to right -- dutch flag approach
	//2 pointer approach, keep incrementing left index until we see an odd number. Keep decrementing right index 
	//until we see an even number.do swaps when both conditions are false
	private static int[] separateEvenAndOdd(int a[]){
		for (int i = 0,j=a.length-1;i<j;) {
			//left is even so increment the left index
			while (a[i]%2==0 && i<j) {
				i++;
			}
			//right is odd so decrement the right index
			while (a[j]%2!=0 && i<j) {
				j--;
			}
			if(i<j){
				//swap
				int temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				i++;
				j--;
			}
		}
		return a;
	}
	//sort array of 0,1,2 - RGB
	//3 variables method.. Keep on swapping to left when 0 occurs and to right when 2 occurs , and just increment the mid if 1 occurs
	private static int[] sortRGB(int a[]){
		int low=0,mid=0,high=a.length-1,temp;
		while (mid<=high) {
			switch (a[mid]) {
				case 0: {
					//swap with low
					temp = a[low];
					a[low] = a[mid];
					a[mid] = temp;
					low++;
					break;
				}
				case 1:{
					mid++;
					break;
				}
				case 2:{
					//swap with high
					temp = a[high];
					a[high] = a[mid];
					a[mid] = temp;
					high--;
					break;
				}
			}
		}
		return a;
	}
	/*
	 * The idea is to consider prime factors of a factorial n. A trailing zero is always produced by prime factors 2 and 5. 
	 * If we can count the number of 5s and 2s, our task is done.We can easily observe that the number of 2s in prime factors 
	 * is always more than or equal to the number of 5s. So if we count 5s in prime factors, we are done.A simple way is to calculate floor(n/5).
	 * Trailing 0s in n! = Count of 5s in prime factors of n!
                  = floor(n/5) + floor(n/25) + floor(n/125) + ....
	 */
	private static int getNoOfTrailingZeroesInFactorial(int n){
		int count = 0;
		// Keep dividing n by powers of 5 and update count
		for (int i = 5; n/i>0; i*=5) {
			count+=n/i;
		}
		return count;
	}
	//Problem : find max(j-i), where A[j]>A[i] and i<j
	//Brute force = O(n^2)
	//we need to get 2 optimum index. For A[i] we don't need to consider i for left index if there is an element
	//on left side which is smaller than A[i]. Similarly we don't need to consider j for right index if there is an 
	//element on right which is greater than A[j]. So we build 2 arrays for leftsMins and RightMaxs. LeftMins holds and repeats lowest
	//useful elements eligible for A[i]. Similarly RightMaxs holds/repeats the greater elements which are eligible for A[j]
	//LeftMins is created traversing from left to right and vice- versa for rightMaxs. So elements in leftMins and rightMax will be in 
	//decreasing order. So now we compare elements and find max(j-i)
	private static int getMaxIndexDiff(int a[]){
		int i=0,j=0,maxDiff=0;
		int leftMins[] = new int[a.length];
		//the first element in left min to start with
		leftMins[0] = a[0];
		//traverse from left to right. Repeat elements which are useful., so we have used Math.min
		for (int k = 1; k < a.length; k++) {
			leftMins[k] = Math.min(a[k],leftMins[k-1]);
		}
		//traverse from right to left. Repeat elements which are useful., so we have used Math.max
		int rightMaxs[] = new int[a.length];
		rightMaxs[0] = a[a.length-1];
		for (int k = a.length-2; k >= 0; k--) {
			rightMaxs[k] = Math.max(a[k],rightMaxs[k+1]);
		}
		//compare element by element in both arrays.Update maxDiff if our condition is met else increment pointers
		//i=0,j=0 initially
		while (i<a.length && j<a.length) {
			//the condition is met so update the maxDiff and also go ahead to search for better combination of i,j by doing j++
			if(leftMins[i]<rightMaxs[j]){
				maxDiff = Math.max(maxDiff,j-i);
				j++;
			}
			// we should move ahead with i as all left elements of A[i] are bigger than A[i]
			else{
				i++;
			}
		}
		return maxDiff;
	}
}
