package com.algo.ds.searching;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SearchingProblems {

	public static void main(String[] args) {
		System.out.println("Duplicate exists in array : "+checkDuplicatesInplaceForRestrictedInput(new int[]{1,2,5,2,0,1}));
		System.out.println("max repeating element is : "+getMaximumRepeatingElementForRestrictedInput(new int[]{1,2,5,4,0,1,3,1}));
		System.out.println("First repeating no is : "+getFirstRepeatingNumber(new int [] {6,1,5,1,2,2,4,4,3}));
		System.out.println("Getting the missing no : "+getMissingNumber(new int[]{1,2,4,5,6},6));
		System.out.println("Getting the no occurring odd no time : "+getNumberOcurringOddNoOfTimes(new int []{1,2,1,2,3,4,4}));
		System.out.println("Getting the 2 repeating no : "+get2RepeatingNumbersByCountArray(new int [] {1,2,5,3,5,4,2},5));
	}
	//hash table will also solve the problem in O(n)
	private static boolean checkDuplicatesInplaceForRestrictedInput(int a[]){
		//if we assume all inputs are in range 0 to n-1 then we can traverse over array and make negative
		//of the each element using element as index. If an element is already negative then it is repeated. 
		//Input array should not be read-only
		List<Integer> duplicates = new ArrayList<>();
		for (int i = 0; i < a.length; i++) {
			if(a[Math.abs(a[i])]<0){
				duplicates.add(Math.abs(a[i]));
			}
			else {
				a[Math.abs(a[i])] = -a[Math.abs(a[i])];
			}
		}
		if(!duplicates.isEmpty()){
			System.out.println("Duplicates are : "+duplicates);
			return true;
		}
		return false;
	}
	//assume that the input ranges from 0 to n-1
	//2 scans - first scan add n to each element,Second scan find the largest no and get the quotient by n and return it's index
	private static int getMaximumRepeatingElementForRestrictedInput(int a[]) {
		int max = 0;
		int maxIndex = 0;
		//adding n to each element
		for (int i = 0; i < a.length; i++) {
			a[a[i] % a.length] = a[a[i] % a.length] + a.length;
		}
		for (int i = 0; i < a.length; i++) {
			if(a[i]>max){
				max = a[i];
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	//we can use brute force -> O(n^2), Sorting the input array won't solve the problem
	//we can use hashing technique              
	private static int getFirstRepeatingNumber(int a[]){
		Map<Integer,Integer> map = new HashMap<Integer, Integer>();
		//make keys as values and array positions as map value,
		for (int i = 0; i < a.length; i++) {
			if(!map.isEmpty()) {
				Integer position = map.get(a[i]);
				//we don't have earlier, so put it as positive
				if(position==null) {
					map.put(a[i],i+1);
				}
				else {
					//check that if it's positive then make it negative to mark that it is repeated
					if(position>0){
						map.put(a[i],-position);
					}
				}
			}
			else {
				//store the position not index as positive
				map.put(a[i],i+1);
			}
		}
		//see the largest index in the map
		Set<Integer> keys = map.keySet();
		int maxValue = Integer.MIN_VALUE;
		for (int key : keys) {
			int value = map.get(key);
			//we consider negative elements because they are only repeating
			if(value<0 && value>maxValue) {
				maxValue = value;
			}
		}
		//no repeating element 
		if(maxValue == Integer.MIN_VALUE) {
			return -1;
		}
		return a[Math.abs(maxValue)-1];
	}
	//Brute force O(n^2)
	//Sort and compare adjacent elements-- O(nlogn)
	//Use hashing technique - O(n) - space complexity = O(n)
	//Use summation. sum = n(n+1)/2, missing no = sum - sum of elements of array. --> O(n). Fails when sum of all numbers overflows integer limit.
	//best approach --> XOR all elements of array,XOR all numbers from 1 to n, missing no = XOR both results.
	private static int getMissingNumber(int a[],int totalNoOFElements){
		int arrayElementsXOR = 0; 
		int totalElementsXOR = 0;
		for (int i = 0; i < a.length; i++) {
			arrayElementsXOR ^= a[i];
		}
		for (int i = 1; i <= totalNoOFElements; i++) {
			totalElementsXOR ^= i;
		}
		return arrayElementsXOR ^ totalElementsXOR;
	}
	/*The ^ operator in Java

	^ in Java is the exclusive-or ("xor") operator.^ is not only a bitwise operator. It is also a logical operator. 
	The ^ operator is overloaded. It operates on integral types or boolean types.

	Let's take 5^6 as example:
	(decimal)    (binary)
     	5     =  101
     	6     =  110
	------------------ xor
     	3     =  011
	This the truth table for bitwise (JLS 15.22.1) and logical (JLS 15.22.2) xor:
	The truth table of A XOR B shows that it outputs true whenever the inputs differ:

	XOR truth table
	Input	Output
	A	B
	0	0	0
	0	1	1
	1	0	1
	1	1	0
	0, false
	1, true
	
	More simply, you can also think of xor as "this or that, but not both!".
	*/
	//This happens because a^a = 0, so even no's will cancel out.
	private static int getNumberOcurringOddNoOfTimes(int a[]){
		int result = 0;
		for (int i = 0; i < a.length; i++) {
			result ^= a[i];
		}
		return result;
	}
	//array has n+2 elements and 2 elements are repeating. rest n are unique, grap those 2
	//Brute force =  O(n^2)
	//Sorting = O(nlogn)
	//Hashing technique == O(n), space = O(n) or counting technique same
	private static List<Integer> get2RepeatingNumbersByCountArray(int a[],int n) {
		int count[] = new int[n+1];//max range is n
		List<Integer> result = new ArrayList<>();
		for (int i = 0; i < a.length; i++) {
			count[a[i]]++;
			if(count[a[i]] ==2){
				result.add(a[i]);
			}
		}
		return result;
	}
	/*XOR technique
	Let the repeating numbers be X and Y, if we xor all the elements in the array and all integers from 1 to n, 
	then the result is X xor Y.
	The 1’s in binary representation of X xor Y is corresponding to the different bits between X and Y. 
	Suppose that the kth bit of X xor Y is 1, we can xor all the elements in the array and all integers from 1 to n, 
	whose kth bits are 1. The result will be one of X and Y.
	*/
	@SuppressWarnings("unused")
	private static List<Integer> get2RepeatingNumbersByXOR(int arr[],int n){
		List<Integer> result = new ArrayList<>();

        /* Will hold xor of all elements */
        int xor = arr[0];
         
        /* Will have only single set bit of xor */
        int setBitNo;
         
        int i;
        int x = 0, y = 0;
 
        /* Get the xor of all elements in arr[] and {1, 2 .. n} */
        for (i = 1; i < n; i++)
            xor ^= arr[i];
        for (i = 1; i <= n; i++)
            xor ^= i;
 
        /* Get the rightmost set bit in setBitNo */
        setBitNo = (xor & ~(xor - 1));
 
        /* Now divide elements in two sets by comparing rightmost set
           bit of xor with bit at same position in each element. */
        for (i = 0; i < n; i++) {
            int a = arr[i] & setBitNo;
            if (a != 0)
                x = x ^ arr[i]; /*XOR of first set in arr[] */
            else
                y = y ^ arr[i]; /*XOR of second set in arr[] */
        }
        for (i = 1; i <= n; i++) 
        {
            int a = i & setBitNo;
            if (a != 0)
                x = x ^ i; /*XOR of first set in arr[] and {1, 2, ...n }*/
            else
                y = y ^ i; /*XOR of second set in arr[] and {1, 2, ...n } */
        }
 
        System.out.println("The two reppeated elements are :");
        System.out.println(x + " " + y);
		return result;
	}
}
