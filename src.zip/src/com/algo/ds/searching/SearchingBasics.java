package com.algo.ds.searching;

public class SearchingBasics {

	public static void main(String[] args) {
		System.out.println("The index of 5 in sorted array is "+binarySearch(new int[]{1,3,4,5,8,9},5));
		System.out.println("The index of 5 in sorted array is "+binarySearchRecursive(new int[]{1,3,4,5,8,9},5,0,5));
	}
	public static int binarySearch(int a[],int data){
		int low = 0;
		int high = a.length-1;
	    int mid;
	    while (low<=high) {
	    	mid = low + (high-low)/2;
			if(a[mid] == data){
				return mid;
			}
			else if(a[mid] > data){
				high = mid-1;
			}
			else {
				low= mid+1;
			}
		}
	    return -1;
	}
	public static int binarySearchRecursive(int a[],int data,int low,int high){
		int mid = low + (high-low)/2;
		if(low>high){
			return -1;
		}
		if(a[mid] == data){
			return mid;
		}
		else if(a[mid] > data){
			return binarySearchRecursive(a, data, low, mid-1);
		}
		else {
			return binarySearchRecursive(a, data, mid+1, high);
		}
	}
}
