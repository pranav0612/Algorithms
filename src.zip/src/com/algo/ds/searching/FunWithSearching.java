package com.algo.ds.searching;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FunWithSearching {

	public static void main(String[] args) {
		System.out.println("The numbers constituting 10 is "+getPairOfNumberWhichConstitueSum(new int[]{1,2,3,4,5,6},10));
		System.out.println("The pythagorean triplet in array are : "+getPythagoreanTripletsFromArray(new int[]{1,2,3,4,5,6}));
		System.out.println("The numbers whose sum is closest to zero is : "+getPairOfNosWhoseSumClosestToZero(new int[]{1,2,3,4,5,6,81,97,-7,-9,-90,-87}));
		System.out.println("The numbers constituting 10 are : "+get3NumbersConstitutingSum(new int[]{1,3,4,2,7,8,3,5},10));
		System.out.println("The element at which ordering flips is : "+getElementDividingArray(new int []{-2,-1,0,2,4,5,4,3,2,1}));
		System.out.println("The index of 3 is : "+findInArr(new int[]{15,16,19,20,25,1,3,4,5,7,10,14},3));
		System.out.println("The index of 3 is : "+findInArrInOneScan(new int[]{15,16,19,20,25,1,3,4,5,7,10,14},3));
	}
	//sort the array, now move in array from starting and end using 2 pointers, check sum and move closer until found.
	private static List<Integer> getPairOfNumberWhichConstitueSum(int arr[],int k){
		List<Integer> result = new ArrayList<Integer>();
		Arrays.sort(arr);
		int lowIndex = 0;
		int highIndex = arr.length-1;
		int sum = 0;
		while (lowIndex<highIndex) {
			sum = arr[lowIndex]+arr[highIndex];
			if(sum==k){
				result.add(arr[lowIndex]);
				result.add(arr[highIndex]);
				return result;
			}
			else if(sum<k){
				lowIndex++;
			}
			else{
				highIndex--;
			}
		}
		return result;
	}
	//a[i]^2 + a[j]^2 = a[k]^2
	/*We can solve this in O(n2) time by sorting the array first.
	1) Do square of every element in input array. This step takes O(n) time.
	2) Sort the squared array in increasing order. This step takes O(nLogn) time.
	3) To find a triplet (a, b, c) such that a = b + c, do following.
	Fix �a� as last element of sorted array.
	Now search for pair (b, c) in subarray between first element and �a�. A pair (b, c) with given sum can be found in O(n) time
	If no pair found for current �a�, then move �a� one position back and repeat*/
	private static List<Integer> getPythagoreanTripletsFromArray(int arr[]){
		List<Integer> result = new ArrayList<Integer>();
		//square each element
		for (int i = 0; i < arr.length; i++) {
			arr[i] = arr[i]*arr[i];
		}
		//sort
		Arrays.sort(arr);
		//loop over to find a = b+c
		int a,lowIndex=0,highIndex,j=arr.length-1;
		//b and c should be smaller than c and to satisfy a = b+c, so we decrease j till 2
		while (j>=2) {
			a = arr[j];
			//now we have to find a pair whose sum is a--> same as above problem
			highIndex = j-1;
			lowIndex = 0;
			while (lowIndex<highIndex) {
				int sum = arr[lowIndex]+arr[highIndex];
				if(sum == a){
					result.add((int) Math.sqrt(arr[lowIndex]));
					result.add((int) Math.sqrt(arr[highIndex]));
					return result;
				}
				else if(sum<a){
					lowIndex++;
				}
				else{
					highIndex--;
				}
			}
			j--;
		}
		return result;
	}
	//Sort array, use 2 pointers one in front on at back,maintain 2 variables to track negative sum and positive sum, return the closest one
	private static List<Integer> getPairOfNosWhoseSumClosestToZero(int a[]){
		List<Integer> result = new ArrayList<Integer>();
		//sort
		Arrays.sort(a);
		int lowIndex=0,highIndex = a.length-1,closestNegativeSum=Integer.MIN_VALUE,closestPositiveSum = Integer.MAX_VALUE,
				sum,lowIndexForNegativeSum=0,highIndexForNegativeSum=0,lowIndexForPositiveSum=0,highIndexForPostivesum=0;
		while (lowIndex<highIndex) {
			sum = a[lowIndex] + a[highIndex];
			if(sum==0){
				result.add(a[lowIndex]);
				result.add(a[highIndex]);
				return result;
			}
			else if(sum<0){
				if(sum>closestNegativeSum) {
					closestNegativeSum = sum;
					lowIndexForNegativeSum = lowIndex;
					highIndexForNegativeSum = highIndex;
				}
				lowIndex++;
			}
			else{
				if(sum<closestPositiveSum) {
					closestPositiveSum = sum;
					lowIndexForPositiveSum = lowIndex;
					highIndexForPostivesum = highIndex;
				}
				highIndex--;
			}
		}
		//if we reach here then find out which one is closest
		if(Math.abs(closestNegativeSum)< closestPositiveSum){
			result.add(a[lowIndexForNegativeSum]);
			result.add(a[highIndexForNegativeSum]);
		}
		else {
			result.add(a[lowIndexForPositiveSum]);
			result.add(a[highIndexForPostivesum]);
		}
		return result;
		
	}
	//this is O(n^2)
	private static List<Integer> get3NumbersConstitutingSum(int a[],int sum){
		List<Integer> result = new ArrayList<Integer>();
		//sort
		Arrays.sort(a);
		int lowerIndex,higherIndex,tempSum;
		for (int i = 0; i < a.length; i++) {
			//take 2 variables
			lowerIndex = i+1;
			higherIndex = a.length-1;
			while (lowerIndex<higherIndex) {
				tempSum = a[i]+a[lowerIndex]+a[higherIndex];
				if(tempSum==sum){
					result.add(a[i]);
					result.add(a[lowerIndex]);
					result.add(a[higherIndex]);
					return result;
				}
				else if(tempSum<sum){
					lowerIndex++;
				}
				else{
					higherIndex--;
				}
			}
		}
		return result;
	}
	//Problem statement : A[1] ..A[k] is increasing and A[k+1]...A[n] is decreasing, so find k -- O(logn)
	private static int getElementDividingArray(int a[]){
		int mid,first = 0,last = a.length-1;
		while (first<=last) {
			if(first==last){
				return a[first];
			}
			else if(first == last-1){
				return Math.max(a[first],a[last]);
			}
			//we have 3 elements
			else {
				mid = first + (last-first)/2;
				//check the main condition for ordering flip in array
				if(a[mid]>a[mid-1] && a[mid]>a[mid+1]){
					return a[mid];
				}
				else if(a[mid]>a[mid-1] && a[mid]<a[mid+1]) {
					first = mid+1;
				}
				else if(a[mid]<a[mid-1] && a[mid]>a[mid+1]) {
					last = mid-1;
				}
				else{
					return -1;
				}
			}
		}
		return -1;
	}
	//rotation of array is nothing but moving an element from last to start and pushing others to right.
	//Problem : the array is rotated unknown no of times, find an element in O(logn)
	private static int findInArr(int arr[],int toBeFound){
		//first find the index element which is pivot for rotation --O(logn)
		int pivotElementIndex = getPivotElementIndex(arr);
		if(arr[pivotElementIndex] == toBeFound){
			System.out.println("Element found!");
			return pivotElementIndex;
		}
		//using pivot divide array in 2 sorted subarrays
		if(toBeFound >= arr[0]) {
			if(toBeFound == arr[0]){
				return 0;
			}
			//then search it in first half
			return Arrays.binarySearch(arr,0,pivotElementIndex, toBeFound);
		}
		//search it in second half
		else {
			return Arrays.binarySearch(arr,pivotElementIndex+1,arr.length, toBeFound);
		}
	}
	// the order of array is still increasing after rotation but only before and after pivot element
	private static int getPivotElementIndex(int a[]){
		int mid,first = 0,last = a.length-1;
		while (first<=last) {
			if(first==last){
				return first;
			}
			else if(first == last-1){
				if(a[first] > a[last]){
					return first;
				}
				else{
					return last;
				}
			}
			//we have 3 elements or more
			else {
				mid = first + (last-first)/2;
				//check the main condition for ordering flip in array
				if(a[mid]>a[mid-1] && a[mid]>a[mid+1]){
					return mid;
				}
				else if(a[first]>a[mid]) {
					last = mid;
				}
				else {
					first = mid;
				}
			}
		}
		return -1;
	}
	private static int findInArrInOneScan(int arr[],int toBeFound){
		int start=0,finish=arr.length-1;
		return binarysearchRotated(arr, toBeFound, start, finish);
	}
	private static int binarysearchRotated(int arr[],int toBeFound,int start,int finish){
		if(start>finish) {
			return -1;
		}
		int mid = start+ (finish-start)/2;
		if(toBeFound == arr[mid]){
			return mid;
		}
		//check if the first half is in sorted order 
		else if(arr[start] <= arr[mid]){
			//check the position of data == normal binary search in this sorted half
			if(toBeFound >=arr[start] && toBeFound <arr[mid]){
				return binarysearchRotated(arr, toBeFound, start, mid-1);
			}
			else {//search in other half
				return binarysearchRotated(arr, toBeFound, mid+1, finish);
			}
		}
		else if(arr[mid]<=arr[finish]) {
			if(toBeFound >arr[mid] && toBeFound <= arr[finish]){
				return binarysearchRotated(arr, toBeFound, mid+1,finish);
			}
			else {//search in other half
				return binarysearchRotated(arr, toBeFound, start, mid-1);
			}
		}
		return -1;
	}
}
