package com.algo.ds.dp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DPProblemsB {

	public static void main(String[] args) {
		System.out.println("The length of longest increasing subsequence : "+getLongestIncreasingSubsequence(new int[]{5,6,2,3,4,1,9,9,8,9,5},true));
		System.out.println("The length of longest increasing subsequence : "+getLongestIncreasingSubsequenceEfficient(new int[]{5,6,2,3,4,1,9,9,8,9,5}));
		System.out.println("The length of longest increasing subsequence : "+getAndPrintLongestIncreasingSubsequence(new int[]{5,6,2,3,4,1,9,9,8,9,5}));
		List<Box> boxes = new ArrayList<>();
		boxes.add(new Box(4, 6, 7));
		boxes.add(new Box(1, 2, 3));
		boxes.add(new Box(4, 5, 6));
		boxes.add(new Box(10,12,32));
		System.out.println("The maximum height for Box stacking is : "+getMaximumHeightByStacking(boxes ));
	}
	//Given an array of integers find longest increasing subsequence - need not to be contiguous. Eg. 5,6,2,3,4,1,9,9,8,9,5=> 2,3,4,8,9
	public static int getLongestIncreasingSubsequence(int a[],boolean strict){
		//take an array for memoization
		int maxSequenceCount[] = new int[a.length];

		//now we have to consider all smaller subsequences from 1 to whole array. Subsequences with length=1 will have count 1
		for (int i = 0; i < maxSequenceCount.length; i++) {
			maxSequenceCount[i] = 1;
		}
		//now we consider each subsequence ranging from 0 to n-1
		for (int i = 0; i < a.length; i++) {
			//consider each subsequence from j to i
			for (int j = 0; j < i; j++) {
				//if the element is increasing and including that element is increasing the count then we will update
				if(strict && a[i]>a[j] && maxSequenceCount[i] < maxSequenceCount[j] +1){
					maxSequenceCount[i] = maxSequenceCount[j] +1;
				}
				else if(!strict && a[i]>=a[j] && maxSequenceCount[i] < maxSequenceCount[j] +1){
					maxSequenceCount[i] = maxSequenceCount[j] +1;
				}
			}
		}
		int max = 0;
		for (int i = 0; i < maxSequenceCount.length; i++) {
			if(maxSequenceCount[i]>max){
				max = maxSequenceCount[i];
			}
		}
		return max;
	}
	//solving above in O(nlogn) for strategy refer the doc
	private static int getLongestIncreasingSubsequenceEfficient(int a[]){

		//this table will store tails of each subsequence
		int[] tailTable = new int[a.length];
		int length = 1;

		//put the first element in tailtable
		tailTable[0] = a[0];

		for (int i = 1; i < a.length; i++) {
			if(a[i]<tailTable[0]){
				//new smallest value - so the smallest will be there in the start of the array
				tailTable[0] = a[i];
			}
			else if(a[i]>tailTable[length-1]){
				//this is the biggest of all values so we have to extend the subsequence
				tailTable[length++] = a[i];
			}
			else{
				//we have to find a place for a[i] as it has to be an end candidate of a subsequence. We can find that place
				//using binary search. It has to replace the value in tailtable.Tailtable is always sorted
				tailTable[binarySearch(tailTable,-1, length-1, a[i])] = a[i];
			}
		}
		return length;
	}
	private static int binarySearch(int a[], int l, int r, int key){
		while (r-l>1) {
			int mid = l+(r-l)/2;
			if(a[mid] >= key){
				r = mid;
			}
			else{
				l = mid;
			}
		}
		return r;
	}
	private static int getAndPrintLongestIncreasingSubsequence(int a[]) {
		//Tracking the predecessors/parents of elements of each subsequence.
		int parent[]= new int[a.length];

		//Tracking ends of each increasing subsequence.
		int increasingSub[]= new int[a.length + 1]; 
		int length = 0; //Length of longest subsequence.

		for(int i=0; i<a.length; i++) {
			//Binary search
			int low = 1;
			int high = length;
			while(low <= high) {
				int mid = (int) Math.ceil((low + high)/2);
				if(a[increasingSub[mid]] < a[i]){
					low = mid + 1;
				}
				else{
					high = mid - 1;
				}
			}

			int pos = low;
			//update parent/previous element for LIS
			parent[i] = increasingSub[pos-1];

			//Replace or append
			increasingSub[pos] =  i;

			//Update the length of the longest subsequence.
			if(pos > length){
				length=pos;
			}
		}
		//Generate LIS by traversing parent array
		int result[] = new int[length];
		int k 	= increasingSub[length];
		for(int j=length-1; j>=0; j--){
			result[j] =  a[k];
			k = parent[k];
		}
		System.out.print("The longest subsequence is : ");
		for(int i=0; i<length; i++) {
			System.out.print(result[i]+" ");
		}
		return length;
	}
	//Box stacking Problem : Create a stack of boxes which is as tall as possible, but you can only stack a box on top of another 
	//box if the dimensions of the 2-D base of the lower box are each strictly larger than those of the 2-D base of the higher box. i.e length
	//and width both are smaller than lower box
	private static int getMaximumHeightByStacking(List<Box> boxes){
		//generate all rotations of box height wise
		List<Box> allBoxesRotaions = new ArrayList<>();
		for (Box box : boxes) {
			
			allBoxesRotaions.add(box);
			int height = box.height;
			int length = box.length;
			int width = box.width;
			
			//first rotation
			allBoxesRotaions.add(new Box(length, height, width));
			//second rotation
			allBoxesRotaions.add(new Box(width, length, width));
		}
		//sort the boxes according to base area
		Collections.sort(allBoxesRotaions);
		
		int maxHeights[] = new int[allBoxesRotaions.size()];
		//add heights if there was only one box
		for (int i = 0; i < maxHeights.length; i++) {
			maxHeights[i] = allBoxesRotaions.get(i).height;
		}
		//now same LIS logic but here we have to increase the height when base dimensions of upper box is strictly less than that of upper box
		for (int i = 1; i < maxHeights.length; i++) {
			//i is going top of jth box
			for (int j = 0; j < i; j++) {
				if(maxHeights[i] < maxHeights[j]+allBoxesRotaions.get(i).height && 
						allBoxesRotaions.get(i).length < allBoxesRotaions.get(j).length && allBoxesRotaions.get(i).width < allBoxesRotaions.get(j).width){
					maxHeights[i] = maxHeights[j]+allBoxesRotaions.get(i).height;
				}
			}
		}
		int maxHeight = 0;
		for (int i : maxHeights) {
			if(i>maxHeight){
				maxHeight = i;
			}
		}
		return maxHeight;
	}
	private static class Box implements Comparable<Box>{
		int height;
		int length;
		int width;
		
		public Box(int height,int width,int length) {
			this.height = height;
			this.length = length;
			this.width = width;
		}

		@Override
		public int compareTo(Box o) {
			int thisArea = length * width;
			int objectArea = o.length * o.width;
			return objectArea - thisArea;
		}
	}

}
