package com.algo.ds.dp;

public class DPProblemsD {

	public static void main(String[] args) {
		System.out.println("The optimal binary has cost : "+getOptimalBinaryTreeCost(new int[]{10,12,20}, new int[]{34,8,50}));
		System.out.println("The highest points can be gained in game : "+getMaxValueForWinning(new int[]{8, 15, 3, 7}));
		System.out.println("The highest points can be gained in game second case : "+getMaxValueForWinning(new int[]{20, 30, 2, 2, 2, 10}));
		System.out.println("The length of longest palindromic subsequence : "+getLongestPalindromicSubsequence("GEEKSFORGEEKS"));
		System.out.println("The longest palindromic substring : "+getLongestPalindromicSubstringUsingDP("forgeeksskeegfor"));
		System.out.println("The no of string occurs as a subsequence in given string : "+getNoOfTimesStringAppearsAsSubsequence("GeeksforGeeks","Gks"));
	}
	private static int getOptimalBinaryTreeCost(int [] sortedElements,int frequencyOfSearch[]){
		
		int n = sortedElements.length;
		int optimalCosts[][] = new int[n][n];
		
		//we have consider different segments of array. for e.g consider segments of length =1, so min cost when only one one 
		//element is considered will be equal to their frequencies
		for (int i = 0; i < n; i++) {
			optimalCosts[i][i] = frequencyOfSearch[i];
		}
		
		//now consider segments of length greater than one. i.e. we will 2 elements and make binary tree and save the optimal cost
		//then we will consider 3 element and do the same and so on..
		for (int segmentLength = 2; segmentLength <= n; segmentLength++) {
			
			//now we consider 2 variables i and j such that j-i = segmentLength and i and j will vary across all array i.e. we are
			//considering all segments of length segmentLength which can formed using whole array 
			for (int i = 0; i < n-segmentLength+1; i++) {
				int j = i + segmentLength-1;
				optimalCosts[i][j] = Integer.MAX_VALUE;
				
				//now we have our segment from i to j, so we will iterate within the segment and make each element root one by one
				//then store the minimum one and record the root chosen
				//when keys[r] becomes root of this subtree
				for (int r = i; r <=j; r++) {
					int cost = getSumForRange(i, j, frequencyOfSearch);
					if(r>i){
						cost += optimalCosts[i][r-1];
					}
					if(r<j){
						cost += optimalCosts[r+1][j];
					}
					if(optimalCosts[i][j] > cost){
						optimalCosts[i][j] = cost;
					}
				}
			}
		}
		return optimalCosts[0][n-1];
	}
	private static int getSumForRange(int i,int j,int a[]){
		int sum = 0;
		for (int k = i; k <= j; k++) {
			sum+= a[k];
		}
		return sum;
	}
	private static int getMaxValueForWinning(int coins[]){
		int n = coins.length;
		
		// Create a table to store solutions of subproblems
		int table[][] = new int[n][n];
		
		//base cases
		for (int i = 0; i < table.length; i++) {
			//we have only one coin to choose
			table[i][i] = coins[i];
		}
		//we have 2 coins
		for (int i = 0; i < table.length-1; i++) {
			table[i][i+1] = Math.max(coins[i],coins[i+1]);
		}
		int x,y,z ;
		
		// Fill table using above recursive formula.The table is filled in diagonal fashion
		//lets try every segment
		for (int segmentLength = 2; segmentLength < n; segmentLength++) {
			
			//traverse all over array to consider all possible segments of length segmentLength 
			for (int i = 0,j=segmentLength; j < n; i++,j++) {
				
				// Here x is value of F(i+2, j), y is F(i+1, j-1) and z is F(i, j-2) in above recursive formula
				x = table[i+2][j];
				y = table[i+1][j-1];
				z = table[i][j-2];
				
				table[i][j] = Math.max(coins[i]+ Math.min(x,y), coins[j]+Math.min(y,z));
			}
		}
		return table[0][n-1];
	}
	private static int getLongestPalindromicSubsequence(String input){
		char[] charArr = input.toCharArray();
		
		int n = charArr.length;
		
		//lets create a table for memoization
		int table[][] = new int[n][n];
		
		//base cases
		//1. When we have only characters -> i to i , length = 1
		for (int i = 0; i < table.length; i++) {
			table[i][i] = 1;
		}
		
		//when we have 2 elements and characters are same then count = 2
		for (int i = 0; i < table.length-1; i++) {
			if(charArr[i] == charArr[i+1]){
				table[i][i+1] = 2;
			}
			else{
				table[i][i+1] = 1;
			}
		}
		
		//now we fill the table. We will consider all subsequences of different lengths.
		for (int subsequenceLength = 2; subsequenceLength <= n; subsequenceLength++) {
			for (int i = 0,j = subsequenceLength; j < n; i++,j++) {
				//if first and last characters are same
				if(charArr[i] == charArr[j]){
					table[i][j] = table[i+1][j-1] + 2;
				}
				else {
					table[i][j] = Math.max(table[i][j-1],table[i+1][j]);
				}
			}
		}
		return table[0][n-1];
		
	}
	private static String getLongestPalindromicSubstringUsingDP(String text){
		char[] charArr = text.toCharArray();
		
		//2 variables for tracking the result
		int startIndex = 0, maxLength = 0;
		//build the table for checking if the substring i to j is a palindrome or not.
		boolean[][] table = new boolean[text.length()][text.length()];
		
		//base case. when length=1, it's true when length=1 , i.e from i to i
		for (int i = 0; i < table.length; i++) {
			table[i][i] = true;
		}
		
		//base case when length = 2
		for (int i = 0; i < table.length-1; i++) {
			if(charArr[i] == charArr[i+1]){
				table[i][i+1] = true;
				startIndex = i;
				maxLength = 2;
			}
		}
		//lets populate this table. We will consider segments of each length 
		for (int segmentLength = 2; segmentLength < table.length; segmentLength++) {
			
			//check each segment from i to j
			for (int i = 0,j= segmentLength; j < table.length; i++,j++) {
				
				//if the characters are same then check the segment from i+1 to j-1
				if(charArr[i] == charArr[j]){
					table[i][j] = table[i+1][j-1];
					if(table[i+1][j-1]){
						startIndex = i;
						maxLength = j-i;
					}
				}
			}
		}
		
		return text.substring(startIndex,startIndex+maxLength+1);
	}
	private static int getNoOfTimesStringAppearsAsSubsequence(String text,String subsequence){
		char[] textCharArr = text.toCharArray();
		char[] subSequenceCharArr = subsequence.toCharArray();
		
		int[][] table = new int[subsequence.length()+1][text.length()+1];
		
		//base case 1 : when j = 0, that is we have empty string, so it should be 0
		for (int i = 0; i <= subsequence.length(); i++) {
			table[i][0] = 0; 
		}
		//base case 2 when i = 0, so we have empty string to compare
		for (int j = 0; j <= text.length(); j++) {
			table[0][j] = 1;
		}
		//now fill the table according to formula
		for (int i = 1; i <= subsequence.length(); i++) {
			for (int j = 1; j <= text.length(); j++) {
				if(subSequenceCharArr[i-1] == textCharArr[j-1]) {
					table[i][j] =  table[i][j-1] + table[i-1][j-1]; //considering ith plus not considering ith
				}
				else{
					table[i][j] =  table[i][j-1]; //Ditching the jth character
				}
			}
		}
		return table[subsequence.length()][text.length()];
	}
}
