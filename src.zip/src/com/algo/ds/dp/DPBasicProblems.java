package com.algo.ds.dp;

public class DPBasicProblems {

	public static void main(String[] args) {
		long currentTime  = System.currentTimeMillis();
		System.out.print("Fibonnaci brute force for n = 42 : "+getFibonacciBruteForce(42));
		System.out.println(" Time taken = "+(System.currentTimeMillis() - currentTime)+"ms");
		
		currentTime  = System.currentTimeMillis();
		System.out.print("Fibonnaci top down for n = 42 : "+getFibonacciTopDown(42));
		System.out.println(" Time taken = "+(System.currentTimeMillis() - currentTime)+"ms");
		
		currentTime  = System.currentTimeMillis();
		System.out.print("Fibonnaci bottom up for n = 42 : "+getFibonacciBottomUp(42));
		System.out.println(" Time taken = "+(System.currentTimeMillis() - currentTime)+"ms");
		
		currentTime  = System.currentTimeMillis();
		System.out.print("Fibonnaci best  for n = 45 : "+getFibonacciBest(45));
		System.out.println(" Time taken = "+(System.currentTimeMillis() - currentTime)+"ms");
		
		currentTime  = System.currentTimeMillis();
		System.out.print("Fibonnaci logn time  for n = 45 : "+getFibonacciNlogN(45));
		System.out.println(" Time taken = "+(System.currentTimeMillis() - currentTime)+"ms");
		
		System.out.println("The factorial of 11 : "+getFactorial(11));
		
		System.out.println("The lcs of abcdaf and acbcf is "+getLCS("abcdaf","acbcf"));
	}
	private static int getFibonacciBruteForce(int n){
		if(n==0){
			return 0;
		}
		if(n==1){
			return 1;
		}
		return getFibonacciBruteForce(n-1) + getFibonacciBruteForce(n-2);
	}
	static int fib[] = null;
	private static int getFibonacciTopDown(int n){
		if(n==0){
			return 0;
		}
		if(n==1){
			return 1;
		}
		//first time
		if(fib==null){
			fib = new int[n+1];
		}
		if(fib[n]!=0){
			return fib[n];
		}
		else {
			fib[n-1] = getFibonacciTopDown(n-1);
			fib[n-2] = getFibonacciTopDown(n-2);
			return fib[n-1] + fib[n-2];
		}
	}
	private static int getFibonacciBottomUp(int n){
		fib = new int[n+1];
		fib[0] = 0;
		fib[1] = 1;
		for (int i = 2; i < fib.length; i++) {
			fib[i] = fib[i-1] + fib[i-2];
		}
		return fib[n];
	}
	private static int getFibonacciBest(int n){
		if(n==0){
			return 0;
		}
		if(n==1){
			return 1;
		}
		int previous = 0;
		int previousOfPrevious = 1;
		int sum  = 0;
		for (int i = 1; i <= n; i++) {
			sum = previous + previousOfPrevious;
			previousOfPrevious = previous;
			previous = sum;
		}
		return sum;
	}
	//Factorial - not overlapping so no DP :(
	private static int getFactorial(int n){
		if(n==0){
			return 1;
		}
		return n*getFactorial(n-1);
	}
	//Longest common subsequence
	private static String getLCS(String str1,String str2){
		StringBuilder builder = new StringBuilder();
		char charArr1[] = str1.toCharArray();
		char charArr2[] = str2.toCharArray();
		int n = charArr1.length;
		int m = charArr2.length;
		
		//corner case
		if(n==1 && m==1){
			if(charArr1[0] == charArr2[0]){
				builder.append(charArr1[0]);
			}
		}
		//memoization -- m+1 * n+1 array because the DP calculation requires it
		int[][] lcs = new int[n+1][m+1];
		
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				//if the character match then lcs = 1+ diagonal element
				if(charArr1[i-1] == charArr2[j-1]) {
					lcs[i][j] = 1 + lcs[i-1][j-1];
				}
				else {
					lcs[i][j] = Math.max(lcs[i][j-1],lcs[i-1][j]);
				}
			}
		}
		//now the lcs[n][m] contains the lcs length, now we backtrack to construct our string
		while(m>0 && n>0){
			//grab variables
			int current = lcs[n][m];
			int upper = lcs[n-1][m];
			int left = lcs[n][m-1];
			int diagonal = lcs[n-1][m-1];
			
			//equal characters so grab one
			if(current == 1+diagonal && charArr1[n-1] == charArr2[m-1]){
				builder.append(charArr1[n-1]);
				n--;
				m--;
			}
			if(current == upper){
				n--;
			}
			if(current == left){
				m--;
			}
		}
		return builder.reverse().toString();
	}
	static int fibonacciNos[] = null;
	public static int getFibonacciNlogN(int n){
		if(fibonacciNos==null){
			fibonacciNos = new int[n+1];
		}
		if(n==0){
			return 0;
		}
		if(n==1){
			return fibonacciNos[1] = 1;
		}
		if(fibonacciNos[n]!=0){
			return fibonacciNos[n];
		}
	    //use formula
		boolean isNeven = (n%2) == 0;
		int k;
		if(isNeven){
			k = n/2;
		}
		else {
			k = (n+1)/2;
		}
		if(isNeven){
			return fibonacciNos[n] = (2*getFibonacciNlogN(k-1) + getFibonacciNlogN(k)) * getFibonacciNlogN(k);
		}
		else {
			return fibonacciNos[n] = getFibonacciNlogN(k)*getFibonacciNlogN(k) + getFibonacciNlogN(k-1)*getFibonacciNlogN(k-1);
		}
	}
}
