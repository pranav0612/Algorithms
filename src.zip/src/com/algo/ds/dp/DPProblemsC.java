package com.algo.ds.dp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DPProblemsC {

	public static void main(String[] args) {
		List<CityPair> cityPairs = new ArrayList<>();
		cityPairs.add(new CityPair(6,2));
		cityPairs.add(new CityPair(4,3));
		cityPairs.add(new CityPair(2,6));
		cityPairs.add(new CityPair(1,5));
		System.out.println("Maximum no of bridges possible : "+getMaximumNoOfBridges(cityPairs ));
		System.out.println("Sum possible using subset : "+isSubsetSumPossible(new int[]{3, 34, 4, 12, 5, 2},9));
		System.out.println("The no of possible ways of parenthesising : "+getMaximumNoOfWaysOfParenthesization(new boolean[]{true,true,false,true},new Operators[]{Operators.OR,Operators.AND,Operators.XOR}));
		int adjacencyMatrix[][] = {
								{0,   5,  Integer.MAX_VALUE, 10},
				                {Integer.MAX_VALUE, 0,   3, Integer.MAX_VALUE},
				                {Integer.MAX_VALUE, Integer.MAX_VALUE, 0,   1},
				                {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, 0}
                				};
		printSolution(getShortestPathsUsingFloysWarshallAlgorithm(adjacencyMatrix));
	}
	private static int getMaximumNoOfBridges(List<CityPair> cityPairs){
		//sort the city pairs
		Collections.sort(cityPairs);

		//now we have sorted according to souther cities so we prepare array of norther index and find the LIS. here we will 
		//consider the non strict mode i.e. equal elements are also supposed to increase the count.

		int arr[] = new int[cityPairs.size()];
		int i = 0; 
		for (CityPair  pair : cityPairs) {
			arr[i] = pair.northCityIndex;
			i++;
		}
		return DPProblemsB.getLongestIncreasingSubsequence(arr, false);

	}
	private static class CityPair implements Comparable<CityPair>{
		int northCityIndex;
		int southCityIndex;

		public CityPair(int northCityIndex, int southCityIndex) {
			this.northCityIndex = northCityIndex;
			this.southCityIndex = southCityIndex;
		}

		@Override
		public int compareTo(CityPair o) {
			//sorting based on south city index
			if(southCityIndex != o.southCityIndex){
				return southCityIndex - o.southCityIndex;
			}
			else{
				return northCityIndex - o.northCityIndex;
			}
		}
	}
	//Check whether there exists a subset of array whose sum is T. Initially i thought this can be solved by first sorting the array
	//and after that taking elements one by one and subtracting from sum and finding the difference in rest of the elements using binary search
	//But this is wrong. We can have subset containing 3 elements :). So DP. Similar to knapsack problem
	private static boolean isSubsetSumPossible(int a[],int sum){
		boolean[][] possibleSums = new boolean[a.length+1][sum+1];

		//we can always make sum = 0 from an empty set, so it will be true for all elements of array
		for (int i = 0; i <=a.length; i++) {
			possibleSums[i][0] = true;
		}
		//for each possible smaller sums
		for (int i = 1; i <=a.length; i++) {
			for (int j = 1; j <=sum; j++) {
				//if the item is greater than sum itself then we will take the value from above row i.e. we will not consider
				//this item and take the previous boolean value without considering this item
				if(a[i-1]>j){
					possibleSums[i][j] = possibleSums[i-1][j];
				}
				//if the sum was possible with the previous item then it will be possible including this item
				else if(possibleSums[i-1][j]){
					possibleSums[i][j] = true;
				}
				//if sum was not possible with previous item then, we will consider the item which is at position sum-currentIteamValue
				//so that if the current item is added then it will perfectly add up to reach the sum. So we are moving up
				//and currentItem value steps backward in the table.
				else{
					possibleSums[i][j] = possibleSums[i-1][j-a[i-1]];
				}
			}
		}
		return possibleSums[a.length][sum];
	}
	private enum Operators{
		AND,OR,XOR
	}
	//XOR returns- same false , different true
	private static int getMaximumNoOfWaysOfParenthesization(boolean booleans[],Operators[] operators){
		int n = booleans.length;
		//define 2 tables one for true expressions and other for false expressions
		int trueExpressionWays[][] = new int[n][n];
		int falseExpressionWays[][] = new int[n][n];

		//fill the diagonal elements as these are base cases
		for (int i = 0; i < n; i++) {
			if(booleans[i]){
				trueExpressionWays[i][i] = 1;
			}
			else{
				falseExpressionWays[i][i] = 1;
			}
		}
		//now fill up our tables - consider subexpressions of all varying length
		for (int subExpressionLength = 1; subExpressionLength < n; subExpressionLength++) {
			//for subexpression of length subExpressionLength from index i to j. Now there are many subexpressions so iterate over the,
			for (int i = 0,j = subExpressionLength; j < n; i++,j++) {
				//now choose the a point k in the subexpression, k will vary from i to j-1
				for (int k = i; k < j; k++) {
					//store the total values 
					int totalFromItoK = trueExpressionWays[i][k] + falseExpressionWays[i][k];
					int totalFromKplus1ToJ = trueExpressionWays[k+1][j] + falseExpressionWays[k+1][j];

					switch(operators[k]){
					case AND:
						trueExpressionWays[i][j] += trueExpressionWays[i][k]*trueExpressionWays[k+1][j];
						falseExpressionWays[i][j] += totalFromItoK*totalFromKplus1ToJ - trueExpressionWays[i][k]*trueExpressionWays[k+1][j];
						break;
					case OR:
						trueExpressionWays[i][j] += totalFromItoK*totalFromKplus1ToJ - falseExpressionWays[i][k]*falseExpressionWays[k+1][j];
						falseExpressionWays[i][j] += falseExpressionWays[i][k]*falseExpressionWays[k+1][j];
						break;
					case XOR:
						trueExpressionWays[i][j] += trueExpressionWays[i][k]*falseExpressionWays[k+1][j] + falseExpressionWays[i][k]*trueExpressionWays[k+1][j];
						falseExpressionWays[i][j] += trueExpressionWays[i][k]*trueExpressionWays[k+1][j] + falseExpressionWays[i][k]*falseExpressionWays[k+1][j];
						break;
					}
				}
			}
		}
		return trueExpressionWays[0][n-1];
	}

	private static int[][] getShortestPathsUsingFloysWarshallAlgorithm(int[][] adjacencyMatrix){
		int shortestPaths[][] = Arrays.copyOf(adjacencyMatrix, adjacencyMatrix.length);
		//check that if K can be included from i to j, else yes then will it make the path shorter
		for (int i = 0; i < shortestPaths.length; i++) {
			for (int j = 0; j < shortestPaths.length; j++) {
				for (int k = 0; k < shortestPaths.length; k++) {
					if(shortestPaths[i][k] != Integer.MAX_VALUE &&  shortestPaths[k][j] != Integer.MAX_VALUE && shortestPaths[i][j] > shortestPaths[i][k] + shortestPaths[k][j]) {
						shortestPaths[i][j] = shortestPaths[i][k] + shortestPaths[k][j];
					}
				}
			}
		}
		return shortestPaths;
	}
  //
	private static void printSolution(int shortestPaths[][]) {
		System.out.println("Following matrix shows the shortest distances between every pair of vertices");
		for (int i=0; i<shortestPaths.length; ++i) {
			for (int j=0; j<shortestPaths.length; ++j){
				if (shortestPaths[i][j]==Integer.MAX_VALUE) {
					System.out.print("INFINITY ");
				}
				else{
					System.out.print(shortestPaths[i][j]+"   ");
				}
			}
			System.out.println();
		}
	}
}
