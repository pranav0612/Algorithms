package com.algo.ds.dp;

import com.algo.ds.dp.DPProblmesA.MaxSubArrayResult;

public class DPProblemsE {

	public static void main(String[] args) throws Exception {
		int a[][] = {
				{1,2,4,8},
				{5,3,1,2},
				{3,0,8,9},
				{7,2,2,17},
				{6,8,4,3}
		};
		System.out.println("The maximum no of apples can be obtained : "+getMaxNoOfApples(a));

		int[][] matrix = {{0, 1, 1, 0, 1}, 
				{1, 1, 0, 1, 0}, 
				{0, 1, 1, 1, 0},
				{1, 1, 1, 1, 0},
				{1, 1, 1, 1, 1},
				{0, 0, 0, 0, 0}};
		System.out.println("The maximum size of square subtrix of ones : "+getMaximumSizeOfSquareSubMatrixWithOnes(matrix));

		matrix = new int[][] {
			{1, 2, -1, -4, -20},
			{-8, -3, 4, 2, 1},
			{3, 8, 10, 1, 3},
			{-4, -1, 1, 7, -6}
		};
		printMaxRectangleInMatrix(matrix);
		System.out.println("The minimum no of jumps : "+getMinimumJumpsToReachEndOfArray(new int []{1, 3, 5, 8, 9, 2, 6, 7, 6, 8, 9}));
	}

	private static int getMaxNoOfApples(int a[][]){
		int n = a.length;
		int m = a[0].length;
		int table[][] = new int[n][m];

		//first element will be same
		table[0][0] = a[0][0];

		//base case - when we have only one row so i=0
		for (int j = 1; j < m; j++) {
			//here we can go in straight line from first column to last column in the same row
			table[0][j] = table[0][j-1] + a[0][j];
		}
		//base case - when we have only one column so j = 0
		for (int i = 1; i < n; i++) {
			//here we can go in straight line from first row to last row in the same column
			table[i][0] = table[i-1][0] + a[i][0];
		}

		//fill the table
		for (int i = 1; i < n; i++) {
			for (int j = 1; j < m; j++) {
				table[i][j] = a[i][j] + Math.max(table[i-1][j],table[i][j-1]);
			}
		}
		return table[n-1][m-1];
	}
	private static int getMaximumSizeOfSquareSubMatrixWithOnes(int matrix[][]){
		int r = matrix.length;
		int c = matrix[0].length;

		int maxSquareMatrixesSize[][] = new int[r][c];

		//in base cases we are copying the first row and column : logic is simple.
		//base case : when we have only one row that is row 0, then 
		for (int i = 0; i < c; i++) {
			maxSquareMatrixesSize[0][i] = matrix[0][i];
		}
		//base case when we have only one column that column 0
		for (int i = 0; i < r; i++) {
			maxSquareMatrixesSize[i][0] = matrix[i][0];
		}
		//we have to find max
		int maxSize = 0;

		//now fill the table
		for (int i = 1; i < r; i++) {
			for (int j = 1; j < c; j++) {
				//we have 1 so we can extend it - we are extending it with minimum value because we want the square matrix with 
				//all 1's and choosing the maximum one will result in inclusion of 0 in matrix. Also we are considering all three
				//near elements because we have to generate sqaure matrix

				if(matrix[i][j] == 1){
					maxSquareMatrixesSize[i][j] = 1 + Math.min(maxSquareMatrixesSize[i-1][j],Math.min(maxSquareMatrixesSize[i-1][j-1],maxSquareMatrixesSize[i][j-1]));
				}
				else {
					maxSquareMatrixesSize[i][j] = 0;
				}

			}
		}
		//lets calculate max
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if(maxSquareMatrixesSize[i][j] > maxSize){
					maxSize = maxSquareMatrixesSize[i][j];
				}
			}

		}
		return maxSize;
	}
	//so here we are trying each and every rectangle and using kadane's algo to reduce the complexity to O(n^3)
	private static void printMaxRectangleInMatrix(int matrix[][]){
		//left right up down will store final indices of the max sum rectangle 
		int maximumSum=0,leftIndex=0,rightIndex=0,upIndex=0,downIndex=0;

		int r = matrix.length;//rows
		int c = matrix[0].length;//columns

		//temp array needed for find the max subarray in it
		int temp[] = new int[r];

		for (int i = 0; i < c; i++) {
			for (int j = i; j < c; j++) {
				//fill temp
				for (int k = 0; k < r; k++) {
					temp[k]+= matrix[k][j];
				}
				//now update the maximum sum and coordinates of the rectangle
				MaxSubArrayResult result = DPProblmesA.getMaxValueContiguousElementsWithoutDP(temp);

				if(result.maxSum > maximumSum){
					maximumSum = result.maxSum;
					//store the coordinates
					leftIndex = i;
					rightIndex = j;
					upIndex = result.startIndex;
					downIndex = result.endIndex;
				}
			}
			//clear temp
			for (int j = 0; j < temp.length; j++) {
				temp[j] = 0;
			}
		}
		System.out.println("The maximum sum is : "+maximumSum);
		System.out.println("The dimensions of rectangle : leftIndex ->"+leftIndex+" rightIndex : "+rightIndex+" upIndex : "+upIndex+" downIndex : "+downIndex);
	}
	//concepts of ladders and stairs
	private static int getMinimumJumpsToReachEndOfArray(int a[]) throws Exception{
		
		int maxLadderReach = 0;
		int remaniningStairsInLadder = 0;
		int jumpsTillNow = 0;
		
		if(a[0] == 0){
			throw new Exception("The first element cannot be zero in the array");
		}
		//the first ladder is from first element
		maxLadderReach = a[0];
		remaniningStairsInLadder = a[0];
		jumpsTillNow = 1;
		
		for (int i = 1; i < a.length; i++) {
			
			// Check if we have reached the end of the array
			if(i == a.length-1){
				return jumpsTillNow;
			}
			//update the maxLadderReach
			maxLadderReach = Math.max(maxLadderReach,i+a[i]);
			
			//decrease a stairs as it is already taken
			remaniningStairsInLadder --;
			
			//no more stairs left in ladder
			if(remaniningStairsInLadder == 0){
				
				//check that if we have reached a point when there is no maxLadderReach available
				if(i >= maxLadderReach){
					return -1;
				}
				//we have to jump now
				jumpsTillNow++;
				
				//and take the next biggest ladder
				remaniningStairsInLadder = maxLadderReach - i;
			}
		}
		return -1;
	}
	
}
