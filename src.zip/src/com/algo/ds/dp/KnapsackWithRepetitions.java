package com.algo.ds.dp;

import java.util.ArrayList;
import java.util.List;

/* Knapsack problems - 2 types fractional and discrete
 * Fractional -- items can be split -- Can be solved by greedy algorithm -- choose the highest value/weight ratio -- next
 * Discrete knapsack -- 2 types : With repetitions , without repetitions -- both can be solved by DP
 * Solution for Discrete Knapsack with repetitions : value(W) = max(value(W-wi) + vi)
 * We calculate max value for all knapsack of weight < = W. We start with the smallest weight and keep on adding weight such
 * that the value is maximum and store that in memory.
*/
public class KnapsackWithRepetitions {

	public static void main(String[] args) {
		int knapsackCapacity = 10;
		System.out.println("Max value for knapsack is : "+getMaxValueForAKnapsack(knapsackCapacity,createItems()));
	}
	//O(n*s) n = no of items and s = size of knapsack
	private static int getMaxValueForAKnapsack(int knapsackCapacity,List<Item> items) {
		//calculate max values for each smaller knapsack -- actually start with the smallest knapsack
		//also we need an array for storing max knapsack values for each smaller knapsack
		int values[] = new int[knapsackCapacity+1];
		
		//0 weighted knapsack has 0 value
		values[0] = 0;
		
		//iterate over all small weighted knapsack
		for (int w = 1; w <= knapsackCapacity ; w++) {
			
			//try to maximize the value for this smaller knapsack by trying all possible items
			for (Item item : items) {
				if(item.weight<=w) {
					
					//get the value without this current weight
					int value = values[w-item.weight] + item.value;
					
					//update the value if it's greater than previous one
					if(value>values[w]) {
						values[w] = value;
					}
				}
			}
		}
		return values[knapsackCapacity];
	}
	private static class Item {
		private int weight;
		private int value;
		
		public Item(int weight,int value) {
			this.value = value;
			this.weight = weight;
		}
	}

	private static List<Item> createItems() {
		List<Item> list = new ArrayList<>();
		list.add(new Item(6, 30));
		list.add(new Item(3, 14));
		list.add(new Item(4, 16));
		list.add(new Item(2, 9));
		return list;
	}
}
