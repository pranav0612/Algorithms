package com.algo.ds.dp;

import java.util.ArrayList;
import java.util.List;

/* This is long story -- well we don't have items to be repeated so the previous solution will not work
 * Key idea : Start with smallest knapsack and for each item check whether this will be added or not
 * So we have combinations of items and weight of knapsack. For eg. if 5kg = Total weight of knapsack and 4 items, then 
 * Combinations will be (1kg - 1item),(1kg - 2items),(1kg - 3items)......(5kg - 3items),(5kg - 4items)
 * So we have a 2D matrix and following recurrence for weight w and ith item
 * value(w,i) = max(item included ,item not included) OR in clear way
 * value(w,i) = max(value(w-wi,i-1)+vi , value(w,i-1))
*/
public class KnapsackWithoutRepitions {

	public static void main(String[] args) {
		int knapsackCapacity = 10;
		System.out.println("Max value for knapsack is : "+getMaxValueForAKnapsack(knapsackCapacity,createItems()));
	}

	//this can be also done using recursion, just we have to use memoization to reduce recursive calls
	private static int getMaxValueForAKnapsack(int knapsackCapacity, List<Item> items) {
		//first create a 2D array for storing max values for item weight combination -- rows are items are columns are weights
		int maxValues[][] =  new int[items.size()+1][knapsackCapacity+1];
		
		//we know all values of maxValues are zero so we don't need to traverse over it.
		
		//now iterate over all items -- see if the values after and before adding 
		for (int i = 1; i <= items.size(); i++) {
			
			//now consider all smaller weights upto knapsack capacity
			for (int w = 1; w <= knapsackCapacity; w++) {
				
				//assign first the value of top element - i.e the value without adding the current item
				maxValues[i][w] = maxValues[i-1][w];
				
				//now check that if the item can be added
				if(items.get(i-1).weight <= w) {
					int valueSubtractingItem = maxValues[i-1][w-items.get(i-1).weight];
					int valueAfterAdding = valueSubtractingItem + items.get(i-1).value;
					
					//if item is making the value better
					if(valueAfterAdding > maxValues[i][w]) {
						maxValues[i][w] = valueAfterAdding;
					}
				}
			}
		}
		return maxValues[items.size()][knapsackCapacity];
	}

	private static class Item {
		private int weight;
		private int value;
		
		public Item(int weight,int value) {
			this.value = value;
			this.weight = weight;
		}
	}

	private static List<Item> createItems() {
		List<Item> list = new ArrayList<>();
		list.add(new Item(6, 30));
		list.add(new Item(3, 14));
		list.add(new Item(4, 16));
		list.add(new Item(2, 9));
		return list;
	}
}
