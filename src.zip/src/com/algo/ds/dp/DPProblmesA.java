package com.algo.ds.dp;


public class DPProblmesA {

	public static void main(String[] args) {
		System.out.println("The 8th recurrence value : "+getRecurrenceValue(8));
		System.out.println("The max value of contiguous elements : "+getMaxValueContiguousElementsUsingDP(new int []{-2,11,-4,13,-5,2}));
		System.out.println("The max value of contiguous elements : "+getMaxValueContiguousElementsWithoutDP(new int []{-2,11,-4,13,-5,2}).maxSum);
		System.out.println("The max value of contiguous elements without adjacent elements : "+getMaxContiguousSumWithNoAdjacentElements(new int []{-2,11,-4,13,-5,2}));
		System.out.println("The max value of contiguous elements without 3 contiguous elements : "+getMaxContiguousSumWithNoThreeContiguousElements(new int []{-2,11,-4,13,-5,2}));
		System.out.println("The 8th catalan number with dp is : "+getCatalanNoUsingDP(8));
		System.out.println("The 8th catalan number without dp : "+getCatalanNumberWithoutDP(8));
		System.out.println("The minimum cost of matrix multiplication : "+getMinimumMulplicationCountAndPrintBraces(new int[]{40, 20, 30, 10, 30}));
	}
    //Solve the recurrence using DP
	//T(n) = Σ(2*T(i)*T(i-1)) i is from 2 to n-1. T(0) = T(1) = 2
	private static int getRecurrenceValue(int n){
		if(n==0 || n==1){
			return 2;
		}
		//DP solution
		int arr[] = new int[n+1];
		arr[0] = 2;
		arr[1] = 2;
		arr[2] = 2*arr[0]*arr[1];
		//basically we are keep on adding elements in array, so arr[i] = arr[i-1] + T(i-1); as T(i-1) is sum till i-2
		for (int i = 3; i <= n; i++) {
			arr[i] = arr[i-1] + 2*arr[i-1]*arr[i-2];
		}
		return arr[n];
	}
	//Maximum value contiguous subsequence : Given array, find a contiguous subsequence for which sum of elements is maximum
	//To find maximum sum we have to do one of the following , either extend the old sum by adding A[i] or start new window with
	//one element A[i].
	private static int getMaxValueContiguousElementsUsingDP(int a[]){
		//we need to also add a check when all elements are negative
		int sum[] = new int[a.length];
		if(a[0]>0){
			sum[0] = a[0];
		}
		//sum[i] = Max(sum[i-1]+a[i],0)
		for (int i = 1; i < a.length; i++) {
			//extend the sum
			if(sum[i-1] + a[i] > 0){
				sum[i] = sum[i-1] + a[i];
			}
			//or start from here
			else {
				sum[i] = 0;
			}
		}
		int maxSum = 0;
		for (int i = 0; i < sum.length; i++) {
			if(sum[i]>maxSum){
				maxSum = sum[i];
			}
		}
		return maxSum;
	}
	public static MaxSubArrayResult getMaxValueContiguousElementsWithoutDP(int a[]){
		//we need to also add a check when all elements are negative
		int sumEndingHere = 0;
		int maxSum = 0;
		int localStart = 0;
		
		MaxSubArrayResult result = new MaxSubArrayResult();
		
		for (int i = 0; i < a.length; i++) {
			//we are tracking all positive segments of the array and get the max positive segment
			if(sumEndingHere + a[i] > 0){
				sumEndingHere+= a[i];
			}
			else{
				sumEndingHere = 0;
				localStart = i+1;
				
			}
			if(sumEndingHere > maxSum){
				maxSum = sumEndingHere;
				result.startIndex = localStart;
				result.endIndex = i;
			}
		}
		result.maxSum = maxSum;
		return result;
	}
	static class MaxSubArrayResult{
		int maxSum;
		int startIndex;
		int endIndex;
	}
	//Problem is same as above only one more condition -  adjacent elements are not allowed
	//we can use following recurrence and memoize it to form efficient solution. M(i) = max sum till i
	//M(i) = Max{(A[i]+ M(i-2),M(i-1)}, if i>2 
	//     = A[1], if i =1
	//     = Max(A[1],A[2]), if i=2
	private static int getMaxContiguousSumWithNoAdjacentElements(int a[]){
		int maxSums[] = new int[a.length];
		maxSums[0] = a[0];
		maxSums[1] = Math.max(a[0],a[1]);
		
		for (int i = 2; i < a.length; i++) {
			maxSums[i] = Math.max(maxSums[i-2]+a[i],maxSums[i-1]);
		}
		return maxSums[a.length-1];
	}
	//Problem : same as above. Condition change : 3 contiguous elements are not allowed
	//we can use following recurrence and memoize it to form efficient solution. M(i) = max sum till i
	//M(i) = Max{((A[i]+A[i-1]+M(i-3)) , (A[i]+M(i-2)) , M(i-1)} - include both A[i] and A[i-1] (see first element), include only A[i] (see second element), include no one
	private static int getMaxContiguousSumWithNoThreeContiguousElements(int a[]){
		int maxSums[] = new int[a.length];
		maxSums[0] = a[0];
		maxSums[1] = Math.max(a[0],a[0]+a[1]);
		maxSums[2] = Math.max(a[2],maxSums[1]);
		for (int i = 3; i < a.length; i++) {
			maxSums[i] = Math.max(a[i]+a[i-1]+maxSums[i-3],Math.max(a[i]+maxSums[i-2],maxSums[i-1]));
		}
		return maxSums[a.length-1];
	}
	//Problem : Calculate catalan number using DP. Recurrence is C(0) =1 and C(n+1) =  ΣC(i)*C(n-i) n from 0 to n 
	private static int getCatalanNoUsingDP(int n){
		int catalan[] = new int[n+1];
		catalan[0] = 1;
		catalan[1] = 1;
		
		for (int i = 2; i <=n; i++) {
			for (int j = 0; j < i; j++) {
				catalan[i]+= catalan[j]*catalan[i-j-1];
			}
		}
		return catalan[n];
	}
	//Catalan(n) = 2nCn/(n+1)
	private static int getCatalanNumberWithoutDP(int n){
		//calculate using formula
		return getBinomialCoefficient(2*n, n)/(n+1);
	}
	//nCr is the binomial coefficient. O(n) solution to calculate it.
	//C(n, r) = n! / (n-r)! * r!
	//After simplifying, we get
	//C(n, r) = [n * (n-1) * .... * (n-r+1)] / [r * (r-1) * .... * 1]
	//Also, C(n, k) = C(n, n-r)  // we can change r to n-r but we want to do that if r > n-r so that we can reduce iterations 
	private static int getBinomialCoefficient(int n,int r){
		if(r > n-r){
			r = n-r;
		}
		int result = 1;
		//iterate r times to calculate [n * (n-1) * .... * (n-r+1)] / [r * (r-1) * .... * 1]
		for (int i = 0; i < r; i++) {
			result*=n-i;
			result/=i+1;
		}
		return result;
	}
	
	
	
	private static int getMinimumMulplicationCountAndPrintBraces(int matrices[]){
		int n = matrices.length;
		//storing best results : memoization
		int m[][] = new int[n][n];
		
		//this array is for recording the values of k, i.e breakpoints where we will put brackets
		int breakPoints[][] = new int[n][n];
		
		//We have overlapping subproblems as the formula is
		//M(i,j) = 0, if i=j
		//       = Min{M(i,k) + M(k+1,j)+Pi-1 *Pk*Pj} if i<j
		int j,cost;
		
		//l is chain length. we try l = 2 i.e. all matrices of length 2. For length=1 i will be equal to j so all elements =0 
		for (int l = 2; l < n; l++) {
			
			//now for a fixed length trying all matrices with length = l
			for (int i = 1; i < n-l+1; i++) {
				j = i+l-1;//from i to j the length should be l-1 so that i to j is l including i and j
				if(j==n){
					continue;
				}
				m[i][j] = Integer.MAX_VALUE;
				//now we have defined i to j, so apply formula to calculate minimum. Lets find k
				for (int k = i; k <j ; k++) {
					cost = m[i][k] + m[k+1][j] + matrices[i-1]*matrices[k]*matrices[j];
					//update cost
					if(cost < m[i][j]){
						m[i][j] = cost;
						breakPoints[i][j] = k;//record it
					}
				}
			}
		}
		printBraces(1,n-1, n, breakPoints);
		System.out.println();
		return m[1][n-1]; 
	}
	static char currentChar = 'A';
	private static void printBraces(int i,int j,int n,int[][] breakPoints){
		if(i==j){
			System.out.print(currentChar++);
			return;
		}
		System.out.print("(");
		//Recursively put brackets around subexpression from i to breakPoints[i][j].
		printBraces(i, breakPoints[i][j], n,breakPoints);
		// Recursively put brackets around subexpression from breakPoints[i][j] + 1 to j.
		printBraces(breakPoints[i][j] + 1, j,n, breakPoints);
		System.out.print(")");
	}
}
