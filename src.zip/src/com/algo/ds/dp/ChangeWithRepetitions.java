package com.algo.ds.dp;

//can't use greedy here as the denominations can repeat.So use DP instead
//25+10+5-- greedy 20+20 -- DP
public class ChangeWithRepetitions {

	public static void main(String[] args) {
		//test data
		int moneyToBeChanged = 35;
		int coins[] = {1,5,6};
		System.out.println("Minimum no of coins needed to change "+moneyToBeChanged+ " is : "+getMinCoinsForMoney(moneyToBeChanged,coins));
	}
	private static int getMinCoinsForMoney(int moneyToBeChanged, int[] coins) {
		//create an array for storing min coins
		int minCoinsArr[] = new int[moneyToBeChanged+1];
		
		//0 can be changed with 0 coins
		minCoinsArr[0] = 0;
		
		//iterate over all breakdowns of money to be changed
		for (int i = 1; i <= moneyToBeChanged; i++) {
			
			//maximize the ith element as we will have a better way to change it
			minCoinsArr[i] = Integer.MAX_VALUE;
			
			//iterate over all coins to check if we have smaller coins than current money, if yes then find min coins if there is possibilty by breaking it
			for (int j = 0; j < coins.length; j++) {
				//check if the moneyTobeChanged is greater than equal to coin value
				if (i>=coins[j]) {
					int minCoins = minCoinsArr[i-coins[j]] + 1;
					if(minCoins< minCoinsArr[i]) {
						minCoinsArr[i] = minCoins;
					}
				}
			}
		}
		return minCoinsArr[moneyToBeChanged];
	}

}
