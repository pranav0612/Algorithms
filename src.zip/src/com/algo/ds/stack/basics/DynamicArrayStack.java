package com.algo.ds.stack.basics;

public class DynamicArrayStack {
	private int top;
	private int[] array;

	public DynamicArrayStack() {
		top =-1;
		array = new int[1];
	}
	public void push(int item){
		if(isFull()) {
			doubleArray();
		}
		array[++top] = item;
	}
	private void doubleArray() {
		int doubledArray[] = new int[array.length*2];
		System.arraycopy(array, 0, doubledArray, 0, array.length);
		array = doubledArray;
	}
	public int top() {
		return top;
	}
	public boolean isEmpty(){
		return top==-1;
	}
	public boolean isFull() {
		return top == array.length-1;
	}
	public int pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stack is empty.Stack underflow!");
		}
		return array[top--];
	}
	public void deleteStack() {
		top=-1;
	}
}
