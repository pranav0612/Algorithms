package com.algo.ds.stack.basics;

import com.algo.ds.common.Node;

public class LinkedListStack {

	private Node head;

	//keep on adding element whose next will be head and make this element new head
	public void push(int data){
		if(head==null) {
			head = new Node(data);
		}
		else{
			Node newNode = new Node(data);
			newNode.setNext(head);
			head = newNode;
		}
	}
	//remove the current and move next
	public int pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stack underflow!");
		}
		int data = head.getData();
		head = head.getNext();
		return data;
	}
	public boolean isEmpty(){
		return head==null;
	}
	public int top(){
		if(isEmpty()) {
			return -1;
		}
		return head.getData();
	}
	public void deleteStack(){
		head = null;
	}
}
