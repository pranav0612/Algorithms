package com.algo.ds.stack.basics;

public class ArrayStack {
	private int top;
	private int capacity;
	private int[] array;

	public ArrayStack(int capacity) {
		top =-1;
		this.capacity = capacity;
		array = new int[capacity];
	}
	public void push(int item) throws Exception {
		if(isFull()) {
			throw new Exception("Stack overflow");
		}
		array[++top] = item;
	}
	public int top() {
		return top;
	}
	public boolean isEmpty(){
		return top==-1;
	}
	public boolean isFull() {
		return top == capacity-1;
	}
	public int pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stack is empty.Stack underflow!");
		}
		return array[top--];
	}
	public void deleteStack() {
		top=-1;
	}
}
