package com.algo.ds.stack.problems;

public class InfixPostfixPrefix {
//Infix = A, Prefix = A, Postfix = A --- can be a single character
//Infix = (A+B)+(C-D) , Prefix = ++AB-CD ,Postfix = AB+CD-+  -- and u know
	public static void main(String[] args) {
		//bhaad mein jaye
	}

}
