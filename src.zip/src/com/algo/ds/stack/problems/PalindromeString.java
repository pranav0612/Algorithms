package com.algo.ds.stack.problems;

import java.util.Stack;

public class PalindromeString {

	public static void main(String[] args) {
		System.out.println("The string ababfbaba is palindrome : "+isPalindrome("ababfbaba")+" and :"+isPalindromeUsingStack("ababfbaba"));
		System.out.println("The string abcbbaba is palindrome : "+isPalindrome("abcbbaba")+" and :"+isPalindromeUsingStack("abcbbaba"));
	}
	private static boolean isPalindrome(String text) {
		int i = 0,j =text.length()-1;
		char charArr[] = text.toCharArray();
		while(i<j && charArr[i] == charArr[j]){
			i++; j--;
		}
		if(i<j) {
			return false;
		}
		else {
			return true;
		}
	}
	//using stack .. more space complexity as we have to maintain a stack for push popping and blah blah
	private static boolean isPalindromeUsingStack(String text) {
		Stack<Character> stack = new Stack<>();
		char charArr[] = text.toCharArray();
		for (int i = 0; i < charArr.length/2; i++) {
			stack.push(charArr[i]);
		}
		for (int i = charArr.length/2+1; i < charArr.length; i++) {
			if(charArr[i]!=stack.pop()) {
				return false;
			}
		}
		return true;
	}
}
