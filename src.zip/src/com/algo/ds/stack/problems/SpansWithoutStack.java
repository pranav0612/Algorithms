package com.algo.ds.stack.problems;

import java.util.Arrays;
//we can use DP here. span[0] = 1
// if arr[i] < arr[i-1], span[i] = span[i-1]
// else we will continue to add spans of previous elements to the current without iterating linearly.
public class SpansWithoutStack {

    public static void main(String[] args) {
        int[] inputArr = {6,3,4,5,2}; //answer = {1,1,2,3,1}
        int[] inputArr2 = {100,80,60,70,60,75,85}; //answer = {1,1,1,2,1,4,6}
        System.out.println("The spans for input array "+ Arrays.toString(inputArr)+" is : "+Arrays.toString(findSpans(inputArr)));
        System.out.println("The spans for input array "+Arrays.toString(inputArr2)+" is : "+Arrays.toString(findSpans(inputArr2)));
    }

    private static int[] findSpans(int[] inputArr) {
        int[] spans = new int[inputArr.length];
        spans[0] = 1;
        //set the span for the first element as 1 as it
        for (int i = 1; i < inputArr.length ; i++){
            //always start the counter with 1
            int counter = 1;
            //increment the counter by hoping over spans of previous elements not linearly, until a bigger element is found
            while((i-counter) >= 0 && inputArr[i] > inputArr[i-counter]){
                counter +=  spans[i-counter];// this makes jumps and we used the previous spans
            }
            //the counter is span of present element
            spans[i] = counter;
        }
        return spans;
    }
}
