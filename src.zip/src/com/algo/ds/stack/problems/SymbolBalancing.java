package com.algo.ds.stack.problems;

import java.util.Stack;

public class SymbolBalancing {

	public static void main(String[] args) throws Exception {
		//test string
		String balancedSymbols = "(ABCDE{[](6FGHJKd)})";
		String unBalancedSymbols = "(HJDYU{[](JJF))";
		SymbolBalancing app = new SymbolBalancing();
		System.out.println("The string "+balancedSymbols+" is balanced : "+app.isBalanced(balancedSymbols));
		System.out.println("The string "+unBalancedSymbols+" is balanced : "+app.isBalanced(unBalancedSymbols));
	}

	public boolean isBalanced(String symbols) throws Exception {
		Stack<Character> stack = new Stack<>();
		char[] charArr = symbols.toCharArray();
		for (int i = 0; i < charArr.length; i++) {
			if(!isClosingSymbol(charArr[i]) && !isOpeningSymbol(charArr[i])) {
				continue;
			}
			if(stack.isEmpty()) {
				if(isClosingSymbol(charArr[i])) {
					return false;
				}
				stack.push(charArr[i]);
			}
			else{
				if(isClosingSymbol(charArr[i])) {
					char c = stack.pop();
					if(charArr[i] != getClosingChar(c)) {
						return false;
					}
				}
				else{
					stack.push(charArr[i]);
				}
			}
		}
		if(!stack.isEmpty()) {
			return false;
		}
		return true;
	}
	private boolean isOpeningSymbol(char c){
		if(c=='(' || c =='{' || c=='[') {
			return true;
		}
		else {
			return false;
		}
	}
	private boolean isClosingSymbol(char c){
		if(c==')' || c =='}' || c==']') {
			return true;
		}
		else {
			return false;
		}
	}
	private char getClosingChar(char c) throws Exception{
		switch (c) {
		case '(' : return ')';
		case '{' : return '}';
		case '[' : return ']';
		}
		throw new Exception("Invalid char found!");
	}
	

}
