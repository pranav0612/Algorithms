package com.algo.ds.stack.problems;

import java.util.Stack;

public class SortStack {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		stack.push(3);
		stack.push(5);
		stack.push(1);
		stack.push(6);
		stack.push(9);
		stack.push(0);
		System.out.println("Sorting of the stack : "+stack+" yields : "+sortStack(stack));
	}
	private static Stack<Integer> sortStack(Stack<Integer> stack) {
		Stack<Integer> result = new Stack<>();
		while (!stack.isEmpty()) {
			//pop out the element from the original stack
			int item = stack.pop();
			//place this item to its correct place in the result stack
			while (!result.isEmpty() && item<result.peek()) {
				stack.push(result.pop());
			}
			result.push(item);
		}
		return result;
	}
}
