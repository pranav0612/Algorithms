package com.algo.ds.stack.problems;

import java.util.Stack;

public class GetMinOfStack {

	
	public static void main(String[] args) {
		AdvancedStack stack = new AdvancedStack();
		stack.push(1);
		stack.push(4);
		stack.push(3);
		stack.push(0);
		stack.push(6);
		stack.push(90);
		stack.push(2);
		stack.pop();
		stack.push(-1);
		stack.push(1);
		stack.push(0);
		System.out.println("The minimum of stack is "+stack.getMinimun());
	}

	private static class AdvancedStack extends Stack<Integer> {
		
		private static final long serialVersionUID = 1300474421041752194L;
		//maintain a min stack.. to get O(1) for getMinimum
		private Stack<Integer> minStack = new Stack<>();
		
		@Override
		public Integer push(Integer item) {
			if(minStack.isEmpty()) {
				minStack.push(item);
			}
			else {
				if(minStack.peek()>item) {
					minStack.push(item);
				}
			}
			return super.push(item);
		}
		@Override
		public synchronized Integer pop() {
			if(this.peek() == minStack.peek()) {
				minStack.pop();
			}
			return super.pop();
		}
		public Integer getMinimun(){
			return minStack.peek();
		}
	}
}
