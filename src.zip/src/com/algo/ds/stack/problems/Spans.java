package com.algo.ds.stack.problems;

import java.util.Arrays;
import java.util.Stack;
//The stock span problem is a financial problem where we have a series of n daily price quotes for a stock and we need to calculate span of stock’s price for all n days.
//The span Si of the stock’s price on a given day i is defined as the maximum number of consecutive days just before the given day,
// for which the price of the stock on the current day is less than or equal to its price on the given day.
//For example, if an array of 7 days prices is given as {100, 80, 60, 70, 60, 75, 85}, then the span values for corresponding 7 days are {1, 1, 1, 2, 1, 4, 6}
public class Spans {

	public static void main(String[] args) {
		int[] inputArr = {6,3,4,5,2}; //answer = {1,1,2,3,1}
		int[] inputArr2 = {100,80,60,70,60,75,85}; //answer = {1,1,1,2,1,4,6}
		System.out.println("The spans for input array "+Arrays.toString(inputArr)+" is : "+Arrays.toString(findSpans(inputArr)));
		System.out.println("The spans for input array "+Arrays.toString(inputArr2)+" is : "+Arrays.toString(findSpans(inputArr2)));
	}
	private static int[] findSpans(int[] inputArr){
		int[] spans = new int[inputArr.length];
		//maintain a next highest element using stack.. then we can calculate the span as span[i] = i - P , p = index of next highest element
		Stack<Integer> stack = new Stack<>();
		for (int i = 0; i < inputArr.length; i++) {
			//remove all elements from stack until its empty or until we found an element bigger than current element
			while (!stack.isEmpty() && inputArr[i] > inputArr[stack.peek()]) {
				stack.pop();
			}
			int p =0;
			//if stack was empty then all elements were smaller than current element so assign p -1
			if(stack.isEmpty()) {
				p = -1;
			}
			// else we have found index p which is index of next highest element of current element
			else {
				p = stack.peek();
			}
			//set the span and push the current element index in stack
			spans[i] = i-p;
			stack.push(i);
		}
		return spans;
	}
}
