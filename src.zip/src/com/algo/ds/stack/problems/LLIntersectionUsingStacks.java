package com.algo.ds.stack.problems;

import java.util.Stack;

import com.algo.ds.common.Node;

public class LLIntersectionUsingStacks {

	public static void main(String[] args) {
		Node head = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
 		Node node4 = new Node(4);
		head.setNext(node2);
		node2.setNext(node3);
		node3.setNext(node4);
		
		Node head2 = new Node(11);
		Node node22 = new Node(22);
		Node node33 = new Node(33);
		head2.setNext(node22);
		node22.setNext(node33);
		node33.setNext(node3);
		
		System.out.println("The intersection of list1 and list2 is "+findIntersectionOfLL(head, head2));
	}
	
	private static Node findIntersectionOfLL(Node head1,Node head2) {
		//create 2 stacks for each list and copy all elements
		Stack<Node> stack1 = new Stack<>();
		Stack<Node> stack2 = new Stack<>();
		
		Node list1 = head1;
		while (list1!=null) {
			stack1.push(list1);
			list1 = list1.getNext();
		}
		
		Node list2 = head2;
		while (list2!=null) {
			stack2.push(list2);
			list2 = list2.getNext();
		}
		//pop elements till they are equal
		Node result = null;
		while(stack1.peek() == stack2.peek()) {
			result = stack1.pop();
			stack2.pop();
		}
		if(result == null) {
			System.out.println("No intersection found!");
		}
		return result;
	}
}
