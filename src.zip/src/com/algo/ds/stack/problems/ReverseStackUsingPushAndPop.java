package com.algo.ds.stack.problems;

import java.util.Stack;

public class ReverseStackUsingPushAndPop {
	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();
		stack.push(1);
		stack.push(4);
		stack.push(3);
		stack.push(0);
		stack.push(6);
		System.out.println("The stack is "+stack);
		reverseStackRecursively(stack);
		System.out.println("The reverse of stack is "+stack);
	}
	private static void reverseStackRecursively(Stack<Integer> stack){
		if(stack.isEmpty()) {
			return;
		}
		int item = stack.pop();
		reverseStackRecursively(stack);
		insertAtBottom(stack, item);
	}
	private static void insertAtBottom(Stack<Integer> stack,int data) {
		if(stack.isEmpty()){
			stack.push(data);
			return;
		}
		int item = stack.pop();
		insertAtBottom(stack,data);
		stack.push(item);
	}
}
