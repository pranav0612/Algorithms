package com.algo.ds.stack.problems;

import java.util.Arrays;
import java.util.Stack;
//A simple solution is to one by one consider all bars as starting points and calculate area of all rectangles starting with every bar.
// Finally return maximum of all possible areas. Time complexity of this solution would be O(n^2).
//area for each bar will be height * (lowestRightIndex - lowestLeftIndex -1) , so we will use stack to store info for these
public class MaxAreaUnderHistogram {

	//we will implement Judge's stack of incomplete sub problems which is O(n) other are not efficient one
	public static void main(String[] args) throws Exception {
		int[] heightArr = {3,2,5,6,1,4,4};
		System.out.println("Maximum area under histogram : "+Arrays.toString(heightArr)+" is : "+getLargestArea(heightArr));
	}

	//process from left to right order, maintain a stack . The area for each bar will be
	//If stack empty, area = heightArr[stack.peek()] * i
	//If stack is not empty, area = heightArr[stack.peek()] * (i - stack.peek()-1)
	private static int getLargestArea(int[] heightArr) throws Exception{
		if(heightArr == null || heightArr.length==0) {
			throw new Exception("Fuck off the height array is empty!");
		}
		Stack<Integer> stack = new Stack<>();
		int i = 0;
		int max = 0;
		while (i<heightArr.length) {
			if(stack.isEmpty() || heightArr[i] >= heightArr[stack.peek()]) {
				stack.push(i);
				i++;
			}
			else {
				int h = heightArr[stack.pop()];
				int wid = stack.isEmpty()? i : i - stack.peek()-1;
				max = Math.max(max, h*wid);
			}
		}
		while (!stack.isEmpty()) {
			int h = heightArr[stack.pop()];
			int wid = stack.isEmpty()? i : i - stack.peek()-1;
			max = Math.max(max, h*wid);
		}
		return max;
	}
//Time Complexity: Since every bar is pushed and popped only once, the time complexity of this method is O(n).
}
