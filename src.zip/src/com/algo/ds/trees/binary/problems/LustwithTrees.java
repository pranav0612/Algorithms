package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class LustwithTrees {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Tree is : ");
		TreeTraversalNonRecursive.levelTraversal(tree);
		System.out.println();
		System.out.println("No of leaves in tree : "+noOfLeavesWithoutRecursion(tree));
		System.out.println("No of full nodes in tree : "+noOfFullNodesWithoutRecursion(tree));
		System.out.println("No of half nodes in tree : "+noOfHalfNodesWithoutRecursion(tree));
		System.out.println("Checking 2 trees : "+areTreesStructurallySame(TreeTraversalNonRecursive.createBinaryTreeNode(), tree));
		System.out.println("Diameter of the tree is : "+calculateDiameter(tree));
		System.out.println("Diameter of the tree is : "+calculateDiameter(createBinaryTreeNode()));
	}

	private static int noOfLeavesWithoutRecursion(BinaryTreeNode tree){
		//idea : leaves have null children so increase the count when encountered with that
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		int count = 0;
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if(node.getLeft()!=null) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null) {
				queue.offer(node.getRight());
			}
			if(node.getLeft()==null && node.getRight()==null) {
				count++;
			}
		}
		return count;
	}
	private static int noOfFullNodesWithoutRecursion(BinaryTreeNode tree){
		//idea : leaves have both children are full nodes so increase the count when encountered with that
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		int count = 0;
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if(node.getLeft()!=null) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null) {
				queue.offer(node.getRight());
			}
			if(node.getLeft()!=null && node.getRight()!=null) {
				count++;
			}
		}
		return count;
	}
	private static int noOfHalfNodesWithoutRecursion(BinaryTreeNode tree){
		//idea : leaves with only one child are half nodes so increase the count when encountered with that
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		int count = 0;
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			boolean isLeftChildNull = node.getLeft()==null;
			boolean isRightChildNull = node.getRight()==null;
			if(!isLeftChildNull) {
				queue.offer(node.getLeft());
			}
			if(!isRightChildNull) {
				queue.offer(node.getRight());
			}
			if((!isLeftChildNull && isRightChildNull) || (!isRightChildNull && isLeftChildNull)) {
				count++;
			}
			
		}
		return count;
	}
	//Idea : if both are null then equal else compare their data and left node with left and right with right
	private static boolean areTreesStructurallySame(BinaryTreeNode tree1,BinaryTreeNode tree2){
		if(tree1 == null && tree2 == null){
			return true;
		}
		if(tree1 == null || tree2 == null) {
			return false;
		}
		//both are non empty
		if(tree1.getData() == tree2.getData() 
				&& areTreesStructurallySame(tree1.getLeft(), tree2.getLeft())
				&& areTreesStructurallySame(tree1.getRight(), tree2.getRight())) {
			return true;
		}
		return false;
	}
	/*The diameter of a tree T is the largest of the following quantities:
	 * the diameter of T’s left subtree
	 * the diameter of T’s right subtree
	 * the longest path between leaves that goes through the root of T 
	 * (this can be computed from the heights of the subtrees of T)*/
	//here we are calculating diameter of left and right trees recursively and send max plus one
	static int diameter = 0;
	private static int calculateDiameter(BinaryTreeNode tree) {
		recursivelySetDiameter(tree);
		return diameter;
	}
	private static int recursivelySetDiameter(BinaryTreeNode tree){
		if(tree==null){
			return 0;
		}
		int left = recursivelySetDiameter(tree.getLeft());//awesome as these are heights -- left and right. Diameter of current node = left + right
		int right = recursivelySetDiameter(tree.getRight());
		if(left+right > diameter){
			diameter = left+right;
		}
		return Math.max(left, right) +1;
	}
	public static BinaryTreeNode createBinaryTreeNode() {
		BinaryTreeNode root = new BinaryTreeNode(0);
		BinaryTreeNode node1 = new BinaryTreeNode(1);
		BinaryTreeNode node2 = new BinaryTreeNode(2);
		BinaryTreeNode node3 = new BinaryTreeNode(3);
		BinaryTreeNode node4 = new BinaryTreeNode(4);
		BinaryTreeNode node5 = new BinaryTreeNode(5);
		BinaryTreeNode node6 = new BinaryTreeNode(6);
		BinaryTreeNode node7 = new BinaryTreeNode(7);
		BinaryTreeNode node8 = new BinaryTreeNode(8);
		BinaryTreeNode node9 = new BinaryTreeNode(9);
		BinaryTreeNode node10 = new BinaryTreeNode(10);
		BinaryTreeNode node11 = new BinaryTreeNode(11);
		BinaryTreeNode node12 = new BinaryTreeNode(12);
		BinaryTreeNode node13 = new BinaryTreeNode(12);
//		BinaryTreeNode node14 = new BinaryTreeNode(14);
//		BinaryTreeNode node15 = new BinaryTreeNode(15);

		root.setLeft(node1);
		root.setRight(node2);
		node1.setLeft(node3);
		node1.setRight(node4);
		node4.setRight(node5);
		node5.setRight(node6);
		node6.setRight(node7);
		
		node3.setLeft(node8);
		node8.setRight(node9);
		node9.setLeft(node10);
		node10.setLeft(node11);
		node10.setRight(node12);
		
		node2.setRight(node13);
//		node13.setLeft(node14);
//		node13.setRight(node15);
		
		return root;
	}
}
