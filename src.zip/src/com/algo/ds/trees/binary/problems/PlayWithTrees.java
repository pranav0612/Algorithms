package com.algo.ds.trees.binary.problems;

import java.util.Stack;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class PlayWithTrees {

	public static void main(String[] args) {
		int[] preOrder = {0,1,3,7,4,8,2,5,9,6,10};
		int[] inOrder = {7,3,1,8,4,0,9,5,2,10,6};
		TreeTraversalNonRecursive.levelTraversal(buildTreeUsingPreAndInOrder(preOrder, inOrder, 0, preOrder.length-1));
		System.out.println();
		System.out.print("Printing all ancestors of 5 : ");
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		printAllAncestors(tree, 10);
		System.out.println();
		System.out.print("Printing all ancestors of 5 without recursion : ");
		printAllAncestorsWithoutRecursion(tree,5);
		System.out.println();
		System.out.println("The lowest common ancestor of 5 and 6  is : "+findLCA(tree,5,6).getData());
		System.out.println("The level of key 5 is "+getLevelOfNode(tree, 5));
	}

	//construct tree using it's preorder and inorder traversals
	//1) Pick an element from Preorder. Increment a Preorder Index Variable (preIndex in below code) to pick next element in next recursive call.
	//2) Create a new tree node tNode with the data as picked element.
	//3) Find the picked element’s index in Inorder. Let the index be inIndex.
	//4) Call buildTree for elements before inIndex and make the built tree as left subtree of tNode.
	//5) Call buildTree for elements after inIndex and make the built tree as right subtree of tNode.
	//6) return tNode.
	
	private static int preIndex = 0; //variable that should be same for each recursive call
	private static BinaryTreeNode buildTreeUsingPreAndInOrder(int[] preOrder,int[] inOrder,int startIndex,int endIndex) {
		//start and end index are for dividing the tree using inorder index
		//some cases when data is not good
		if(startIndex > endIndex){
			return null;
		}
		//Pick an element from Preorder. Increment a Preorder Index Variable (preIndex in below code) to pick next element in next recursive call.
		//Create a new tree node tNode with the data as picked element.
		BinaryTreeNode newNode = new BinaryTreeNode(preOrder[preIndex]);
		preIndex++;
		
		//if node has no children then we can't divide the inIndex, so return
		if(startIndex == endIndex){
			return newNode;
		}
		//Find the picked element’s index in Inorder. Let the index be inIndex
		int inIndex = getIndexFromArray(inOrder,newNode.getData(),startIndex,endIndex);
		
		//build left subtree
		newNode.setLeft(buildTreeUsingPreAndInOrder(preOrder, inOrder, startIndex, inIndex-1));
		
		//build right subtree
		newNode.setRight(buildTreeUsingPreAndInOrder(preOrder, inOrder, inIndex+1, endIndex));
		return newNode;
	}
	private static int getIndexFromArray(int[] arr,int searchItem,int startIndex,int endIndex){
		for (int i = startIndex; i <= endIndex; i++) {
			if(searchItem == arr[i]) {
				return i;
			}
		}
		return -1;
	}
	//print All ancestors for a given node key
	private static boolean printAllAncestors(BinaryTreeNode tree,int data){
		//node not found
		if(tree==null){
			return false;
		}
		//node found so return true, don't print as we have print ancestors
		if(tree.getData() == data){
			return true;
		}
		if(printAllAncestors(tree.getLeft(), data) || printAllAncestors(tree.getRight(), data)) {
			System.out.print(tree.getData()+" ");
			return true;
		}
		return false;
	}
	//without recursion -- use iterative postorder , stop traversing when node is found. print the stack
	private static void printAllAncestorsWithoutRecursion(BinaryTreeNode tree,int data) {
		if(tree == null){
			return;
		}
		Stack<BinaryTreeNode> stack = new Stack<>();
		do {
			if(tree!=null) {
				if(tree.getData() == data){
					break;
				}
				if(tree.getRight()!=null){
					stack.push(tree.getRight());
					stack.push(tree);
					tree = tree.getLeft();
				}
				else{
					stack.push(tree);
					tree = tree.getLeft();
				}
			}
			else{
				tree = stack.pop();
				if(tree.getData() == data){
					break;
				}
				if(!stack.isEmpty() && stack.peek() == tree.getRight()) {
					BinaryTreeNode node = stack.pop();
					stack.push(tree);
					tree = node;
				}
				else {
					tree = null;
				}
			}
		} while (!stack.isEmpty());
		while (!stack.isEmpty()) {
			System.out.print(stack.pop().getData()+" ");
		}
	}
	//least common ancestor not data wise but the one who is farthest from root and is common. A node can also be it's descendant so it can be LCA of it's own
	// Method 1 : Following is simple O(n) algorithm to find LCA of n1 and n2.
	//1) Find path from root to n1 and store it in a vector or array.
	//2) Find path from root to n2 and store it in another vector or array.
	//3) Traverse both paths till the values in arrays are same. Return the common element just before the mismatch.
	
	//Method 2 : The idea is to traverse the tree starting from root. 
	//If any of the given keys (n1 and n2) matches with root, then root is LCA (assuming that both keys are present). 
	//If root doesn’t match with any of the keys, we recur for left and right subtree. 
	//The node which has one key present in its left subtree and the other key present in right subtree is the LCA. 
	//If both keys lie in left subtree, then left subtree has LCA also, otherwise LCA lies in right subtree.
	
	private static BinaryTreeNode findLCA(BinaryTreeNode root,int key1,int key2){
		//base case
		if(root==null){
			return root;
		}
		// If either n1 or n2 matches with root's key, report the presence by returning root 
		//Note that if a key is ancestor of other, then the ancestor key becomes LCA
		if(root.getData() == key1 || root.getData()== key2) {
			return root;
		}
		BinaryTreeNode leftNode = findLCA(root.getLeft(), key1, key2);
		BinaryTreeNode rightNode = findLCA(root.getRight(), key1, key2);
		
		// If both of the above calls return Non-NULL, then one key
        // is present in one subtree and other is present in other,So this node is the LCA
		if(leftNode!=null && rightNode!=null){
			return root;
		}
		else{
			return leftNode!=null? leftNode : rightNode;
		}
	}
	// can also be done using level order traversal
	private static int getLevelOfNode(BinaryTreeNode root,int key) {
		//this is one of the leaf
		if(root==null){
			return 0;
		}
		//this is the case when we found the key
		if(root.getData() == key) {
			return 1;
		}
		//recursively find key in left subtree and right subtree
		int leftSideLevel = getLevelOfNode(root.getLeft(), key);
		int rightSideLevel = getLevelOfNode(root.getRight(), key);
		//if any one of them found add 1 and return
		if(leftSideLevel>0) {
			return leftSideLevel+1;
		}
		if(rightSideLevel>0){
			return rightSideLevel+1;
		}
		//default return if key not found in current recursion or as whole
		return 0;
	}
	
}
