package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class FunWithTrees {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		traverseLevelOrderReverse(tree);
		System.out.println();
		System.out.println("Height of tree "+findHeight(tree));
		System.out.println("Height of tree "+findHeightWithoutRecursion(tree));
		System.out.println("Deepest node of the tree is : "+findDeepestNode(tree));
		System.out.println("Deleting an element 5 from tree ");
		deleteAnElementFromTree(tree, 5);
		System.out.print("Tree after deletion : ");
		TreeTraversalNonRecursive.levelTraversal(tree);
		System.out.println();
		System.out.println("Deleting full tree");
		deleteTree(tree);
	}
	//to delete a tree post order traversal is required, because it does work without storing nodes
	//to delete a tree we need to delete leaves first, so post order is perfect
	private static void deleteTree(BinaryTreeNode tree){
		if(tree==null){
			return;
		}
		deleteTree(tree.getLeft());
		deleteTree(tree.getRight());
		tree = null;
	}
	private static void traverseLevelOrderReverse(BinaryTreeNode tree) {
		//use stacks to reverse
		Stack<Integer> stack = new Stack<>();
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			stack.push(node.getData());
			if(node.getLeft()!=null) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null) {
				queue.offer(node.getRight());
			}
		}
		while (!stack.isEmpty()) {
			System.out.print(stack.pop()+" ");
		}
	}
	private static int findHeight(BinaryTreeNode tree) {
		//recursively calculate height
		if(tree==null){
			return -1;//Because height is 1 less than level
		}
		return Math.max(findHeight(tree.getLeft()),findHeight(tree.getRight())) +1;
	}
	private static int findHeightWithoutRecursion(BinaryTreeNode tree) {
		int level = 0;
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		//idea is to insert level marker elements in queue
		queue.offer(null);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if(node==null){
				level++;
				if(!queue.isEmpty()) {
					queue.offer(null);
				}
			}
			else {
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
		}
		return level-1;
	}
	private static BinaryTreeNode findDeepestNode(BinaryTreeNode tree){
		//idea is to find the element which was last dequeued from the queue as that would be one of deepest element
		BinaryTreeNode node = null;
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			node = queue.poll();
			if(node.getLeft()!=null) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null) {
				queue.offer(node.getRight());
			}
		}
		return node;
	}
	//we have to delete an element so we don't care about the order of the element.
	//Idea : find node to be deleted and deepest node. Replace each other's data and delete the deepest node
	private static void deleteAnElementFromTree(BinaryTreeNode tree,int data) {
		//search for the data
	    BinaryTreeNode nodeToBeDeleted = SearchInTree.findAndReturnNodeWithoutRecursion(tree, data);
	    if(nodeToBeDeleted!=null){
	    	//find the deepest node and it's parent
	    	Queue<BinaryTreeNode> queue =  new LinkedList<>();
	    	BinaryTreeNode parentNode = null;
	    	BinaryTreeNode deepestNode = null;
			queue.offer(tree);
			queue.offer(null);
			while (!queue.isEmpty()) {
				BinaryTreeNode node = queue.poll();
				if(node==null){
					if(!queue.isEmpty()) {
						queue.offer(null);
					}
				}
				else {
					if(node.getLeft()!=null) {
						queue.offer(node.getLeft());
					}
					if(node.getRight()!=null) {
						queue.offer(node.getRight());
					}
					if(node.getLeft()!=null || node.getRight()!=null) {
						parentNode = node;
					}
					deepestNode = node;
				}
			}
			//exchange data and delete node
			nodeToBeDeleted.setData(deepestNode.getData());
			if(parentNode.getLeft() == deepestNode){
				parentNode.setLeft(null);
			}
			if(parentNode.getRight() == deepestNode){
				parentNode.setRight(null);
			}
			deepestNode = null;
	    }
	}

}
