package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class MaxElementInTree {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Max value of the tree by recursion is :"+findMaxByRecursion(tree));
		System.out.println("Max value of the tree without recursion is :"+findMaxWithoutRecursion(tree));
	}

	private static int findMaxByRecursion(BinaryTreeNode tree) {
		int max = Integer.MIN_VALUE;
		if(tree != null) {
			int rootValue = tree.getData();
			int leftMax = findMaxByRecursion(tree.getLeft());
			int rightMax = findMaxByRecursion(tree.getRight());
			max = Math.max(rootValue,Math.max(leftMax, rightMax));
		}
		return max;
	}
	private static int findMaxWithoutRecursion(BinaryTreeNode tree){
		int max = Integer.MIN_VALUE;
		if(tree!=null) {
			//traverse level traversal
			Queue<BinaryTreeNode> queue = new LinkedList<>();
			queue.offer(tree);
			while (!queue.isEmpty()) {
				BinaryTreeNode node = queue.poll();
				max = Math.max(max,node.getData());
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
		}
		return max;
	}
}
