package com.algo.ds.trees.binary.problems.traversal;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

//Given a binary tree, print boundary nodes of the binary tree Anti-Clockwise starting from the root.
public class BoundaryTraversal {

	//We break the problem in 3 parts:
	//1. Print the left boundary in top-down manner.
	//2. Print all leaf nodes from left to right, which can again be sub-divided into two sub-parts:
	//.2.1 Print all leaf nodes of left sub-tree from left to right.
	//2.2 Print all leaf nodes of right subtree from left to right.
	//3. Print the right boundary in bottom-up manner.
	//We need to take care of one thing that nodes are not printed again. e.g. The left most node is also the leaf node of the tree.
	public static void main(String[] args) {
		printBoundary(TreeTraversalNonRecursive.createBinaryTreeNode());
	}
	//we have to print left boundary in top down manner so first print then recurse
	private static void printLeftBoundary(BinaryTreeNode root){
		if(root==null){
			return;
		}
		if(root.getLeft()!=null){
			System.out.print(root.getData()+" ");
			printLeftBoundary(root.getLeft());
		}
		//here else if is important as we have to prefer left than right and also if left is not present then print right
		else if(root.getRight()!=null){
			System.out.print(root.getData()+" ");
			printLeftBoundary(root.getRight());
		}
	}
	private static void printLeaves(BinaryTreeNode root){
		if(root==null){
			return;
		}
		if(root.getLeft() ==null && root.getRight()==null){
			System.out.print(root.getData()+" ");
		}
		printLeaves(root.getLeft());
		printLeaves(root.getRight());
	}
	//we have print right in bottom up manner so first recurse then print
	private static void printRightBoundary(BinaryTreeNode root){
		if(root==null){
			return;
		}
		if(root.getRight()!=null){
			printRightBoundary(root.getRight());
			System.out.print(root.getData()+" ");
		}
		//here else if is important as we have to prefer right than left and also if right is not present then print left
		else if(root.getLeft()!=null){
			printRightBoundary(root.getLeft());
			System.out.print(root.getData()+" ");
		}
	}
	
	private static void printBoundary(BinaryTreeNode root){
		printLeftBoundary(root);
		printLeaves(root.getLeft());
		printLeaves(root.getRight());
		printRightBoundary(root.getRight());
	}
}
