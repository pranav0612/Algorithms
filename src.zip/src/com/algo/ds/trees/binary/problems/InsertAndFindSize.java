package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class InsertAndFindSize {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Initial tree size : "+findSizeWithRecursion(tree));
		System.out.println("Inserting an element in tree");
		BinaryTreeNode nodeToInsert = new BinaryTreeNode(11);
		insert(tree, nodeToInsert);
		System.out.println("After inserting tree size : "+findSizeWithoutRecursion(tree));
	}
	//we will insert at the first location where a node has NULL left or right child. will use level order traversal
	private static BinaryTreeNode insert(BinaryTreeNode tree,BinaryTreeNode nodeToInsert) {
		if(tree==null){
			return nodeToInsert;
		}
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if (node.getLeft()!=null) {
				queue.add(node.getLeft());
			}
			else{
				node.setLeft(nodeToInsert);
				return tree;
			}
			if (node.getRight()!=null) {
				queue.add(node.getRight());
			}
			else {
				node.setRight(nodeToInsert);
				return tree;
			}
		}
		return tree;
	}
	private static int findSizeWithRecursion(BinaryTreeNode tree){
		if(tree==null) {
			return 0;
		}
		return findSizeWithRecursion(tree.getLeft()) + 1 + findSizeWithRecursion(tree.getRight());
	}
	private static int findSizeWithoutRecursion(BinaryTreeNode tree){
		//use level order traversal
		int count = 0;
		if(tree == null){
			return count;
		}
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			count++;
			if (node.getLeft()!=null) {
				queue.add(node.getLeft());
			}
			if (node.getRight()!=null) {
				queue.add(node.getRight());
			}
		}
		return count;
	}

}
