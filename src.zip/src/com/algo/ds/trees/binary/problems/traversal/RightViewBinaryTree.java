package com.algo.ds.trees.binary.problems.traversal;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

//Given a Binary Tree, print Right view of it. Right view of a Binary Tree is set of nodes visible when tree is visited from Right side.
//The Right view contains all nodes that are last nodes in their levels. A simple solution is to do level order traversal and print the last node in every level.
public class RightViewBinaryTree {

	public static void main(String[] args) {
		BinaryTreeNode root = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.print("Tree is : ");
		TreeTraversalNonRecursive.levelTraversal(root);
		System.out.println();
		System.out.print("Right view is  : ");
		printRightView(root,0);
	}
	private static int maxLevel = Integer.MIN_VALUE;
	
	//2 things. Maintain a max level, when traverse the right child first We can keep track of level of a node by passing a parameter 
	//to all recursive calls. The idea is to keep track of maximum level also. And traverse the tree in a manner that right 
	//subtree is visited before left subtree. Whenever we see a node whose level is more than maximum level so far, 
	//we print the node because this is the last node in its level 
	private static void printRightView(BinaryTreeNode root,int level){
		if(root==null){
			return;
		}
		if(level>maxLevel){
			System.out.print(root.getData()+" ");
			maxLevel = level;
		}
		//traverse right first then left
		printRightView(root.getRight(), level+1);
		printRightView(root.getLeft(), level+1);
	}
}
