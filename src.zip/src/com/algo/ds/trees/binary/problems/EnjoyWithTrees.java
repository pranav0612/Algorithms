package com.algo.ds.trees.binary.problems;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class EnjoyWithTrees {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		computeVerticalSum(tree, 0);
		printMap();
		char[] nodeCharArr = "ILILL".toCharArray();
		System.out.println();
		depthFirstInOrderTraversal(buildTreeFromPreOrder(nodeCharArr));
		System.out.println();
		System.out.println(fillNextSiblings(createBinaryTreeWithSiblings()));
		TreeWithSiblings treeWithSiblings = createBinaryTreeWithSiblings();
		fillNextSiblingsRecursive(treeWithSiblings);
		System.out.println(treeWithSiblings);
	}
	static void depthFirstInOrderTraversal(BinaryTreeNode tree) {
		if(tree==null) {
			return;
		}
		depthFirstInOrderTraversal(tree.getLeft());
		System.out.print((char)tree.getData() +" ");
		depthFirstInOrderTraversal(tree.getRight());
	}
	//concept of Horizontal distances refer trees.doc
	private static Map<Integer,Integer> map = new HashMap<>();
	
	private static void printMap(){
		//sort by keys
		Object[] keys = map.keySet().toArray();
		Arrays.sort(keys);
		for (int i = 0; i < keys.length; i++) {
			System.out.print(map.get(keys[i])+" ");
		}
	}
	//another approach is to use doubly linked list move previous when left and move next when right
	private static void computeVerticalSum(BinaryTreeNode tree,int horizontalDistance) {
		if(tree == null) {
			return;
		}
		Integer value  = map.get(horizontalDistance);
		if(value!=null){
			map.put(horizontalDistance,tree.getData()+value);
		}
		else {
			map.put(horizontalDistance,tree.getData());
		}
		computeVerticalSum(tree.getLeft(), horizontalDistance-1);
		computeVerticalSum(tree.getRight(), horizontalDistance+1);
	}
	private static int index = 0;
	//generate special tree using preorder sequence. The tree is having 0 or 2 nodes and each node is mentioned
	//whether it is a leaf node or not. 'L' = leaf , 'I' = internal node
	private static BinaryTreeNode buildTreeFromPreOrder(char[] nodeCharArr){
		//base case - all nodes are constructed
		if(index == nodeCharArr.length) {
			return null;
		}
		//construct new node
		BinaryTreeNode node = new BinaryTreeNode(nodeCharArr[index]);
		
		//that means it has left and right child both
		if(nodeCharArr[index] == 'I') {
			//populate the left child
			index++;
			node.setLeft(buildTreeFromPreOrder(nodeCharArr));
			//populate the right child
			index++;
			node.setRight(buildTreeFromPreOrder(nodeCharArr));
		}
		return node;
	}
	private static TreeWithSiblings fillNextSiblings(TreeWithSiblings tree) {
		Queue<TreeWithSiblings> queue = new LinkedList<>();
		queue.offer(tree);
		//level demarcation
		queue.offer(null);
		while (!queue.isEmpty()) {
			TreeWithSiblings node = queue.poll();
			if(node==null) {
				if (!queue.isEmpty()) {
					queue.offer(null);
				}
			}
			else {
				node.setNextRight(queue.peek());
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
			
		}
		return tree;
	}
	private static void fillNextSiblingsRecursive(TreeWithSiblings tree) {
		if(tree==null) {
			return; 
		}
		if(tree.getLeft()!=null) {
			tree.getLeft().setNextRight(tree.getRight());
		}
		if(tree.getRight()!=null && tree.getNextRight()!=null) {
			tree.getRight().setNextRight(tree.getNextRight().getLeft());
		}
		fillNextSiblings(tree.getLeft());
		fillNextSiblings(tree.getRight());
	}
   //Please refer tree.doc for this tree
	public static class TreeWithSiblings {
		private TreeWithSiblings left;
		private TreeWithSiblings right;
		private TreeWithSiblings nextRight;
		private int data;
		
		public TreeWithSiblings(int data) {
			this.setData(data);
		}
		public TreeWithSiblings getLeft() {
			return left;
		}
		public void setLeft(TreeWithSiblings left) {
			this.left = left;
		}
		public TreeWithSiblings getRight() {
			return right;
		}
		public void setRight(TreeWithSiblings right) {
			this.right = right;
		}
		public TreeWithSiblings getNextRight() {
			return nextRight;
		}
		public void setNextRight(TreeWithSiblings nextRight) {
			this.nextRight = nextRight;
		}
		public int getData() {
			return data;
		}
		public void setData(int data) {
			this.data = data;
		}
		@Override
		public String toString() {
			if(left != null && right!=null) {
				return "TreeWithSiblings [left=" + left + ", right=" + right + ", nextRight=" + nextRight + ", data=" + data
						+ "]";
			}
			else {
				return "TreeWithSiblings"+ " : data=" + data + ", nextRight=" + nextRight;
			}
			
		}
		
	}
	public static TreeWithSiblings createBinaryTreeWithSiblings() {
		TreeWithSiblings root = new TreeWithSiblings(0);
		TreeWithSiblings node1 = new TreeWithSiblings(1);
		TreeWithSiblings node2 = new TreeWithSiblings(2);
		TreeWithSiblings node3 = new TreeWithSiblings(3);
		TreeWithSiblings node4 = new TreeWithSiblings(4);
		TreeWithSiblings node5 = new TreeWithSiblings(5);
		TreeWithSiblings node6 = new TreeWithSiblings(6);
		TreeWithSiblings node7 = new TreeWithSiblings(7);
		TreeWithSiblings node8 = new TreeWithSiblings(8);
		TreeWithSiblings node9 = new TreeWithSiblings(9);
		TreeWithSiblings node10 = new TreeWithSiblings(10);

		root.setLeft(node1);
		root.setRight(node2);
		node1.setLeft(node3);
		node1.setRight(node4);
		node2.setLeft(node5);
		node2.setRight(node6);
		node3.setLeft(node7);
		node4.setLeft(node8);
		node5.setLeft(node9);
		node6.setLeft(node10);

		return root;
	}
}
