package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class SearchInTree {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Finding value of the tree by recursion. Found : "+findByRecursion(tree,500));
		System.out.println("Finding value of the tree without recursion. Found : "+findWithoutRecursion(tree,50));
	}

	public static boolean findByRecursion(BinaryTreeNode tree, int item) {
		if(tree == null) {
			return false;
		}
		if(tree.getData() == item) {
			return true;
		}
		if(findByRecursion(tree.getLeft(),item)) {
			return true;
		}
		else if(findByRecursion(tree.getRight(), item)){
			return true;
		}
		return false;
	}

	private static boolean findWithoutRecursion(BinaryTreeNode tree, int item) {
		if(tree!=null) {
			//traverse level traversal
			Queue<BinaryTreeNode> queue = new LinkedList<>();
			queue.offer(tree);
			while (!queue.isEmpty()) {
				BinaryTreeNode node = queue.poll();
				if(item == node.getData()){
					return true;
				}
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
		}
		return false;
	}
	public static BinaryTreeNode findAndReturnNodeWithoutRecursion(BinaryTreeNode tree, int item) {
		if(tree!=null) {
			//traverse level traversal
			Queue<BinaryTreeNode> queue = new LinkedList<>();
			queue.offer(tree);
			while (!queue.isEmpty()) {
				BinaryTreeNode node = queue.poll();
				if(item == node.getData()){
					return node;
				}
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
		}
		return null;
	}
}
