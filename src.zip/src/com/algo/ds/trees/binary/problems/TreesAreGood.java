package com.algo.ds.trees.binary.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class TreesAreGood {

	public static void main(String[] args) {
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Level with max sum is :"+findLevelMaxSum(tree));
		//create a path array
		int path[] = new int[1000];//depends on tree height
		printAllPathsFromRootToLeaves(tree, path, 0);
		System.out.println("Tree has a path sum = 18 : "+hasPathSum(tree, 18));
		System.out.println("Sum of all nodes of tree : "+sumOfAllNodes(tree));
		System.out.println("Sum of all nodes non recursive of tree : "+sumOfAllNodesWihtoutRecursion(tree));
		System.out.print("Tree is : ");
		TreeTraversalNonRecursive.levelTraversal(tree);
		System.out.println();
		System.out.println("Now revesing to it's mirror image");
		changeToMirrorImage(tree);
		TreeTraversalNonRecursive.levelTraversal(tree);
		System.out.println();
		System.out.println("Checking mirrror images : "+areTreesMirrorImages(tree, TreeTraversalNonRecursive.createBinaryTreeNode()));
	}
	
	//find the level which has maximum sum
	private static int findLevelMaxSum(BinaryTreeNode tree){
		int currentLevel = 0,maxLevel = 0;
		Queue<BinaryTreeNode> queue =  new LinkedList<>();
		queue.offer(tree);
		queue.offer(null);// end of level 0
		int currentSum = 0;
		int maxSum = 0;
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if(node == null) {
				if(currentSum > maxSum){
					maxSum = currentSum;
					maxLevel = currentLevel;
				}
				currentSum = 0;
				if(!queue.isEmpty()) {
					queue.offer(null);
				}
				currentLevel++;
			}
			else {
				currentSum += node.getData();
				if(node.getLeft()!=null) {
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null) {
					queue.offer(node.getRight());
				}
			}
		}
		return maxLevel;
	}
   //Use a path array path[] to store current root to leaf path. Traverse from root to all leaves in top-down fashion. 
	//While traversing, store data of all nodes in current path in array path[]. When we reach a leaf node,
	//print the path array.
	private static void printAllPathsFromRootToLeaves(BinaryTreeNode tree,int[] path,int pathLength) {
		if(tree==null){
			return;
		}
		//path array is maintaining previous data i.e higher nodes
		path[pathLength] = tree.getData();
		pathLength++;
		//if it's a leaf then print the path
		if(tree.getLeft() == null && tree.getRight()==null) {
			printRangeOfArray(path, pathLength);
		}
		else{
			printAllPathsFromRootToLeaves(tree.getLeft(), path, pathLength);
			printAllPathsFromRootToLeaves(tree.getRight(), path, pathLength);
		}
	}
	private static void printRangeOfArray(int arr[],int endIndex){
		for (int i = 0; i < endIndex; i++) {
			System.out.print(arr[i]+ " ");
		}
		System.out.println();
	}
	//idea is to subtract node value until we reach leaf or sum = 0, if both occur at same time then return true
	private static boolean hasPathSum(BinaryTreeNode tree,int sum){
		if(tree==null){
			if(sum == 0){
				return true;
			}
			else {
				return false;
			}
		}
		sum = sum - tree.getData();
		return hasPathSum(tree.getLeft(), sum) || hasPathSum(tree.getRight(), sum);
	}
	private static int sumOfAllNodes(BinaryTreeNode tree) {
		//use recursion
		if(tree == null) {
			return 0;
		}
		return tree.getData()+sumOfAllNodes(tree.getLeft())+sumOfAllNodes(tree.getRight());
	}
	private static int sumOfAllNodesWihtoutRecursion(BinaryTreeNode tree) {
		if(tree == null) {
			return 0;
		}
		int sum = 0;
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			sum += node.getData();
			if(node.getLeft()!=null) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null) {
				queue.offer(node.getRight());
			}
		}
		return sum;
	}
	private static void changeToMirrorImage(BinaryTreeNode tree) {
		if(tree==null) {
			return;
		}
		//first go to the deepest nodes then reverse
		changeToMirrorImage(tree.getLeft());
		changeToMirrorImage(tree.getRight());
		//swap
		BinaryTreeNode node = tree.getLeft();
		tree.setLeft(tree.getRight());
		tree.setRight(node);
	}
	//idea : check nulls -- both should be null at same time -- as we are comparing left to right and vice versa
	//then at any node data should be same and the left branch should be equal to right branch and vice versa
	private static boolean areTreesMirrorImages(BinaryTreeNode tree1,BinaryTreeNode tree2) {
		if(tree1==null && tree2==null){
			return true;
		}
		if(tree1==null || tree2==null){
			return false;
		}
		if(tree1.getData() != tree2.getData()) {
			return false;
		}
		return (areTreesMirrorImages(tree1.getLeft(), tree2.getRight()) && 
				areTreesMirrorImages(tree1.getRight(), tree2.getLeft()));
	}
}
