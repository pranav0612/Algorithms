package com.algo.ds.trees.binary.problems.traversal;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

//Top view of a binary tree is the set of nodes visible when the tree is viewed from the top. Given a binary tree, print the top view of it. The output nodes can be printed in any order. Expected time complexity is O(n)	
//A node x is there in output if x is the topmost node at its horizontal distance. Horizontal distance of left child of a node x is equal to horizontal distance of x minus 1, and that of right child is horizontal distance of x plus 1.
public class TopViewBinaryTree {

	public static void main(String[] args) {
		printTopViewRecursive(TreeTraversalNonRecursive.createBinaryTreeNode());
	}
	
	private static void printTopViewRecursive(BinaryTreeNode root){
		if(root==null){
			return;
		}
		topPost(root);
		topPre(root.getRight());
	}
	private static void topPost(BinaryTreeNode root){
		if(root == null){
			return ;
		}
		topPost(root.getLeft());
		System.out.print(root.getData()+" ");
	}

	private static void topPre(BinaryTreeNode root){
		if(root == null){
			return ;
		}
		System.out.print(root.getData()+" ");
		topPre(root.getRight());
	}
	
	//Another solution using horizontal distance : //group the nodes with same HD together. Print the first one and ignore 
	//rest. yes hash map. And level order traversal is required so that top node is printed first
}
