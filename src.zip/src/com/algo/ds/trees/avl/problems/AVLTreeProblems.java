package com.algo.ds.trees.avl.problems;

import com.algo.ds.trees.basics.AVLTreeBasics;
import com.algo.ds.trees.basics.AVLTreeNode;
import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class AVLTreeProblems {

	public static void main(String[] args) {
		TreeTraversalNonRecursive.inOrderTraversal(buildHeightBalancedTreeWithZeroBF(3));
		System.out.println();
		System.out.println("The tree is AVL : "+isAVLTree(TreeTraversalNonRecursive.createBinaryTreeNode()).isBalanced);
		AVLTreeBasics.inOrderTraversal(buildMinimumAVLTree(3));
		System.out.println();
		System.out.println("No of nodes in range of 2 and 12 are : "+countNodesInRange(AVLTreeBasics.createAVLTree(), 2, 12));
	}
	private static int count = 1;
	//HB(0) is full binary tree.. With h we can have 2^(h+1) -1 nodes, so nodes can be numbered from 1 to 2^(h+1) -1
	private static BinaryTreeNode buildHeightBalancedTreeWithZeroBF(int height) {
		if(height==0){
			//one node can be formed when height = 0
			BinaryTreeNode node = new BinaryTreeNode(count);
			count++;
			return node;
		}
		BinaryTreeNode node = new BinaryTreeNode(count);
		count++;
		node.setLeft(buildHeightBalancedTreeWithZeroBF(height-1));
		node.setRight(buildHeightBalancedTreeWithZeroBF(height-1));
		return node;
	}
	private static class Result {
		private int height;
		private boolean isBalanced;
		
		public Result() {}
		public Result(int height, boolean isBalanced) {
			this.height = height;
			this.isBalanced = isBalanced;
		}
	}
	//one way is to check each node and calculate the height each time == O(n^2)
	//efficient way : pass height in each recursive call and check each node. Result class is a wrapper
	private static Result isAVLTree(BinaryTreeNode root){
		//base case
		if(root == null){
			return new Result(0, true);
		}
		Result result = new Result();
		
		//check for the left and right subtree
		Result left = isAVLTree(root.getLeft());
		Result right = isAVLTree(root.getRight());
		
		//check AVL tree condition
		if(Math.abs(left.height - right.height) > 1) {
			result.isBalanced = false;
			return result;
		}
		//set the height
		result.height = Math.max(left.height,right.height) +1;
		
		//set the isBalanced
		result.isBalanced = left.isBalanced && right.isBalanced;
		return result;
	}
	
	private static AVLTreeNode buildMinimumAVLTree(int height){
		count = 1;
		return genearteMinAVLTree(height);
	}
	private static AVLTreeNode genearteMinAVLTree(int height) {
		if(height == 0){
			count++;
			return new AVLTreeNode(count);
		}
		else if(height < 0){
			return null;
		}
		AVLTreeNode node = new AVLTreeNode(count);
		count++;
		node.setLeft(genearteMinAVLTree(height-1));
		node.setRight(genearteMinAVLTree(height-2));
		node.setHeight(height);
		return node;
	}
	private static int countNodesInRange(AVLTreeNode root,int a,int b){
		//use BST property
		if(root == null){
			return 0;
		}
		//we need to go to right in this case
		if(root.getData() < a){
			return countNodesInRange(root.getRight(), a, b);
		}
		// we need to go to left in this case
		if(root.getData() > b){
			return countNodesInRange(root.getLeft(), a, b);
		}
		//now we are in range
		return countNodesInRange(root.getLeft(), a, b) + countNodesInRange(root.getRight(), a, b) + 1;
	}
	
}
