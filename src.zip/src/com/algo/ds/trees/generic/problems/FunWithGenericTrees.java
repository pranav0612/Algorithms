package com.algo.ds.trees.generic.problems;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.GenericTree;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class FunWithGenericTrees {

	public static void main(String[] args) {
		System.out.println("Sum of all nodes : "+sumOfAllNodes(createGenericTree()));
		int[] parent = {-1,0,1,6,6,0,0,2,7};
		System.out.println("Max depth of the tree "+calculateDepthFromParentArray(parent));
		System.out.println("No of siblings : "+countNoOfSiblings(createGenericTree().getFirstChild()));
		BinaryTreeNode tree = TreeTraversalNonRecursive.createBinaryTreeNode();
		System.out.println("Trees are isomorphic : "+isIsomorphic(tree,tree));
		System.out.println("Trees are quasi isomorphic : "+isQuasiIsomophic(tree,tree));
	}
	private static int sumOfAllNodes(GenericTree tree) {
		if(tree==null){
			return 0;
		}
		return tree.getData()+sumOfAllNodes(tree.getFirstChild())+sumOfAllNodes(tree.getNextSibling());
	}
	private static int countNoOfSiblings(GenericTree tree){
		int count = 0;
		while (tree.getNextSibling()!=null) {
			count++;
			tree = tree.getNextSibling();
		}
		return count;
	}
	private static int calculateDepthFromParentArray(int[] parent){
		//we can use DP.
		int maxDepth = 0;
		Integer depth[] = new Integer[parent.length];
		for (int i = 0; i < parent.length; i++) {
			
			if(parent[i] == -1){
				depth[i] = 0;
			}
			else if(depth[parent[i]]!=null) {
				depth[i] = depth[parent[i]] +1;
				maxDepth = Integer.max(maxDepth, depth[i]);
			}
			else{
				int j = i;
				int depthCount = 0;
				while (parent[j]!=-1) {
					j = parent[j];
					depthCount++;
				}
				depth[i] = depthCount;
				maxDepth = Integer.max(maxDepth, depth[i]);
			}
		}
		return maxDepth;
	}
	private static boolean isIsomorphic(BinaryTreeNode tree1,BinaryTreeNode tree2) {
		if(tree1==null && tree2==null){
			return true;
		}
		if(tree1==null && tree2!=null) {
			return false;
		}
		if(tree1!=null && tree2==null){
			return false;
		}
		return isIsomorphic(tree1.getLeft(), tree2.getLeft()) && isIsomorphic(tree1.getRight(), tree2.getRight());
	}
	
	private static boolean isQuasiIsomophic(BinaryTreeNode tree1,BinaryTreeNode tree2){
		if(tree1==null && tree2== null){
			return true;
		}
		if(tree1==null && tree2!=null) {
			return false;
		}
		if(tree1!=null && tree2==null){
			return false;
		}
		return (isIsomorphic(tree1.getLeft(), tree2.getLeft()) && isIsomorphic(tree1.getRight(), tree2.getRight()))||
			   (isIsomorphic(tree1.getLeft(), tree2.getRight()) && isIsomorphic(tree1.getRight(), tree2.getLeft()));
	}
	
	public static GenericTree createGenericTree() {
		GenericTree root = new GenericTree(0);
		GenericTree node1 = new GenericTree(1);
		GenericTree node2 = new GenericTree(2);
		GenericTree node3 = new GenericTree(3);
		GenericTree node4 = new GenericTree(4);
		GenericTree node5 = new GenericTree(5);
		GenericTree node6 = new GenericTree(6);
		GenericTree node7 = new GenericTree(7);
		GenericTree node8 = new GenericTree(8);
		GenericTree node9 = new GenericTree(9);
		GenericTree node10 = new GenericTree(10);

		root.setFirstChild(node1);
		node1.setFirstChild(node2);
		node1.setNextSibling(node3);
		node2.setFirstChild(node4);
		node2.setNextSibling(node5);
		node3.setFirstChild(node6);
		node6.setNextSibling(node7);
		node7.setNextSibling(node8);
		node8.setNextSibling(node9);
		node9.setNextSibling(node10);

		return root;
	}
}
