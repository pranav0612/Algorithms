package com.algo.ds.trees.basics;

public class BSTBasics {

	public static void main(String[] args) {
		BinaryTreeNode tree = createBST();
		System.out.println("Finding 5 in BST : "+find(tree,5));
		System.out.println("Finding 6 in BST : "+findNonRecursive(tree,6));
		System.out.println("Finding min in tree : "+findMin(tree));
		System.out.println("Finding min in tree : "+findMinNonRecursive(tree));
		System.out.println("Finding max in tree : "+findMax(tree));
		System.out.println("Finding max in tree : "+findMaxNonRecursive(tree));
		System.out.println("Inserting -2 in tree");
		insert(tree,-2);
		System.out.println("After insertion : ");
		TreeTraversalNonRecursive.levelTraversal(tree);
		System.out.println();
		System.out.println("Deleting the node -2 ");
		TreeTraversalNonRecursive.levelTraversal(delete(tree, -2));
	}
	private static BinaryTreeNode find(BinaryTreeNode root,int data) {
		if(root==null){
			return null;
		}
		if(root.getData() == data){
			return root;
		}
		if(root.getData()>data) {
			return find(root.getLeft(), data);
		}
		else{
			return find(root.getRight(), data);
		}
	}
	
	private static BinaryTreeNode findNonRecursive(BinaryTreeNode root,int data) {
		if(root==null){
			return null;
		}
		while (root!=null) {
			if(root.getData() == data){
				return root;
			}
			if(root.getData()>data) {
				root = root.getLeft();
			}
			else{
				root = root.getRight();
			}
		}
		return null;
	}
	public static BinaryTreeNode findMin(BinaryTreeNode root) {
		if(root == null){
			return null;
		}
		if(root.getLeft()==null){
			return root;
		}
		else{
			return findMin(root.getLeft());
		}
	}
	private static BinaryTreeNode findMinNonRecursive(BinaryTreeNode root) {
		BinaryTreeNode min = root;;
		while (root!=null) {
			if(root.getData()<min.getData()){
				min = root;
			}
			root = root.getLeft();
		}
		return min;
	}
	public static BinaryTreeNode findMax(BinaryTreeNode root) {
		if(root == null){
			return null;
		}
		if(root.getRight()==null){
			return root;
		}
		else{
			return findMax(root.getRight());
		}
	}
	private static BinaryTreeNode findMaxNonRecursive(BinaryTreeNode root) {
		BinaryTreeNode max = root;;
		while (root!=null) {
			if(root.getData()>max.getData()){
				max = root;
			}
			root = root.getRight();
		}
		return max;
	}
	//find the appropriate place and insert
	private static BinaryTreeNode insert(BinaryTreeNode root,int data) {
		if(root==null){
			root = new BinaryTreeNode(data);
		}
		else{
			//we are not including equal condition as we will just overwrite the node and there will no effect on tree
			if(data<root.getData()) {
				root.setLeft(insert(root.getLeft(),data));
			}
			else if(data>root.getData()){
				root.setRight(insert(root.getRight(), data));
			}
		}
		return root;
	}
	//deleting a node 
	private static BinaryTreeNode delete(BinaryTreeNode root,int data) {
		//nothing to delete
		if(root==null){
			return null;
		}
		//keep going left
		if(data<root.getData()) {
			root.setLeft(delete(root.getLeft(), data));
		}
		//right in case
		else if(data>root.getData()) {
			root.setRight(delete(root.getRight(), data));
		}
		//node found -- very important as we have to send null upward
		else{
			//both children are there find the largest element in left subtree
			if(root.getLeft()!=null && root.getRight()!=null) {
				BinaryTreeNode max = findMax(root.getLeft());
				//set data
				root.setData(max.getData());
				//delete the max node
				root.setLeft(delete(root.getLeft(),max.getData()));
			}
			//single child
			else if(root.getLeft()!=null){
				root = root.getLeft();
			}
			//single child
			else if(root.getRight()!=null){
				root = root.getRight();
			}
			//no children
			else{
				return null;
			}
		}
		return root;
	}
	public static BinaryTreeNode createBST() {
		BinaryTreeNode root = new BinaryTreeNode(4);
		BinaryTreeNode node1 = new BinaryTreeNode(1);
		BinaryTreeNode node2 = new BinaryTreeNode(2);
		BinaryTreeNode node3 = new BinaryTreeNode(3);
		BinaryTreeNode node0 = new BinaryTreeNode(0);
		BinaryTreeNode node5 = new BinaryTreeNode(5);
		BinaryTreeNode node6 = new BinaryTreeNode(6);
		BinaryTreeNode node7 = new BinaryTreeNode(7);
		BinaryTreeNode node8 = new BinaryTreeNode(8);
		BinaryTreeNode node9 = new BinaryTreeNode(9);
		BinaryTreeNode node10 = new BinaryTreeNode(10);

		root.setLeft(node2);
		root.setRight(node8);
		node2.setLeft(node1);
		node2.setRight(node3);
		node1.setLeft(node0);
		
		node8.setLeft(node6);
		node8.setRight(node9);
		node6.setLeft(node5);
		node6.setRight(node7);
		node9.setRight(node10);
		return root;
	}
}
