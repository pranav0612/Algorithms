package com.algo.ds.trees.basics;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class TreeTraversalNonRecursive {

	public static void main(String[] args) {
		BinaryTreeNode tree = createBinaryTreeNode();
		preOrderTraversal(tree);
		System.out.println();
		inOrderTraversal(tree);
		System.out.println();
		postOrderTraversal(tree);
		System.out.println();
		levelTraversal(tree);
		System.out.println();
		zigZagTraversal(tree);
	}
	public static void inOrderTraversal(BinaryTreeNode tree){
		if(tree== null) {
			return;
		}
		//using stack
		Stack<BinaryTreeNode> stack = new Stack<>();
		while (true) {
			while (tree!=null) {
				stack.push(tree);
				tree = tree.getLeft();
			}
			if(stack.isEmpty()){
				break;
			}
			tree = stack.pop();
			System.out.print(tree.getData()+" ");
			tree = tree.getRight();
		}
	}
	private static void preOrderTraversal(BinaryTreeNode tree){
		if(tree== null) {
			return;
		}
		//using stack
		Stack<BinaryTreeNode> stack = new Stack<>();
		while (true) {
			while (tree!=null) {
				System.out.print(tree.getData()+" ");
				stack.push(tree);
				tree = tree.getLeft();
			}
			if(stack.isEmpty()){
				break;
			}
			tree = stack.pop();
			tree = tree.getRight();
		}
	}
	
	//The idea is to move down to leftmost node using left pointer. 
	//While moving down, push root and root's right child to stack. 
	//Once we reach leftmost node, print it if it doesn't have a right child. 
	//If it has a right child, then change root so that the right child is processed before.

	/*1.1 Create an empty stack
     2.1 Do following while root is not NULL
    	a) Push root's right child and then root to stack.
    	b) Set root as root's left child.
	 2.2 Pop an item from stack and set it as root.
    	a) If the popped item has a right child and the right child is at top of stack, 
    	then remove the right child from stack,push the root back and set root as root's right child.
    	b) Else print root's data and set root as NULL.
	 2.3 Repeat steps 2.1 and 2.2 while stack is not empty.
	 */
	private static void postOrderTraversal(BinaryTreeNode tree){
		if(tree== null) {
			return;
		}
		//using stack
		Stack<BinaryTreeNode> stack = new Stack<>();
		do {
			//go to the left most element,on way push right child and root
			if(tree!=null) {
				if(tree.getRight()!=null) {
					stack.push(tree.getRight());
					stack.push(tree);
					tree = tree.getLeft();
				}
				else{
					stack.push(tree);
					tree = tree.getLeft();
				}
			}
			//else pop and assign to root.check if right child is same as element on stack that means it is time to explore right child first and then root
			else{
				tree = stack.pop();
				if(!stack.isEmpty() && tree.getRight()!=null && tree.getRight() == stack.peek()) {
					BinaryTreeNode righChild = stack.pop();
					stack.push(tree);
					tree = righChild;
				}
				//if not equal then print the data of root and go to next element in stack
				else {
					System.out.print(tree.getData()+" ");
					tree = null;
				}
			}
		}
		while (!stack.isEmpty());
	}
	public static void levelTraversal(BinaryTreeNode tree){
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		queue.offer(tree);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			System.out.print(node.getData()+" ");
			if (node.getLeft()!=null) {
				queue.add(node.getLeft());
			}
			if (node.getRight()!=null) {
				queue.add(node.getRight());
			}
		}
	}
	//To print the nodes in spiral order, nodes at different levels should be printed in alternating order.
	//prints nodes from left to right for first and then from right to left in next level and so on.
	private static void zigZagTraversal(BinaryTreeNode tree) {
		//idea : use 2 stacks one for printing from left to right and second for right to left
		if(tree == null){
			return;
		}
		Stack<BinaryTreeNode> stack1 = new Stack<>();
		Stack<BinaryTreeNode> stack2 = new Stack<>();
		stack1.push(tree);
		while (!stack1.isEmpty() || !stack2.isEmpty()) {
			while (!stack1.isEmpty()) {
				BinaryTreeNode node = stack1.pop();
				//print data
				System.out.print(node.getData()+" ");
				//push right before left in second stack as second stack will print left first then right
				if(node.getRight()!=null) {
					stack2.push(node.getRight());
				}
				if(node.getLeft()!=null) {
					stack2.push(node.getLeft());
				}
			}
			while (!stack2.empty()) {
				BinaryTreeNode node = stack2.pop();
				//print data
				System.out.print(node.getData()+" ");
				//push left before right in first stack as first stack will print right first then left
				if(node.getLeft()!=null) {
					stack1.push(node.getLeft());
				}
				if(node.getRight()!=null) {
					stack1.push(node.getRight());
				}
				
			}
	    }
	}
	
	public static BinaryTreeNode createBinaryTreeNode() {
		BinaryTreeNode root = new BinaryTreeNode(0);
		BinaryTreeNode node1 = new BinaryTreeNode(1);
		BinaryTreeNode node2 = new BinaryTreeNode(2);
		BinaryTreeNode node3 = new BinaryTreeNode(3);
		BinaryTreeNode node4 = new BinaryTreeNode(4);
		BinaryTreeNode node5 = new BinaryTreeNode(5);
		BinaryTreeNode node6 = new BinaryTreeNode(6);
		BinaryTreeNode node7 = new BinaryTreeNode(7);
		BinaryTreeNode node8 = new BinaryTreeNode(8);
		BinaryTreeNode node9 = new BinaryTreeNode(9);
		BinaryTreeNode node10 = new BinaryTreeNode(10);

		root.setLeft(node1);
		root.setRight(node2);
		node1.setLeft(node3);
		node1.setRight(node4);
		node2.setLeft(node5);
		node2.setRight(node6);
		node3.setLeft(node7);
		node4.setLeft(node8);
		node5.setLeft(node9);
		node6.setLeft(node10);

		return root;
	}
}
