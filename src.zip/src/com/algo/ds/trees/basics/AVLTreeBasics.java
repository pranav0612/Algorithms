package com.algo.ds.trees.basics;

public class AVLTreeBasics {

	public static void main(String[] args) {
		AVLTreeNode root = createAVLTree();
		inOrderTraversal(root);
	}
	public static int getHeight(AVLTreeNode root){
		if(root==null) {
			return -1;
		}
		return root.getHeight();
	}
	//this is applicable for RR case
	private static AVLTreeNode rotateLeft(AVLTreeNode unbalancedNode){
		if(unbalancedNode==null){
			return null;
		}
		//unbalanced so go to it's right ==  RR case
		AVLTreeNode right = unbalancedNode.getRight();

		//store the left as this link will be replaced
		AVLTreeNode leftOfRight = right.getLeft();

		//make unbalanced node  the left of right
		right.setLeft(unbalancedNode);

		//now make left of right as right of unbalanced node
		unbalancedNode.setRight(leftOfRight);

		//now set the heights of unbalanced node and right as these 2 nodes are impacted -- none others are impacted.. see definition of height
		//there is a increase
		unbalancedNode.setHeight(Math.max(getHeight(unbalancedNode.getLeft()),getHeight(unbalancedNode.getRight()))+1);
		right.setHeight(Math.max(getHeight(right.getLeft()),getHeight(right.getRight()))+1);
		// this is new balanced node
		return right;
	}
	//this is applicable for LL case
	private static AVLTreeNode rotateRight(AVLTreeNode unbalancedNode){
		if(unbalancedNode==null){
			return null;
		}
		//unbalanced so go to it's left ==  LL case
		AVLTreeNode left = unbalancedNode.getLeft();

		//store the left as this link will be replaced
		AVLTreeNode rightOfLeft = left.getRight();

		//make unbalanced node  the left of right
		left.setRight(unbalancedNode);

		//now make rightOfLeft as left of unbalanced node
		unbalancedNode.setLeft(rightOfLeft);

		//now set the heights of unbalanced node and right as these 2 nodes are impacted -- none others are impacted.. see definition of height
		//there is a increase
		unbalancedNode.setHeight(Math.max(getHeight(unbalancedNode.getLeft()),getHeight(unbalancedNode.getRight()))+1);
		left.setHeight(Math.max(getHeight(left.getLeft()),getHeight(left.getRight()))+1);
		// this is new balanced node
		return left;
	}
	//first left then right
	private static AVLTreeNode rotateLR(AVLTreeNode unbalancedNode){
		//first rotate left
		unbalancedNode.setLeft(rotateLeft(unbalancedNode.getLeft()));
		//then right
		return rotateRight(unbalancedNode);
	}

	private static AVLTreeNode rotateRL(AVLTreeNode unbalancedNode) {
		//first rotate right
		unbalancedNode.setRight(rotateRight(unbalancedNode.getRight()));
		//then left
		return rotateLeft(unbalancedNode);
	}
	//insert and return new root
	private static AVLTreeNode insert(AVLTreeNode root,int data){
		//make a new tree when null
		if(root==null){
			root = new AVLTreeNode(data);
			return root;
		}
		else{
			if(data<root.getData()) {
				//go to the left and insert
				root.setLeft(insert(root.getLeft(), data));
			}
			else if(data>root.getData()) {
				// go to the right and insert
				root.setRight(insert(root.getRight(), data));
			}
			else{
				//data already present
				return root;
			}
			//update height of root as it is returned from recursive calls
			root.setHeight(Math.max(getHeight(root.getRight()),getHeight(root.getLeft()))+1);
			//get the balance factor
			int balanceFactor = getBalanceFactor(root);
			//this is left left case as balance = left - right , so balance factor =2 or more and we check left child data to be less than current data so left left
			if(balanceFactor > 1 && data < root.getLeft().getData()) {
				return rotateRight(root);
			}
			//this is left right case
			if(balanceFactor > 1 && data > root.getLeft().getData()) {
				return rotateLR(root);
			}
			//this is right right case 
			if(balanceFactor < -1 && data > root.getRight().getData()) {
				return rotateLeft(root);
			}
			//this is right left case
			if(balanceFactor < -1 && data < root.getRight().getData()){
				return rotateRL(root);
			}
			return root;
		}
	}
	private static int getBalanceFactor(AVLTreeNode node){
		if(node==null) {
			return 0;
		}
		return getHeight(node.getLeft()) - getHeight(node.getRight());
	}
	public static AVLTreeNode createAVLTree() {
		AVLTreeNode root = insert(null, 10);
		root = insert(root, 13);
		root = insert(root, 14);
		root = insert(root, 15);
		root = insert(root, 2);
		root = insert(root, 5);
		root = insert(root, 7);
		root = insert(root, 8);
		root = insert(root, 18);
		root = insert(root, 21);
		root = insert(root, 4);
		root = insert(root, 5);
		return root;
	}
	public static void inOrderTraversal(AVLTreeNode root) {
		if(root == null){
			return;
		}
		inOrderTraversal(root.getLeft());
		System.out.print(root.getData()+" ");
		inOrderTraversal(root.getRight());
	}
}
