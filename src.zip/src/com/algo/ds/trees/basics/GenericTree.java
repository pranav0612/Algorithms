package com.algo.ds.trees.basics;

//this is called first child/next sibling representation-> since a parent can have n children so it's sufficient to link first
//child with parent and keep all children on same level and link each child with next pointers.
public class GenericTree {
	private int data;
	private GenericTree firstChild;
	private GenericTree nextSibling;
	
	public GenericTree(int data) {
		this.data = data;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public GenericTree getFirstChild() {
		return firstChild;
	}
	public void setFirstChild(GenericTree firstChild) {
		this.firstChild = firstChild;
	}
	public GenericTree getNextSibling() {
		return nextSibling;
	}
	public void setNextSibling(GenericTree nextSibling) {
		this.nextSibling = nextSibling;
	}
	@Override
	public String toString() {
		return "GenericTree [data=" + data + "]";
	}
}
