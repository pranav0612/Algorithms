package com.algo.ds.trees.basics;

import java.util.ArrayDeque;
import java.util.Queue;

public class TreeTraversal {

	//2 types - breadth first and depth first
	//depth first = completely traverse one sub tree before exploring siblings of a sub tree
	//Depth First Traversals:
	//(a) Inorder (Left, Root, Right)
	//(b) Preorder (Root, Left, Right)
	//(c) Postorder (Left, Right, Root)
	//breadth first = traverse nodes of a level then go to next level
	public static void main(String[] args) {
		Tree root = createTree();
		System.out.print("Inorder --> ");
		depthFirstInOrderTraversal(root);
		System.out.println();
		System.out.print("Preorder --> ");
		depthFirstPreOrderTraversal(root);
		System.out.println();
		System.out.print("Postorder --> ");
		depthFirstPostOrderTraversal(root);
		System.out.println();
		System.out.print("BreadthFirst --> ");
		breadthFirstTraversal(root);
	}

	static void depthFirstInOrderTraversal(Tree tree) {
		if(tree==null) {
			return;
		}
		depthFirstInOrderTraversal(tree.getLeft());
		System.out.print(tree.getKey() +" ");
		depthFirstInOrderTraversal(tree.getRight());
	}
	static void depthFirstPreOrderTraversal(Tree tree) {
		if(tree==null) {
			return;
		}
		System.out.print(tree.getKey() +" ");
		depthFirstPreOrderTraversal(tree.getLeft());
		depthFirstPreOrderTraversal(tree.getRight());
	}
	static void depthFirstPostOrderTraversal(Tree tree) {
		if(tree==null) {
			return;
		}
		depthFirstPostOrderTraversal(tree.getLeft());
		depthFirstPostOrderTraversal(tree.getRight());
		System.out.print(tree.getKey() +" ");
	}
	
	static void breadthFirstTraversal(Tree tree) {
		Queue<Tree> queue = new ArrayDeque<>();
		if(tree==null) {
			return;
		}
		queue.add(tree);
		while(!queue.isEmpty()) {
			Tree node = queue.remove();
			System.out.print(node.getKey()+" ");
			if(node.getLeft()!=null){
				queue.add(node.getLeft());
			}
			if(node.getRight()!=null){
				queue.add(node.getRight());
			}
		}
	}
	static class Tree {
		private int key;
		private Tree left;
		private Tree right;
		
		public Tree(int key) {
			this.key = key;
		}

		public int getKey() {
			return key;
		}

		public void setKey(int key) {
			this.key = key;
		}

		public Tree getLeft() {
			return left;
		}

		public void setLeft(Tree left) {
			this.left = left;
		}

		public Tree getRight() {
			return right;
		}

		public void setRight(Tree right) {
			this.right = right;
		}
		
	}
	static Tree createTree() {
		Tree root = new Tree(0);
		Tree node1 = new Tree(1);
		Tree node2 = new Tree(2);
		Tree node3 = new Tree(3);
		Tree node4 = new Tree(4);
		Tree node5 = new Tree(5);
		Tree node6 = new Tree(6);
		Tree node7 = new Tree(7);
		Tree node8 = new Tree(8);
		Tree node9 = new Tree(9);
		Tree node10 = new Tree(10);
		
		root.setLeft(node1);
		root.setRight(node2);
		node1.setLeft(node3);
		node1.setRight(node4);
		node2.setLeft(node5);
		node2.setRight(node6);
		node3.setLeft(node7);
		node4.setLeft(node8);
		node5.setLeft(node9);
		node6.setLeft(node10);
		
		return root;
	}
}
