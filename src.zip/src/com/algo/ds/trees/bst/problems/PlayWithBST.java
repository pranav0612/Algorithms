package com.algo.ds.trees.bst.problems;

import com.algo.ds.common.DLLNode;
import com.algo.ds.linkedlist.basics.LinkedListUtils;
import com.algo.ds.trees.basics.BSTBasics;
import com.algo.ds.trees.basics.BinaryTreeNode;

public class PlayWithBST {

	public static void main(String[] args) {
		BinaryTreeNode root  = BSTBasics.createBST();
		System.out.println("The LCA of 10 and 0 is "+findLCA(10, 0, root));
		System.out.println("Is the tree BST : "+isBST(root));
		System.out.println("Is the tree BST : "+isBSTInorder(root,Integer.MIN_VALUE));
		System.out.println("Printing DLL from tree : ");
		printDllFromTree(convertTreeToDLL(root));
		BinaryTreeNode newRoot  = BSTBasics.createBST();
		System.out.println();
		printDllFromTree(convertTreeToDLLEfficient(newRoot));
		System.out.println();
		//create a sorted DLL
		DLLNode head = LinkedListUtils.createSortedDLL();
		System.out.println("Dll is "+head);
		//convert this to BST
		System.out.print("After conversion the inorder traversal yields: ");
		inOrder(convertSortedDLLToBST(head));
	}
	//find the shortest path between 2 nodes of BST == same as finding LCA of 2 nodes, finding LCA is little optimized in BST
	private static BinaryTreeNode findLCA(int data1,int data2,BinaryTreeNode root) {
		while (true) {
			if((data1 < root.getData() && data2 > root.getData()) || 
					(data1 > root.getData() && data2 < root.getData())) {
				return root;
			}
			if(data1<root.getData() && data2 < root.getData()) {
				root = root.getLeft();
			}
			else{
				root = root.getRight();
			}
		}
	}
	//to check whether a tree is a BST or not -- if we check if node at left is smaller and node at right is greater then
	//at node level testing this will be incorrect. We need to check that max value at left is less than current node and
	//min value at right is greater than node -- O(n2)
	private static boolean isBST(BinaryTreeNode root) {
		if(root == null){
			return true;
		}
		if(root.getLeft()!=null && BSTBasics.findMax(root.getLeft()).getData() > root.getData()) {
			return false;
		}
		if(root.getRight()!=null && BSTBasics.findMin(root.getRight()).getData() < root.getData()) {
			return false;
		}
		if(isBST(root.getLeft()) && isBST(root.getRight())) {
			return true;
		}
		return true;
	}

	//better solution - O(n) by using inorder traversal. Inorder traversal produces a sorted list, so the node data should
	//be greater than or equal to previous-- maintain a previous
	private static boolean isBSTInorder(BinaryTreeNode root,int previous) {
		if(root == null){
			return true;
		}
		if(!isBSTInorder(root.getLeft(), previous)) {
			return false;
		}
		if(root.getData()<previous) {
			return false;
		}
		previous = root.getData();
		return isBSTInorder(root.getRight(), previous);
	}
	private static BinaryTreeNode convertTreeToDLL(BinaryTreeNode root){
		BinaryTreeNode node = convertTreeToDLLInEfficient(root);
		//got to the leftest node
		while (node.getLeft()!=null) {
			node = node.getLeft();
		}
		return node;
	}
	//space complexity O(1) refer doc .. this is O(n^2)
	private static BinaryTreeNode convertTreeToDLLInEfficient(BinaryTreeNode root) {
		//base case
		if(root==null){
			return null;
		}
		//convert the left subtree
		if(root.getLeft()!=null){
			//convert left node
			BinaryTreeNode leftNode = convertTreeToDLLInEfficient(root.getLeft());

			//find the inorder predecessor -- rightmost node in left subtree
			for (;leftNode.getRight()!=null;leftNode = leftNode.getRight()) {}

			//now leftNode is inorder predecessor so make it previous of root
			root.setLeft(leftNode);

			//make root next of inorder predecessor
			leftNode.setRight(root);
		}
		if(root.getRight()!=null){
			//convert right node
			BinaryTreeNode rightNode = convertTreeToDLLInEfficient(root.getRight());

			//find the inorder successor -- leftmost node in right subtree
			for (;rightNode.getLeft()!=null;rightNode = rightNode.getLeft()) {}

			//now rightNode is inorder successor so make it next of root
			root.setRight(rightNode);

			//make root previous of inorder predecessor
			rightNode.setLeft(root);
		}
		return root;
	}
	//space complexity O(1) refer doc .. this is O(n)
	private static BinaryTreeNode convertTreeToDLLEfficient(BinaryTreeNode root) {
		//we need 2 utility functions 1. to make fix all left pointers using a prev varibale
		fixLeftPointers(root);
		//2.go to the rightmost node of tree and reverse back fixing the next pointers 
		return fixNextPointers(root);
	}
	private static BinaryTreeNode previous = null;
	private static void fixLeftPointers(BinaryTreeNode root) {
		if(root!=null) {
			fixLeftPointers(root.getLeft());
			root.setLeft(previous);
			previous = root;
			fixLeftPointers(root.getRight());
		}
	}
	private static BinaryTreeNode fixNextPointers(BinaryTreeNode root) {
		//go to the right most node of the tree
		while (root.getRight()!=null) {
			root = root.getRight();
		}
		//reverse back and assign next pointers-- the left pointers are already fixed then we can use it
		while (root.getLeft()!=null) {
			previous = root;
			root = root.getLeft();
			root.setRight(previous);
		}
		return root;
	}
	private static void printDllFromTree(BinaryTreeNode head){
		while (head!=null) {
			System.out.print(head.getData()+ " ");
			head = head.getRight();
		}
	}
	//refer doc -- this is O(n)
	private static DLLNode convertSortedDLLToBST(DLLNode head) {
		if(head == null){
			return null;
		}
		PlayWithBST.head = head;
		//calculate size
		int size = 0;
		while (head!=null) {
			head = head.getNext();
			size++;
		}

		return convertDLLToBST(size);
	}
	private static DLLNode head;
	private static DLLNode convertDLLToBST(int size){
		//base case
		if(size<=0) {
			return null;
		}
		//Recursively create left subtree
		DLLNode left = convertDLLToBST(size/2);

		//By this time head will point to middle node, so this is our root
		DLLNode root = head;

		//make the left previous of root
		root.setPrevious(left);

		//increment head as this will required for recursive calls
		head = head.getNext();

		//recursively create right subtree
		DLLNode right = convertDLLToBST(size - (size/2) -1);

		//make this next of the root
		root.setNext(right);

		return root;
	}
	public static void inOrder(DLLNode root) {
		if (root != null) {
			inOrder(root.getPrevious());
			System.out.print(" " + root.getData());
			inOrder(root.getNext());
		}
	}
	
}
