package com.algo.ds.trees.bst.problems;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import com.algo.ds.trees.basics.BSTBasics;
import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

public class FunWithBST {

	public static void main(String[] args) {
		int arr[] = {1,2,3,4,5,6,7,8,9};
		BinaryTreeNode root = BSTBasics.createBST();
		System.out.print("Building tree from sorted array : ");
		TreeTraversalNonRecursive.inOrderTraversal(buildBSTFromSortedArray(arr, 0, arr.length-1));
		System.out.println();
		System.out.println("3rd smallest in tree : "+kthSmallestElement(root, 3));
		System.out.println("The floor of 3 is : "+floorInBST(root, 3));
		System.out.println("The Ceiling of 7 is : "+ceilingInBST(root, 7));
		System.out.println("Common nodes for the trees are : ");
		printCommonNodes(root, root);
		System.out.println();
		rangePrinter(root, 1,5);
		System.out.println();
		rangePrinterLevelOrder(root, 1, 5);
	}
	//converting sorted array to BST == same as binary search
	private static BinaryTreeNode buildBSTFromSortedArray(int arr[],int left,int right) {
		if(left>right){
			return null;
		}
		BinaryTreeNode node = null;
		if(left == right){
			node = new BinaryTreeNode(arr[left]);
			return node;
		}
		int mid = left + (right-left)/2; // for integer overflow
		node = new BinaryTreeNode(arr[mid]);
		node.setLeft(buildBSTFromSortedArray(arr,left, mid-1)); //remember mid-1 as we excluding mid
		node.setRight(buildBSTFromSortedArray(arr, mid+1, right));
		return node;
	}
	//just traverse in inorder fashion and keep track of the keys -- smallest is leftest
	private static int count = 0;
	private static BinaryTreeNode kthSmallestElement(BinaryTreeNode root,int k) {
		//base case
		if(root == null){
			return null;
		}
		//check left
		BinaryTreeNode  left = kthSmallestElement(root.getLeft(), k);
		//return left for parent recursive calls as we don't want to go down
		if(left!=null) {
			return left;
		}
		if(++count == k){
			return root;
		}
		return  kthSmallestElement(root.getRight(), k);
	}
	//floor = largest key <= key
	private static BinaryTreeNode floorInBST(BinaryTreeNode root,int key) {
		//base case
		if(root == null){
			return null;
		}
		//if key is less than root's data , then floor is in left subtree
		if(key < root.getData()){
			return floorInBST(root.getLeft(), key);
		}
		//if key is equal to root
		if(key == root.getData()){
			return root;
		}
		//key > root's data , then search in right subtree
		BinaryTreeNode node = floorInBST(root.getRight(), key);
		//if found then return it
		if(node!=null){
			return node;
		}
		//else root is closest one.. return it
		else{
			return root;
		}
	}
	//ceiling is the smallest element <= key
	private static BinaryTreeNode ceilingInBST(BinaryTreeNode root,int key){
		//base case
		if(root == null){
			return null;
		}
		//if root's data is smaller than key then ceiling lies in right subtree for sure
		if(root.getData() < key){
			return ceilingInBST(root.getRight(), key);
		}
		//if equals then return root
		if(root.getData() == key){
			return root;
		}
		//if root is greater than key then ceiling will be left subtree or will be root. So first search left subtree
		BinaryTreeNode node = ceilingInBST(root.getLeft(), key);
		if(node != null){
			return node;
		}
		//root is the closest
		else {
			return root;
		}
	}
	//iterative version
	private static void printCommonNodes(BinaryTreeNode root1,BinaryTreeNode root2) {
		Stack<BinaryTreeNode> stack1 = new Stack<>();
		Stack<BinaryTreeNode> stack2 = new Stack<>();
		while (true) {
			if(root1 != null){
				stack1.push(root1);
				root1 = root1.getLeft();// we are traversing in order so first left
			}
			else if(root2 != null){
				stack2.push(root2);
				root2 = root2.getLeft();
			}
			//both roots are null so check both stacks and pop
			else if(!stack1.isEmpty() && !stack2.isEmpty()){
				root1 = stack1.peek();
				root2 = stack2.peek();
				
				//check if the node is common
				if(root1.getData() == root2.getData()){
					System.out.print(root1.getData()+" ");
					//pop them out
					stack1.pop();
					stack2.pop();
					//move to the right
					root1 = root1.getRight();
					root2 = root2.getRight();
				}
				else if(root1.getData() > root2.getData()) {
					//then we have to pop out smaller
					stack2.pop(); //we don't need this
					root2 = root2.getRight();// go to right for bigger element
					root1 = null;//as we don't have to add any element to stack2 and don't go left , because this element
					//is already sufficient
				}
				else if(root1.getData() < root2.getData()) {
					//then we have to pop out smaller
					stack1.pop(); //we don't need this
					root1 = root1.getRight();// go to right for bigger element
					root2 = null;//as we don't have to add any element to stack1 and don't go left , because this element
					//is already sufficient
				}
			}
			else{
				break;
			}
		}
	}
	private static void rangePrinter(BinaryTreeNode root,int k1,int k2) {
		//base case
		if(root==null){
			return;
		}
		//we need to go to right in this case
		if(root.getData() < k1) {
			rangePrinter(root.getRight(), k1, k2);
		}
		//in range then print
		if(root.getData()>=k1 && root.getData()<=k2){
			System.out.print(root.getData()+ " ");
			//print others
			rangePrinter(root.getLeft(), k1, k2);
			rangePrinter(root.getRight(), k1, k2);
		}
		//we need to go to left in this case
		if(root.getData() > k2) {
			rangePrinter(root.getLeft(), k1, k2);
		}
	}
	private static void rangePrinterLevelOrder(BinaryTreeNode root,int k1,int k2){
		if(root==null) {
			return;
		}
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		queue.offer(root);
		while (!queue.isEmpty()) {
			BinaryTreeNode node = queue.poll();
			if (node.getData()>=k1 && node.getData()<=k2) {
				System.out.print(node.getData()+ " ");
				if(node.getLeft()!=null){
					queue.offer(node.getLeft());
				}
				if(node.getRight()!=null){
					queue.offer(node.getRight());
				}
			}
			if(node.getLeft()!=null && node.getData()>k2) {
				queue.offer(node.getLeft());
			}
			if(node.getRight()!=null && node.getData()<k1){
				queue.offer(node.getRight());
			}
			
		}
	}
	//another way for range print : locate k1 with binary search , then use Inorder successor until we encounter k2
	
}
