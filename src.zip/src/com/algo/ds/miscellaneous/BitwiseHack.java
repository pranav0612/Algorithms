package com.algo.ds.miscellaneous;

//XOR > different value ->1, << left shift = shifts the bits to left and fill the vacated bits by 0
//>> right shift ->shifts the bits to right and fill the vacated bits by 0 for unsigned but for signed it can fill it up with signed
//bit or 0 depending upon implementation. ~ -> bitwise compliment.(0->1 and 1->0)

public class BitwiseHack {

	public static void main(String[] args) {
		System.out.println("If 3rd bit is of 4 "+checkKthBitSetOrNot(4,3));
		System.out.println("If 3rd bit is of 1 "+checkKthBitSetOrNot(1,3));
		System.out.println("After setting the 3rd bit of 1 number is : "+setKthBit(1,3));
		System.out.println("After clearing the 3rd bit of 5 number is : "+clearKthBit(5,3));
		System.out.println("After toggling the 3rd bit of 1 : "+toggleKthBit(1,3));
		System.out.println("After clearing the right most set bit in 11 : "+togglingRightMostBit(11));
		System.out.println("Isolating the rightmost bit of 5 : "+isolateRightMostBit(5));
		System.out.println("Isolating the rightmost zero bit of 1 : "+isolateRightMostZeroBit(1));
		System.out.println("Is 4 power of 2 : "+isPowerOf2(4));
		System.out.println("Is 5 power of 2 : "+isPowerOf2(5));
		System.out.println("The double of 5 is :"+multiplyByPowerOf2(5,1));
		System.out.println("The half of 4 is :"+divideByPowerOf2(4,1));
		System.out.println("After reversing : "+Integer.toBinaryString(reverseBits(25)));
	}
	private static boolean checkKthBitSetOrNot(int a,int k){
		//first shift k-1 bits of 1 to left 
		int b = 1<<k-1;
		//now AND with the number, if the kth bit is set then 
		if((a & b)!=0){
			return true;
		}
		return false;
	}
	private static int setKthBit(int a,int k){
		//first shift k-1 bits of 1 to left 
		int b = 1<<k-1;
		//now we can OR it with number to get a number whose Kth bit is set to 1
		return b|a;
	}
	private static int clearKthBit(int a,int k){
		//first shift k-1 bits of 1 to left 
		int b = 1<<k-1;
		//now we can take its compliment and AND it to number
		return ~b & a;
	}
	private static int toggleKthBit(int a,int k){
		//first shift k-1 bits of 1 to left 
		int b = 1<<k-1;
		//Now XOR it as if it will be same it will be 0 if its different then 1
		return b^a;
	}
	//same as clearing right most bit
	private static int togglingRightMostBit(int a){
		//n-1 would have all the bits flipped after the rightmost set bit (including the set bit). 
		//So, doing n&(n-1) would give us the required result.
		return a &(a-1);
	}
	//Isolating rightmost one bit
	private static int isolateRightMostBit(int a){
		return a & -a;
	}
	//Isolating the leftmost zero bit
	private static int isolateRightMostZeroBit(int a){
		return ~a & (a+1); 
	}
	//checking the number is power of 2 or not
	private static boolean isPowerOf2(int a){
		//10,100,1000 these are powers of 2, so we will do n-1 as if the number is power of 2 , then after n-1 it will be in form
		//01,011,0111 and then we do AND. If the result is 0 then it is power of 2 else not
		return ((a & (a-1)) == 0);
	}
	//multiplying by 2^k
	private static int multiplyByPowerOf2(int a, int k){
		return a<< k;
	}
	//dividing by 2^k
	private static int divideByPowerOf2(int a, int k){
		return a >> k;
	}
	//reversing the bits of a number
	private static int reverseBits(int a){
		System.out.println("The initials bits are : "+Integer.toBinaryString(a));
		System.out.println("Java's built in output : "+Integer.toBinaryString(Integer.reverse(a)));
		int reverse = 0;
		//int size  = Integer.SIZE - Integer.numberOfLeadingZeros(a);
		while (a!=0){
			reverse<<=1;
			reverse|=( a &1);
			a>>=1;
		}
		return reverse;
	}
}