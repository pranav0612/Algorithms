package com.algo.ds.amazonprep.easy;

public class RectangleOverlapChecker {

	public static void main(String[] args) {
		Point topLeftFirstRec = new Point(0,10);
		Point bottomRightFirstRec  = new Point(10,0);
		Point topLeftSecondRec  = new Point(5,5);
		Point bottomRightSecondRec  = new Point(15,0);
		System.out.println("The rectangle overlaps : "+checkRectangleOverlap(topLeftFirstRec, bottomRightFirstRec, topLeftSecondRec, bottomRightSecondRec));
	}

	private static boolean checkRectangleOverlap(Point topLeftFirstRec,Point bottomRightFirstRec,Point topLeftSecondRec,Point bottomRightSecondRec){
		//calculate all four points of second rectangles
		Point topRightSecondRec = new Point(bottomRightSecondRec.x, topLeftSecondRec.y);
		Point bottomLeftSecondRec = new Point(topLeftSecondRec.x, bottomRightSecondRec.y);

		//check each point of rectangle whether it is in range of the first rectangle
		double xCoordinateFrom = topLeftFirstRec.x;
		double xCoodinateTo = bottomRightFirstRec.x;
		double yCoordinateFrom = bottomRightFirstRec.y;
		double yCoordinateTo = topLeftFirstRec.y;

		//checking all coordinates of the second rectangle in range
		//first point
		if(checkNumberInRange(xCoordinateFrom, xCoodinateTo, topLeftSecondRec.x) && checkNumberInRange(yCoordinateFrom, yCoordinateTo, topLeftSecondRec.y)){
			return true;
		}
		//second point
		if(checkNumberInRange(xCoordinateFrom, xCoodinateTo, topRightSecondRec.x) && checkNumberInRange(yCoordinateFrom, yCoordinateTo, topRightSecondRec.y)){
			return true;
		}
		//third point
		if(checkNumberInRange(xCoordinateFrom, xCoodinateTo, bottomLeftSecondRec.x) && checkNumberInRange(yCoordinateFrom, yCoordinateTo, bottomLeftSecondRec.y)){
			return true;
		}
		//fourth point
		if(checkNumberInRange(xCoordinateFrom, xCoodinateTo, bottomRightSecondRec.x) && checkNumberInRange(yCoordinateFrom, yCoordinateTo, bottomRightSecondRec.y)){
			return true;
		}
		return false;
	}
	private static boolean checkNumberInRange(double from,double to,double number){
		if(number>from && number < to){
			return true;
		}
		return false;
	}
	static class Point{
		double x;
		double y;

		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}
	}
}
