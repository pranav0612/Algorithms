package com.algo.ds.amazonprep.easy;

import java.util.HashMap;
import java.util.Map;

//Given an array of distinct elements and a number x, find if there is a pair with product equal to x.
public class PairWithGivenProduct {

	//Naive approach O(n2)
	//Better Solution (O(n Log n) : We sort the given array. After sorting, we traverse the array and for every element arr[i], 
	//we do binary search for x/arr[i] in the subarry on right of arr[i], i.e., in subarray arr[i+1..n-1]
	public static void main(String[] args) {
		System.out.println("Product can be formed : "+isProductPossible(new int[]{10, 20, 9, 40}, 400));
	}
	//Efficient Solution ( O(n) ): We can improve time complexity to O(n) using hashing. 
	private static boolean isProductPossible(int a[],int product){
		Map<Integer,Integer> map = new HashMap<>();
		
		if(a.length<2){
			return false;
		}
		for (int i = 0; i < a.length; i++) {
			if(a[i] == 0 && product ==0){
				return true;
			}
			if(product % a[i] == 0){
				if(map.get(product/a[i])!=null){
					return true;
				}
				else{
					map.put(a[i],product/a[i]);
				}
			}
		}
		return false;
	}
}
