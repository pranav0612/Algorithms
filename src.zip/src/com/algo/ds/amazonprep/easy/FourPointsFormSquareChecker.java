package com.algo.ds.amazonprep.easy;

/*Given coordinates of four points in a plane, find if the four points form a square or not.
To check for square, we need to check for following.
a) All fours sides formed by points are same.
b) The angle between any two sides is 90 degree.*/

public class FourPointsFormSquareChecker {

	public static void main(String[] args) {
		System.out.println("The points form square : "+isSquare(new Point(20,10),new Point(10,20), new Point(20,20),new Point(10, 10)));
	}
	static class Point{
		public Point(double x,double y) {
			this.x = x;
			this.y = y;
		}
		double x;
		double y;
	}
	private static boolean isSquare(Point point1,Point point2,Point point3,Point point4){
		
		//lets pick any point and calculate the distances to other points
		double distance12 = squaredDistance(point1, point2);
		double distance13 = squaredDistance(point1, point3);
		double distance14 = squaredDistance(point1, point4);
		
		if(distance12 == distance13){
			//check distance14 to 2 times the distance12
			if(distance14 != 2*distance12){
				return false;
			}
			//check that the point 4 is same side as of 2 and 3
			if(squaredDistance(point2, point4) == squaredDistance(point3, point4)){
				return true;
			}
			else{
				return false;
			}
		}
		else if(distance12 == distance14){
			//check distance13 to 2 times the distance12
			if(distance13 != 2*distance12){
				return false;
			}
			//check that the point 3 is same side as of 1 and 4
			if(squaredDistance(point2, point3) == squaredDistance(point4, point3)){
				return true;
			}
			else{
				return false;
			}
		}
		else if(distance13 == distance14){
			//check distance12 to 2 times the distance13
			if(distance12 != 2*distance13){
				return false;
			}
			//check that the point 2 is same side as of 1 and 3
			if(squaredDistance(point2, point4) == squaredDistance(point2, point3)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
	private static double squaredDistance(Point point1,Point point2){
		return Math.pow((point1.x-point2.x),2) + Math.pow((point1.y-point2.y),2);
	}
}
