package com.algo.ds.amazonprep.easy;

/*Given two strings, the task is to find if a string can be obtained by rotating another string two places.
Examples:
Input : string1 = "amazon" 
        string2 = "azonam"  // rotated anti-clockwise
Output : Yes
Input : string1 = "amazon"
        string2 = "onamaz"  // rotated clockwise
Output : Yes*/

public class StringRotateChecker {

	public static void main(String[] args) {
		System.out.println("The strings can be converted by 2 rotations : "+checkStringOtbtainedAfter2Rotations("geeks","eksge"));
	}
	private static boolean checkStringOtbtainedAfter2Rotations(String input,String target){
		if(input.length() != target.length()){
			return false;
		}
		int length = input.length();
		//check the first 2 characters and last 2 characters of both strings
		//check clockwise
		if(input.charAt(length-2) == target.charAt(0) && input.charAt(length-1) == target.charAt(1)){
			return input.substring(0,length-2).equals(target.substring(2,length));
		}
		//check anti clockwise
		if(input.charAt(0) == target.charAt(length-2) && input.charAt(1) == target.charAt(length-1)){
			return input.substring(2,length).equals(target.substring(0,length-2));
		}
		return false;
	}
}
