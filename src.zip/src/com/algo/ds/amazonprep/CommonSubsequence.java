package com.algo.ds.amazonprep;

import java.util.Scanner;

//Given two strings a and b print whether they contain any common subsequence (non empty) or not.
//Input: ABEF CADE Output: true AE
public class CommonSubsequence {

	public static void main(String[] args) {
		System.out.println("If the string ABSKHGA has unique characters : "+isStringHasUniqueCharacters("ABSKHGA"));
		System.out.println("If the string ABSKHG has unique characters : "+isStringHasUniqueCharacters("ABSKHG"));
		//checkCommonSubsequence();//this one was for geegsforgeeks
	}

	public static void checkCommonSubsequence() {
		Scanner sc = new Scanner(System.in);
		//t is no of test cases
		int t = Integer.parseInt(sc.nextLine());
		for (int i = 1; i <= t; i++) {
			String x[] = sc.nextLine().split(" ");
		    String a=x[0];
		    String b=x[1];
		    
		    char[] aCharArr = a.toCharArray();
		    char[] bCharArr = b.toCharArray();
		    
		    //only 26 characters are there
		    int[] alphabets = new int[256];
		    
		    for (int j = 0; j < aCharArr.length; j++) {
				alphabets[aCharArr[j]] = 1;
			}
		    boolean found = false;
		    for (int j = 0; j < bCharArr.length; j++) {
				if(alphabets[bCharArr[j]] == 1){
					found = true;
					break;
				}
			}
		    if(found){
		    	System.out.println(1);
		    }
		    else{
		    	System.out.println(0);
		    }
		    
		}
		sc.close();
	}
	//check string has unique characters in  O(1) space - we will use the bits of integer variable instead of charArr of 26 sized 
	//array as we want 26 bits only and integer has 32 bits
	private static boolean isStringHasUniqueCharacters(String s){
		
		if (s.length() > 26) {
	        return false;
	    }
		char[] charArr = s.toCharArray();
		int val;
		
		//now instead of array we will use int variable bits check if the bits are already set
		int checker = 0;//all bits are 0
		
		for (int i = 0; i < charArr.length; i++) {
			val = 'a' - charArr[i];
			//now check if positional bit for val is already set in the checker. 
			//1<<val will give a binary number with only valth bit set to 1 and all 0
			//Checker will have only those bits set which were earlier set prior to this character and Anding with check will result
			//into 0 if a new character was there else if the character already was encountered before then u know 1&1 = 1,so a non zero number
			if((checker & (1<<val)) > 0) {
				return false;
			}
			//update the checker using OR
			checker |= (1<<val); 
		}
		return true;
		
	}

}
