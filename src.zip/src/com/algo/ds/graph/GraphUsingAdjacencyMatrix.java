package com.algo.ds.graph;

//Space = O(V^2) and time complexity for initialization = O(V^2)
public class GraphUsingAdjacencyMatrix {

	private boolean matrix[][];
	private int vertexCount;
	
	public GraphUsingAdjacencyMatrix(int vertexCount) {
		this.vertexCount = vertexCount;
		matrix = new boolean[this.vertexCount][this.vertexCount];
	}
	//add edge from i to j and j to i
	public void addEdge(int i,int j){
		if(validRange(i) && validRange(j)){
			matrix[i][j] = true;
			matrix[j][i] = true;
		}
	}
	private boolean validRange(int i){
		if(i>=0 && i<vertexCount){
			return true;
		}
		return false;
	}
	public void removeEdge(int i,int j){
		if(validRange(i) && validRange(j)){
			matrix[i][j] = false;
			matrix[j][i] = false;
		}
	}
	public boolean isEdge(int i,int j){
		if(validRange(i) && validRange(j)){
			return matrix[i][j];
		}
		else{
			return false;
		}
	}
}
