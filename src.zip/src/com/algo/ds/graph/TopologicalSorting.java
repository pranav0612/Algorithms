package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class TopologicalSorting {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		System.out.println(topologicalSort(graph));
	}
	public static List<Integer> topologicalSort(GraphUsingList graph){
		Vertex[] vertices = graph.vertices;
		List<Integer> result = new ArrayList<>();
		for (Vertex node : vertices) {
			if(!node.visited){
				node.visited = true;
				explore(vertices, node.neighbours, result);
				result.add(node.index);
			}
		}
		//now reverse the list to get ordering from source to sink
		Collections.reverse(result);
		return result;
	}
	private static void explore(Vertex[] vertices,ArrayList<Integer> neighbors,List<Integer> result){
		if(!neighbors.isEmpty()){
			for (Integer neighborIndex : neighbors) {
				Vertex node = vertices[neighborIndex];
				if(!node.visited){
					node.visited = true;
					explore(vertices, node.neighbours,result);
					//now add this node to final list as it is a source node now because it's neighbors are explored
					result.add(neighborIndex);
				}
			}
		}
	}
}
