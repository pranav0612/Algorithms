package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

import com.algo.ds.graph.GraphUsingList.Edge;

public class Prims {

	public static void main(String[] args) {
		int n = 6;
		Node[] vertices = new Node[n];
		for (int i = 0; i < n; i++) {
			vertices[i] = new Node(i,false,new ArrayList<Integer>(),new ArrayList<Integer>());
		}
		vertices[0].neighbours.add(1);
		vertices[0].neighbours.add(2);
		vertices[0].neighbours.add(3);
		vertices[0].weights.add(2);
		vertices[0].weights.add(1);
		vertices[0].weights.add(4);
		
		vertices[1].neighbours.add(0);
		vertices[1].neighbours.add(2);
		vertices[1].weights.add(2);
		vertices[1].weights.add(3);
		
		vertices[2].neighbours.add(1);
		vertices[2].neighbours.add(0);
		vertices[2].neighbours.add(3);
		vertices[2].neighbours.add(4);
		vertices[2].weights.add(3);
		vertices[2].weights.add(1);
		vertices[2].weights.add(5);
		vertices[2].weights.add(9);
		
		vertices[3].neighbours.add(0);
		vertices[3].neighbours.add(2);
		vertices[3].neighbours.add(4);
		vertices[3].neighbours.add(5);
		vertices[3].weights.add(4);
		vertices[3].weights.add(5);
		vertices[3].weights.add(6);
		vertices[3].weights.add(8);
		
		vertices[4].neighbours.add(2);
		vertices[4].neighbours.add(3);
		vertices[4].neighbours.add(5);
		vertices[4].weights.add(9);
		vertices[4].weights.add(6);
		vertices[4].weights.add(1);
		
		vertices[5].neighbours.add(3);
		vertices[5].neighbours.add(4);
		vertices[5].weights.add(8);
		vertices[5].weights.add(1);
		
		System.out.println(getMinimumSpanningTreeUsingPrims(vertices));
	}
	//very similar to dijtra's.
	public static List<Edge> getMinimumSpanningTreeUsingPrims(Node[] vertices){
		List<Edge> result = new ArrayList<>();
		
		//create a PQ for edges, we need that the edge with lowest weight should have highest priority
		PriorityQueue<Edge> queue = new PriorityQueue<>();

		//add any vertex's edges to it.Lets add edges of first vertex in array
		for (int i=0;i<vertices[0].neighbours.size();i++) {
			queue.offer(new Edge(0,vertices[0].neighbours.get(i),vertices[0].weights.get(i)));
		}
		//make the node visited
		vertices[0].visited = true;
		
		while (!queue.isEmpty()) {
			//keep on adding the lightest edge to current subtree
			Edge edge = queue.remove();
			//now we will explore the other end of edge
			Node neighbor = vertices[edge.endIndex];
			//if not visited
			if(!neighbor.visited) {
				//add only when the endNode is not visited
				result.add(edge);
				//add all of it's unvisited edges
				for (int i=0;i<neighbor.neighbours.size();i++) {
					if(!vertices[neighbor.neighbours.get(i)].visited){
						queue.offer(new Edge(neighbor.index,neighbor.neighbours.get(i),neighbor.weights.get(i)));
					}
				}
				//after exploring the neighbor mark it as visited
				neighbor.visited = true;
			}
		}
		return result;
	}
	//we haven't used the GraphUsingList class as the node has weights here
	private static class Node{
		private int index;
		private boolean visited;
		private ArrayList<Integer> neighbours;
		private ArrayList<Integer> weights;

		public Node(int index,boolean visited,ArrayList<Integer> neighbours,ArrayList<Integer> weights) {
			this.index = index;
			this.visited = visited;
			this.neighbours = neighbours;
			this.weights = weights;
		}
	}
}
