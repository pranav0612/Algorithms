package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.Arrays;


public class StronglyConnected {
	private static int clock = 1;
	private static int numberOfStronglyConnectedComponents(Node[] vertices, Node[] reverseGraph) {
		int result = 0;
		//Run DFS on reverse graph to find the sources that have highest post order--- the sources will be the sinks in the main graph and exploring those will give our SCC
		for (int i = 0; i < reverseGraph.length; i++) {
			if(!reverseGraph[i].visited) {
				reverseGraph[i].visited = true;
				previsit(reverseGraph[i]);
				explore(reverseGraph, reverseGraph[i].neighbours);
				postvisit(reverseGraph[i]);
			}
		}
		// SORT the reverse graph with the post visit values
		Arrays.sort(reverseGraph);
		for (Node node : reverseGraph) {
			//get the index
			int index = node.index;
			Node actualNodeToBeExplored = vertices[index];
			if(!actualNodeToBeExplored.visited) {
				result++;
				actualNodeToBeExplored.visited = true;
				explore(vertices, actualNodeToBeExplored.neighbours);
			}
		}
		return result;
	}
	private static void explore(Node[] vertices,ArrayList<Integer> neighbors) {
		if(neighbors.isEmpty()) {
			return;
		}
		for (Integer index : neighbors) {
			Node node = vertices[index];
			if(!node.visited) {
				node.visited = true;
				previsit(node);
				explore(vertices, node.neighbours);
				postvisit(node);
			}
		}

	}
	private static void previsit(Node node) {
		//we don't need previsit values here so
		clock += 1;
	}
	private static void postvisit(Node node) {
		node.postVisit = clock;
		clock += 1;
	}
	public static void main(String[] args) {
		int n = 9;
		Node[] vertices = new Node[n];
		Node[] reverseGraph = new Node[n];
		for (int i = 0; i < n; i++) {
			vertices[i] = new Node(i,false,new ArrayList<Integer>());
			reverseGraph[i] = new Node(i,false,new ArrayList<Integer>());
		}
		vertices[0].neighbours.add(1);
		reverseGraph[1].neighbours.add(0);
		vertices[1].neighbours.add(4);
		reverseGraph[4].neighbours.add(1);
		vertices[1].neighbours.add(5);
		reverseGraph[5].neighbours.add(1);
		vertices[2].neighbours.add(1);
		reverseGraph[1].neighbours.add(2);
		vertices[3].neighbours.add(0);
		reverseGraph[0].neighbours.add(3);
		vertices[3].neighbours.add(6);
		reverseGraph[6].neighbours.add(3);
		vertices[4].neighbours.add(0);
		reverseGraph[0].neighbours.add(4);
		vertices[4].neighbours.add(2);
		reverseGraph[2].neighbours.add(4);
		vertices[4].neighbours.add(7);
		reverseGraph[7].neighbours.add(4);
		vertices[6].neighbours.add(7);
		reverseGraph[7].neighbours.add(6);
		vertices[7].neighbours.add(8);
		reverseGraph[8].neighbours.add(7);
		vertices[8].neighbours.add(7);
		reverseGraph[7].neighbours.add(8);
		vertices[8].neighbours.add(5);
		reverseGraph[5].neighbours.add(8);
		//should print 5 ==> Refer SCC.png in the folder 
		System.out.println(numberOfStronglyConnectedComponents(vertices,reverseGraph));
	}
	private static class Node implements Comparable<Node>{
		private int index;
		private boolean visited;
		private ArrayList<Integer> neighbours;
		private int postVisit;

		public Node(int index,boolean visited,ArrayList<Integer> neighbours) {
			this.index = index;
			this.visited = visited;
			this.neighbours = neighbours;
		}

		@Override
		public String toString() {
			return "Node [index=" + index + ", visited=" + visited + ", neighbours=" + neighbours + "]";
		}

		//reverse order postvisit
		@Override
		public int compareTo(Node o) {
			return o.postVisit-this.postVisit;
		}

	}
}

