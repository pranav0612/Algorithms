package com.algo.ds.graph;

import static com.algo.ds.graph.GraphUsingList.*;

import java.util.ArrayList;

import com.algo.ds.graph.GraphUsingList.GraphType;

public class DFS {
	private static int clock = 1;
	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.UNDIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		dfs(graph,null);
	}
	//O(V+E)
	public static void dfs(GraphUsingList graph,Integer source){
		Vertex[] vertices = graph.getVertices();
		//we can also compute connected components using DFS but for now explore in preorder traversal
		Vertex node = null;
		//lets start with the first vertex if source is null
		if(source!=null){
			node = vertices[source];
		}
		else{
			node = vertices[0];
		}
		System.out.print(node.index+" ");
		node.visited = true;
		explore(vertices, node.neighbours);
	}
	private static void explore(Vertex[] vertices,ArrayList<Integer> neighbors){
		if(!neighbors.isEmpty()){
			for (Integer neighborIndex : neighbors) {
				Vertex node = vertices[neighborIndex];
				if(!node.visited){
					node.visited = true;
					System.out.print(node.index+" ");
					explore(vertices, node.neighbours);
				}
			}
		}
	}
	public static void dfsWithPreAndPostVisits(GraphUsingList graph,Integer source){
		clock = 1;
		Vertex[] vertices = graph.getVertices();
		Vertex node = null;
		//lets start with the first vertex if source is null
		if(source!=null){
			node = vertices[source];
		}
		else{
			node = vertices[0];
		}
		node.visited = true;
		node.previsit = ++clock;
		exploreWithPreAndPostVisits(vertices, node.neighbours,node.index);
		node.postvisit = ++clock;
	}
	private static void exploreWithPreAndPostVisits(Vertex[] vertices,ArrayList<Integer> neighbors,int currentParent){
		if(!neighbors.isEmpty()){
			for (Integer neighborIndex : neighbors) {
				Vertex node = vertices[neighborIndex];
				node.parent = currentParent;
				if(!node.visited){
					node.visited = true;
					node.previsit = ++clock;
					exploreWithPreAndPostVisits(vertices, node.neighbours,node.index);
					node.postvisit = ++clock;
				}
			}
		}
	}
}
