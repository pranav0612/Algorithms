package com.algo.ds.graph.problems;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

import com.algo.ds.graph.BFS;
import com.algo.ds.graph.DFS;
import com.algo.ds.graph.GraphUsingList;
import com.algo.ds.graph.GraphUsingList.Edge;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class GraphProblemsB {

	public static void main(String[] args) {
		//check different images in this current folder
		GraphUsingList eulerianPathCircuitGraph = new GraphUsingList(5,GraphType.UNDIRECTED);
		eulerianPathCircuitGraph.addEdge(3,4);
		eulerianPathCircuitGraph.addEdge(0,3);
		eulerianPathCircuitGraph.addEdge(1,0);
		eulerianPathCircuitGraph.addEdge(1,2);
		eulerianPathCircuitGraph.addEdge(2,0);
		checkEulerianPathAndCircuits(eulerianPathCircuitGraph);

		eulerianPathCircuitGraph.resetVerticesVisitedState();
		eulerianPathCircuitGraph.addEdge(0,4);
		checkEulerianPathAndCircuits(eulerianPathCircuitGraph);

		eulerianPathCircuitGraph.resetVerticesVisitedState();
		eulerianPathCircuitGraph.removeEdge(0,4);
		eulerianPathCircuitGraph.addEdge(1,3);
		checkEulerianPathAndCircuits(eulerianPathCircuitGraph);

		eulerianPathCircuitGraph.resetVerticesVisitedState();
		eulerianPathCircuitGraph.removeEdge(3,4);
		System.out.println("The no of connected components : "+getNoOfConnectedComponents(eulerianPathCircuitGraph));

		eulerianPathCircuitGraph.resetVerticesVisitedState();
		System.out.println("The no of connected components using BFS : "+getNoOfConnectedComponentsUsingBFS(eulerianPathCircuitGraph));

		eulerianPathCircuitGraph.resetVerticesVisitedState();
		eulerianPathCircuitGraph.addEdge(3,4);
		System.out.println("The edges constituting spanning tree : "+getSpanningTreeFromGraph(eulerianPathCircuitGraph));

		//lets test it one more time
		GraphUsingList graph1 = new GraphUsingList(6,GraphType.UNDIRECTED);
		graph1.addEdge(0,1);
		graph1.addEdge(2,1);
		graph1.addEdge(2,3);
		graph1.addEdge(3,4);
		graph1.addEdge(3,5);
		graph1.addEdge(5,4);
		System.out.println("The edges constituting spanning tree : "+getSpanningTreeFromGraph(graph1));
		
		graph1.resetVerticesVisitedState();
		System.out.println("Cycle exists in graph1 : "+isCycleInGraph(graph1));
		
		eulerianPathCircuitGraph.resetVerticesVisitedState();
		System.out.println("Cycle exists in eulerianPathCircuitGraph : "+isCycleInGraph(eulerianPathCircuitGraph));
		
		eulerianPathCircuitGraph.resetVerticesVisitedState();
		System.out.println("Cycle exists in cutvertexgraph : "+isCycleInGraphUsingAdjacentNode(eulerianPathCircuitGraph));
		
		//lets see that it works for directed graph.--> the stack based solution will work for directed graph
		GraphUsingList directedgGraph = new GraphUsingList(6,GraphType.DIRECTED);
		directedgGraph.addEdge(0,1);
		directedgGraph.addEdge(2,1);
		directedgGraph.addEdge(2,3);
		directedgGraph.addEdge(3,4);
		directedgGraph.addEdge(3,5);
		directedgGraph.addEdge(5,4);
		System.out.println("Cycle exists in directedgGraph : "+isCycleInGraph(directedgGraph));
		
		//lets create a cycle by adding edge and test
		directedgGraph.addEdge(1, 2);
		directedgGraph.resetVerticesVisitedState();
		System.out.println("Cycle exists in directedgGraph : "+isCycleInGraph(directedgGraph));
		
	}
	private static void checkEulerianPathAndCircuits(GraphUsingList graph){
		//check the connectivity of the graph using DFS
		DFS.dfs(graph, null);
		System.out.println();
		//check if any node is unvisited
		for (Vertex vertex : graph.getVertices()) {
			if(!vertex.visited){
				System.out.println("The graph is not eulerian");
				return;
			}
		}
		//check the no of odd neighbors in each vertex
		int oddVertexCount = 0; 
		for (Vertex vertex : graph.getVertices()) {
			if(vertex.neighbours.size() % 2!=0){
				oddVertexCount++;
			}
		}
		if(oddVertexCount>2){
			System.out.println("The graph is not eulerian");
			return;
		}
		else if(oddVertexCount == 2){
			System.out.println("The graph contains a eulerian path");
			return;
		}
		// Note that odd count can never be 1 for undirected graph
		else{
			System.out.println("The graph contains a eulerian circuit");
		}
	}
	private static int getNoOfConnectedComponents(GraphUsingList graph){
		int result = 0;
		for (Vertex vertex : graph.getVertices()) {
			if(!vertex.visited){
				DFS.dfs(graph,vertex.index);
				System.out.println();
				result++;
			}
		}
		return result;
	}
	private static int getNoOfConnectedComponentsUsingBFS(GraphUsingList graph){
		int result = 0;
		for (Vertex vertex : graph.getVertices()) {
			if(!vertex.visited){
				BFS.bfs(graph,vertex.index);
				System.out.println();
				result++;
			}
		}
		return result;
	}
	private static List<Edge> getSpanningTreeFromGraph(GraphUsingList graph){
		List<Edge> result = new ArrayList<>();

		//we can use BFS to find the tree
		Queue<Vertex> queue = new LinkedList<>();

		//lets start with 0th node, add it to queue
		Vertex[] vertices = graph.getVertices();
		vertices[0].visited = true;
		queue.add(vertices[0]);

		//iterate
		while (!queue.isEmpty()) {
			Vertex parent = queue.remove();

			for (Integer neighborIndex : parent.neighbours) {
				Vertex neighborNode = vertices[neighborIndex];
				//add all neighbors to result if the node was not visited
				if(!neighborNode.visited){
					result.add(new Edge(parent.index, neighborIndex,0));
					neighborNode.visited = true;
					queue.offer(neighborNode);
				}
			}
		}
		return result;
	}
	//maintain a stack to check whether a visited node is again visited during it's own explore
	private static Stack<Integer> nodeStack = new Stack<>();

	private static boolean isCycleInGraph(GraphUsingList graph) {
		nodeStack.clear();
		Vertex[] vertices = graph.getVertices();
		for (int i = 0; i < vertices .length; i++) {
			if(!vertices[i].visited) {
				vertices[i].visited = true;
				nodeStack.push(vertices[i].index);
				if(exploreToFindCycle(vertices, vertices[i].neighbours)){
					return true;
				}
				nodeStack.pop();
			}
		}
		return false;
	}
	private static boolean exploreToFindCycle(Vertex[] vertices, ArrayList<Integer> neighbours) {
		if(!neighbours.isEmpty()){
			for (Integer neighborIndex : neighbours) {
				Vertex node = vertices[neighborIndex];
				if(nodeStack.contains(node.index)) {
					return true;
				}
				else if(!node.visited){
					node.visited = true;
					nodeStack.push(node.index);
					if(exploreToFindCycle(vertices, node.neighbours)){
						return true;
					}
					nodeStack.pop();
				}
			}
		}
		return false;
	}
	//if an adjacent node is already visited and it's parent is not
	//This will also work for directed graph
	private static boolean isCycleInGraphUsingAdjacentNode(GraphUsingList graph){
		Vertex[] vertices = graph.getVertices();
		for (int i = 0; i < vertices .length; i++) {
			if(!vertices[i].visited){
				vertices[i].visited = true;
				if(exploreToFindCycleUsingAdjacentNode(vertices,i)){
					return true;
				}
			}
		}
		return false;
	}
	private static boolean exploreToFindCycleUsingAdjacentNode(Vertex[] vertices,int currentNodeIndex){
		Vertex currentNode = vertices[currentNodeIndex];
		currentNode.visited = true;
		
		for (Integer neighborIndex : currentNode.neighbours) {
			Vertex neighborNode = vertices[neighborIndex];
			if(!neighborNode.visited){
				neighborNode.parent = currentNodeIndex;
				if(exploreToFindCycleUsingAdjacentNode(vertices, neighborIndex)){
					return true;
				}
			}
			//now the main logic--> check the parent, if it's same or not
			else{
				if(neighborNode.parent!=null && neighborNode.parent != currentNodeIndex){
					return true;
				}
			}
		}
		return false;
	}
}
