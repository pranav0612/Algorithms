package com.algo.ds.graph.problems;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.graph.GraphUsingList;
import com.algo.ds.graph.GraphUsingList.Flag;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class GraphProblemsD {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		System.out.println("Graph is bpartite : "+isGraphBipartite(graph));
	}
	private static boolean isGraphBipartite(GraphUsingList graph){
		boolean isBipartite = true;
		Vertex[] vertices = graph.getVertices();
		Queue<Vertex> queue = new LinkedList<>();
		
		//start with first node and initialize with black
		Vertex source = vertices[0];
		source.flag = Flag.BLACK;
		queue.add(source);
		
		while (!queue.isEmpty()) {
			Vertex node = queue.remove();
			if(!node.visited) {
				node.visited = true;
				//check each adjacent node whether it is of opposite color or not
				for (int index : node.neighbours) {
					if(vertices[index].flag.equals(node.flag)) {
						isBipartite = false;
						break;
					}
					else {
						vertices[index].flag = getOppositeFlag(node.flag);
						queue.add(vertices[index]);
					}
				}
				if(!isBipartite){
					break;
				}
			}

		}
		return isBipartite;
	}
	private static Flag getOppositeFlag(Flag flag) {
		if(flag.equals(Flag.BLACK)) {
			return Flag.WHITE;
		}
		else {
			return Flag.BLACK;
		}
	}
}
