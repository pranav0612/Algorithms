package com.algo.ds.graph.problems;

import java.util.ArrayList;
import java.util.List;

import com.algo.ds.graph.DFS;
import com.algo.ds.graph.GraphUsingList;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class GraphsProblemsA {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		System.out.println("Is path possible between 1 and 6 : "+isPathPossible(graph, 1, 6));
		graph.resetVerticesVisitedState();
		System.out.println("Is path possible between 3 and 6 : "+isPathPossible(graph, 3, 6));
		graph.resetVerticesVisitedState();
		
		GraphUsingList graph1 = new GraphUsingList(4,GraphType.DIRECTED);
		graph1.addEdge(0,1);
		graph1.addEdge(2,0);
		graph1.addEdge(0,2);
		graph1.addEdge(2,1);
		graph1.addEdge(1,3);
		graph1.addEdge(0,3);
		System.out.println("No of paths from 2 and 3 : "+getNoOfSimplePaths(graph1, 2, 3));
		
		DFSNode[] vertices = createDfsNodeGraph();
		System.out.println("The cut vertives are "+getCutVerticesOfGraph(vertices));
		resetVertices(vertices);
		System.out.println("The cut edges of the graph are : "+getBridgesInGraph(vertices));
	}
	private static DFSNode[] createDfsNodeGraph() {
		//see the cutvertices.png file
		DFSNode[] vertices = new DFSNode[8];
		for (int i = 0; i < vertices.length; i++) {
			vertices[i] = new DFSNode(i, new ArrayList<>());
		}
		vertices[0].neighbors.add(2);
		vertices[0].neighbors.add(4);
		vertices[2].neighbors.add(3);
		vertices[2].neighbors.add(0);
		vertices[2].neighbors.add(1);
		vertices[1].neighbors.add(2);
		vertices[1].neighbors.add(3);
		vertices[3].neighbors.add(2);
		vertices[3].neighbors.add(1);
		vertices[4].neighbors.add(0);
		vertices[4].neighbors.add(7);
		vertices[4].neighbors.add(5);
		vertices[5].neighbors.add(4);
		vertices[5].neighbors.add(7);
		vertices[5].neighbors.add(6);
		vertices[7].neighbors.add(4);
		vertices[7].neighbors.add(5);	
		vertices[6].neighbors.add(5);
		return vertices;
	}
	private static void resetVertices(DFSNode[] vertices) {
		//reset the graph first
		for (DFSNode dfsNode : vertices) {
			dfsNode.visited = false;
			dfsNode.parent = null;
			dfsNode.discoveryTime = 0;
			dfsNode.lowTime = 0;
		}
	}
	public static boolean isPathPossible(GraphUsingList graph,int source,int target){
		//run a DFS with the source,if target is reachable then it will be visited
		DFS.dfs(graph, source);
		System.out.println();
		return graph.getVertices()[target].visited;
	}
	static int noOfSimplePaths = 0;
	static int time = 0;
	//modify the DFS to count the paths
	public static int getNoOfSimplePaths(GraphUsingList graph,int source,int target) {
		noOfSimplePaths = 0;
		//start with the source
		if(source == target){
			noOfSimplePaths++;
		}
		Vertex sourceNode = graph.getVertices()[source];
		sourceNode.visited = true;
		explore(graph.getVertices(), sourceNode.neighbours, target);
		return noOfSimplePaths;
	}
	private static void explore(Vertex[] vertices,ArrayList<Integer> neighbors,int target){
		if(!neighbors.isEmpty()){
			for (Integer neighborIndex : neighbors) {
				//we have encountered our target so increase the count
				if(target == neighborIndex){
					noOfSimplePaths++;
				}
				Vertex neighbor = vertices[neighborIndex];
				if(!neighbor.visited){
					neighbor.visited = true;
					explore(vertices,neighbor.neighbours, target);
					//this is the hack. After exploring the vertex we are making it unvisited. :)
					neighbor.visited = false;
				}
			}
		}
	}
	//O(E+V) --> Tarjan's algorithm
	private static List<DFSNode> getCutVerticesOfGraph(DFSNode[] vertices){
		List<DFSNode> cutVertices = new ArrayList<>();
		time = 0;
		//iterate over all vertices to check the cut vertices in all connected components.
		for (int i = 0; i < vertices.length; i++) {
			if(!vertices[i].visited){
				exploreToFindCutVertices(vertices, cutVertices, i);
			}
		}
		return cutVertices;
	}
	private static void exploreToFindCutVertices(DFSNode[] vertices,List<DFSNode> cutVertices,int currentNodeIndex){
		//count the children for the current DFS tree
		int children = 0;
		DFSNode currentParent = vertices[currentNodeIndex];
		
		//mark it as visited
		currentParent.visited = true;
		
		//Initialize variables of the current parent, initially low and discovery time will be same, we will update low time
		currentParent.discoveryTime = currentParent.lowTime = ++time;
		
		//explore the neighbors which will also include the parent itself so check is there in else
		for (int neighborIndex : currentParent.neighbors) {
			DFSNode neighborNode = vertices[neighborIndex];
			
			// If neighborNode is not visited yet, then make it a child of currentParent in DFS tree and recur for it
			if(!neighborNode.visited) {
				children++;//increment the children counter as this neighbor is not visited so this is a independent child
				neighborNode.parent = currentParent.index; //make the parent
				
				//now explore this node
				exploreToFindCutVertices(vertices, cutVertices, neighborIndex);
				
				//update the lowTime for the current Node
				currentParent.lowTime = Math.min(currentParent.lowTime,neighborNode.lowTime);
				
				//now have 2 checks
				//check for the root node if it's having more than 1 independent children
				if(currentParent.parent==null && children>1){
					cutVertices.add(currentParent);
				}
				
				//now check for back edge. if back edge doesn't exist then add the current vertex to list
				if(currentParent.parent!=null && currentParent.discoveryTime <= neighborNode.lowTime){
					cutVertices.add(currentParent);
				}
				
			}
			//very important: this neighbor is visited that means we have 2 cases
			//1. this is the parent of currentParent
			//2. this is some other node. so this is a back edge. hence we have to update lowTime
			else{
				//if some other node, then update the lowTime for the currentParent--> so back edge exists.
				if(currentParent.parent != neighborIndex) {
					currentParent.lowTime = Math.min(currentParent.lowTime,neighborNode.discoveryTime);
				}
			}
		}
	}
	private static List<DFSEdge> getBridgesInGraph(DFSNode[] vertices) {
		time = 0;
		List<DFSEdge> cutEdges = new ArrayList<>();
		//iterate over all vertices to check the cut vertices in all connected components.
		for (int i = 0; i < vertices.length; i++) {
			if(!vertices[i].visited){
				exploreToFindCutEdges(vertices, cutEdges, i);
			}
		}
		return cutEdges;
	}
	private static void exploreToFindCutEdges(DFSNode[] vertices,List<DFSEdge> cutEdges,int currentNodeIndex){
		//count the children for the current DFS tree
		DFSNode currentParent = vertices[currentNodeIndex];
		
		//mark it as visited
		currentParent.visited = true;
		
		//Initialize variables of the current parent, initially low and discovery time will be same, we will update low time
		currentParent.discoveryTime = currentParent.lowTime = ++time;
		
		//explore the neighbors which will also include the parent itself so check is there in else
		for (int neighborIndex : currentParent.neighbors) {
			DFSNode neighborNode = vertices[neighborIndex];
			
			// If neighborNode is not visited yet, then make it a child of currentParent in DFS tree and recur for it
			if(!neighborNode.visited) {
				neighborNode.parent = currentParent.index; //make the parent
				
				//now explore this node
				exploreToFindCutEdges(vertices, cutEdges, neighborIndex);
				
				//update the lowTime for the current Node
				currentParent.lowTime = Math.min(currentParent.lowTime,neighborNode.lowTime);
				
				//If the lowest vertex reachable from subtree under neighborNode is below currentParent in DFS tree, then currentParent-neighborNode is a bridge
				if(currentParent.discoveryTime < neighborNode.lowTime){
					cutEdges.add(new DFSEdge(currentNodeIndex, neighborIndex));
				}
				
			}
			//very important: this neighbor is visited that means we have 2 cases
			//1. this is the parent of currentParent
			//2. this is some other node. so this is a back edge. hence we have to update lowTime
			else{
				//if some other node, then update the lowTime for the currentParent--> so back edge exists.
				if(currentParent.parent != neighborIndex) {
					currentParent.lowTime = Math.min(currentParent.lowTime,neighborNode.discoveryTime);
				}
			}
		}
	}
	public static class DFSNode {
		public int index;
		public boolean visited;
		public Integer parent;
		// if node's parent is removed, what is the lowest level node can climb to. This level is lowTime
		public int lowTime;
		public int discoveryTime;
		public ArrayList<Integer> neighbors;
		
		public DFSNode(int index,ArrayList<Integer> neighbors) {
			this.index = index;
			this.neighbors = neighbors;
		}

		@Override
		public String toString() {
			return  index+"";
		}
	}
	private static class DFSEdge {
		public DFSEdge(int startIndex,int endIndex) {
			this.startIndex = startIndex;
			this.endIndex = endIndex;
		}
		private int startIndex;
		private int endIndex;
		
		@Override
		public String toString() {
			return  startIndex+"-->"+endIndex;
		}
	}
}
