package com.algo.ds.graph.problems;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.algo.ds.graph.GraphUsingList;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;
import com.algo.ds.graph.TopologicalSorting;

public class GraphProblemsC {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		System.out.println("The depth of the graph is : "+getDepthOfDAG(graph,3));
		
		graph.resetVerticesVisitedState();
		System.out.println("Hamiltonian path exist for the graph : "+isHamilotianPathExists(graph));
		
		//refer 
		GraphUsingList graphWithHamiltonianPath = new GraphUsingList(6,GraphType.DIRECTED);
		graphWithHamiltonianPath.addEdge(1,0);
		graphWithHamiltonianPath.addEdge(1,2);
		graphWithHamiltonianPath.addEdge(0,2);
		graphWithHamiltonianPath.addEdge(2,3);
		graphWithHamiltonianPath.addEdge(3,4);
		graphWithHamiltonianPath.addEdge(3,5);
		graphWithHamiltonianPath.addEdge(4,5);
		System.out.println("Hamiltonian path exist for the graphWithHamiltonianPath : "+isHamilotianPathExists(graphWithHamiltonianPath));
	}
	//Do a BFS, use a marker element in queue. Null will do the job
	private static int getDepthOfDAG(GraphUsingList graph,int sourceVertex){
		Vertex[] vertices = graph.getVertices();
		int result = 0;
		
		Vertex source = vertices[sourceVertex];
		source.visited = true;
		Queue<Vertex> queue = new LinkedList<>();
		queue.offer(source);
		
		//mark the end of level 0
		queue.offer(null);
		
		while (!queue.isEmpty()) {
			Vertex node = queue.remove();
			//check for our marker element which marks end of a level
			if(node==null){
				//a level ends
				result++;
				//this is check whether we are out of elements
				if(!queue.isEmpty()){
					queue.offer(null);
				}
			}
			else{
				for (Integer neighborIndex : node.neighbours) {
					Vertex neighbor = vertices[neighborIndex];
					if(!neighbor.visited){
						neighbor.visited = true;
						queue.offer(neighbor);
					}
				}
			}
		}
		//its calculating the levels not depth
		return result-1;
	}
	//let's do a topological sort and then check each consecutive vertices if all of them form edges then hamiltonian path exist
	private static boolean isHamilotianPathExists(GraphUsingList graph){
		List<Integer> topologicalSorts = TopologicalSorting.topologicalSort(graph);
		Vertex[] vertices = graph.getVertices();
		//check that edges exists between consecutive elements of list
		for (int i = 0; i < topologicalSorts.size()-1; i++) {
			Vertex currentVertex = vertices[topologicalSorts.get(i)];
			if(!currentVertex.neighbours.contains(topologicalSorts.get(i+1))){
				return false;
			}
		}
		//printing the path
		for (Integer nodeIndex : topologicalSorts) {
			System.out.print(nodeIndex+"-->");
		}
		System.out.println("null");
		return true;
	}
}
