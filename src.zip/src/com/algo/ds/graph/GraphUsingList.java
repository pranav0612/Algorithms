package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.List;


public class GraphUsingList {

	public enum GraphType{
		DIRECTED,UNDIRECTED;
	}

	Vertex[] vertices =  null;
	//used in case of bellman-ford
	List<Edge> edges = new ArrayList<>();
	GraphType graphType;

	public GraphUsingList(int noOfVertices,GraphType graphType) {
		this.graphType = graphType;
		this.vertices = new Vertex[noOfVertices];
		for (int i = 0; i < vertices.length; i++) {
			vertices[i] = new Vertex(i,new ArrayList<>());
			vertices[i].flag = Flag.NOCOLOR;
		}
	}
	public enum Flag {
		NOCOLOR,WHITE,BLACK
	}
	public static class Vertex{
		public int index;
		public boolean visited;
		public ArrayList<Integer> neighbours;
		public int distanceFromSource;
		public Integer parent;
		public int inDegree;
		public int previsit;
		public int postvisit;
		public Flag flag;

		public Vertex(int index,ArrayList<Integer> neighbours) {
			this.index = index;
			this.neighbours = neighbours;
			this.visited = false;
			this.distanceFromSource = Integer.MAX_VALUE;
		}

		@Override
		public String toString() {
			return "Node [index=" + index + ", visited=" + visited + ", neighbours=" + neighbours + "]";
		}

	}
	public static class Edge implements Comparable<Edge>{
		int startIndex;
		int endIndex;
		int weight;

		public Edge(int startIndex, int endIndex, int weight) {
			this.startIndex = startIndex;
			this.endIndex = endIndex;
			this.weight = weight;
		}
		@Override
		public String toString() {
			if(weight==0){
				return startIndex+"---"+endIndex;
			}
			return startIndex+"===("+weight+")==="+endIndex;
		}
		@Override
		public int compareTo(Edge o) {
			return this.weight-o.weight;
		}
	}
	public void addEdge(int source,int destination){
		if(validRange(source) && validRange(destination)){
			vertices[source].neighbours.add(destination);
			vertices[destination].inDegree++;
			if(graphType.equals(GraphType.UNDIRECTED)){
				vertices[destination].neighbours.add(source);
				vertices[source].inDegree++;
			}
		}
	}
	public void addWeightedEdge(int source,int destination,int weight){
		if(validRange(source) && validRange(destination)){
			vertices[source].neighbours.add(destination);
			if(graphType.equals(GraphType.UNDIRECTED)){
				vertices[destination].neighbours.add(source);
			}
			edges.add(new Edge(source, destination, weight));
		}
	}
	public  void resetVerticesVisitedState(){
		for (Vertex vertex : vertices) {
			vertex.visited = false;
		}
	}
	public void removeEdge(int source,int destination){
		if(validRange(source) && validRange(destination)){
			vertices[source].neighbours.remove(new Integer(destination));
			if(graphType.equals(GraphType.UNDIRECTED)){
				vertices[destination].neighbours.remove(new Integer(source));
			}
		}
	}
	private boolean validRange(int i){
		if(i>=0 && i<vertices.length){
			return true;
		}
		return false;
	}
	public Vertex[] getVertices() {
		return vertices;
	}
}
