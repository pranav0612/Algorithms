package com.algo.ds.graph;

import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class BFS {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.UNDIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		bfs(graph,3);
	}

	public static void bfs(GraphUsingList graph,Integer sourceIndex) {
		//lets start with top node.
		Vertex[] vertices = graph.getVertices();
		Vertex source = null;
		if(sourceIndex!=null){
			source = vertices[sourceIndex];
		}
		else{
			source = vertices[0];
		}
		source.visited = true;
		Queue<Vertex> queue = new LinkedList<>();
		queue.offer(source);
		
		while (!queue.isEmpty()) {
			Vertex node = queue.poll();
			System.out.print(node.index+" ");
			
			for (int neighborIndex : node.neighbours) {
				Vertex neighbor = vertices[neighborIndex];
				
				if(!neighbor.visited){
					neighbor.visited = true;
					queue.offer(neighbor);
				}
			}
		}
	}
}
