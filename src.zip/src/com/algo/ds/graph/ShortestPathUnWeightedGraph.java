package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

//this will work for both directed and undirected graph
public class ShortestPathUnWeightedGraph {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addEdge(3,1);
		graph.addEdge(3,5);
		graph.addEdge(1,0);
		graph.addEdge(1,2);
		graph.addEdge(5,4);
		graph.addEdge(5,6);
		System.out.println(calculateDistanceUsingBFS(graph, 3, 0));
	}
	public static int calculateDistanceUsingBFS(GraphUsingList graph,int sourceIndex,int targetIndex){
		int result = -1;
		Vertex[] vertices = graph.vertices;
		if(sourceIndex == targetIndex){
			return 0;
		}
		//get the source vertex
		Vertex source = vertices[sourceIndex];
		//distance will be 0 for source
		source.distanceFromSource = 0;
		source.visited = true;
		//make queue
		Queue<Vertex> queue =  new LinkedList<Vertex>();
		queue.offer(source);
		while (!queue.isEmpty()) {
			Vertex node = queue.poll();
			if(node.index == targetIndex) {
				result =  node.distanceFromSource;
				break;
			}
			if(!node.neighbours.isEmpty()){
				ArrayList<Integer> neighbors =  node.neighbours;
				for (Integer neighborIndex : neighbors) {
					Vertex neighbor = vertices[neighborIndex];
					if(!neighbor.visited){
						neighbor.visited = true;
						neighbor.distanceFromSource = node.distanceFromSource+1;
						queue.offer(neighbor);
					}
				}
			}
		}
		return result;
	}
}
