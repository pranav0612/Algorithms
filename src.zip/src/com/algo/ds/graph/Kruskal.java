package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.algo.ds.disjointsets.DisjointSetWithTrees;
import com.algo.ds.disjointsets.DisjointSetWithTrees.Node;
import com.algo.ds.graph.GraphUsingList.Edge;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class Kruskal {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(9,GraphType.UNDIRECTED);//Refer the graphforspanningtree.png
		graph.addWeightedEdge(0,1,2);
		graph.addWeightedEdge(0,3,4);
		graph.addWeightedEdge(0,2,1);
		graph.addWeightedEdge(1,2,3);
		graph.addWeightedEdge(2,3,5);
		graph.addWeightedEdge(3,5,8);
		graph.addWeightedEdge(3,4,6);
		graph.addWeightedEdge(5,4,1);
		graph.addWeightedEdge(2,4,9);
		System.out.println(getMinimumSpanningTreeByKruskals(graph));
	}
	//returning the list of edges as spanning tree is enough
	public static List<Edge> getMinimumSpanningTreeByKruskals(GraphUsingList graph){
		Vertex[] vertices = graph.vertices;
		List<Edge> edges = graph.edges;
		
		//we will make a collection of disjoint sets nodes and later use them and merge them
		DisjointSetWithTrees disjointSet = new DisjointSetWithTrees();
		List<Node> nodes = new ArrayList<>();
		
		//iterate over vertices to make individual disjoint sets.
		for (int i = 0; i < vertices.length; i++) {
			nodes.add(disjointSet.new Node(vertices[i].index));//Note that index of the disjoint set node in list is same as vertex in vertices array so it will be easy to access the corresponding node and vice versa
		}
		List<Edge> result = new ArrayList<>();
		
		//now sort the edges 
		Collections.sort(edges);
		
		//iterate over edges in increasing order of weights
		for (Edge edge : edges) {
			
			//grab the nodes from disjoint sets using indexes.
			Node startNode = nodes.get(edge.startIndex);
			Node endNode = nodes.get(edge.endIndex);
			
			//if the nodes are in different, that mean they are in different tree and will not make cycle
			//so add this to result
			if(startNode.getParent() != endNode.getParent()){
				result.add(edge);
				disjointSet.union(startNode, endNode);
			}
		}
		return result;
	}
}
