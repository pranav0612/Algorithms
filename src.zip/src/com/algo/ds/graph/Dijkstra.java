package com.algo.ds.graph;

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Queue;

//we have to find only this distance so we are not worried of the actual tracing of path. For tracing the path use another field in Node class called previous
//element and update it when distance is updated.
public class Dijkstra {
	public static int getDistance(Node[] vertices,int s, int t) {
		if(s == t){
    		return 0;
    	}
		//using priority queue to maintain to store unprocessed nodes
		Queue<Node> queue = new PriorityQueue<Node>();
		//add the start node to the queue
		vertices[s].distanceFromSource = 0; //as it is the source
		vertices[s].visited = true;
		queue.add(vertices[s]);
		//iterate over the queue until it's not empty
		while (!queue.isEmpty()) {
			//take out the node with highest priority or lowest distance value
			Node node = queue.remove();
			//relax all edges of the node and add only unvisited nodes to the queue
			int priorityOfNeighbour = node.priority + 1;
			for (int i=0;i<node.neighbours.size(); i++) {
				//get all variables
				int neighbourIndex = node.neighbours.get(i);
				int neighbourWeight = node.weights.get(i);
				Node neighbourNode = vertices[neighbourIndex];
				
				//relax it's edge
				if(neighbourNode.distanceFromSource > (node.distanceFromSource + neighbourWeight)) {
					neighbourNode.distanceFromSource = node.distanceFromSource + neighbourWeight;
					//make it unvisited as we have to process it again.
					neighbourNode.visited = false;
				}
				neighbourNode.priority = priorityOfNeighbour;
				if(!neighbourNode.visited){
					//make the node visited
					neighbourNode.visited = true;
					queue.add(neighbourNode);
				}
			}
			
		}
		//check for the target node
		if(vertices[t].distanceFromSource != Integer.MAX_VALUE) {
			return vertices[t].distanceFromSource;
		}
		//target node unreachable
		return -1;
	}

	public static void main(String[] args) {
		int n = 9;
		Node[] vertices = new Node[n];
		for (int i = 0; i < n; i++) {
			vertices[i] = new Node(i,false,new ArrayList<Integer>(),new ArrayList<Integer>(),Integer.MAX_VALUE,0);
		}
		vertices[0].neighbours.add(1);
		vertices[0].neighbours.add(3);
		vertices[0].neighbours.add(4);
		vertices[0].weights.add(2);
		vertices[0].weights.add(2);
		vertices[0].weights.add(2);
		
		vertices[1].neighbours.add(4);
		vertices[1].neighbours.add(5);
		vertices[1].weights.add(2);
		vertices[1].weights.add(2);
		
		vertices[2].neighbours.add(1);
		vertices[2].weights.add(2);
		
		vertices[3].neighbours.add(6);
		vertices[3].weights.add(2);
		
		vertices[4].neighbours.add(2);
		vertices[4].neighbours.add(7);
		vertices[4].weights.add(2);
		vertices[4].weights.add(2);
		
		vertices[6].neighbours.add(7);
		vertices[6].weights.add(2);
		
		vertices[7].neighbours.add(8);
		vertices[7].weights.add(2);
		
		vertices[8].neighbours.add(7);
		vertices[8].neighbours.add(5);
		vertices[8].weights.add(2);
		vertices[8].weights.add(2);
		
		System.out.println(getDistance(vertices,0,7));
	}
	//we haven't used the graphusinglist class as the node's compareTo is different
	private static class Node implements Comparable<Node>{
		private int index;
		private boolean visited;
		private ArrayList<Integer> neighbours;
		private ArrayList<Integer> weights;
		private int distanceFromSource;
		private int priority;

		public Node(int index,boolean visited,ArrayList<Integer> neighbours,ArrayList<Integer> weights,int distanceFromSource,int priority) {
			this.index = index;
			this.visited = visited;
			this.neighbours = neighbours;
			this.weights = weights;
			this.distanceFromSource = distanceFromSource;
			this.priority = priority;
		}
		
		@Override
		public String toString() {
			return "Node [index=" + index + ", visited=" + visited + ", neighbours=" + neighbours + ", weights="
					+ weights + ", distanceFromSource=" + distanceFromSource + ", priority=" + priority + "]";
		}

		@Override
		public int compareTo(Node o) {
			//first check priority, if the priority is same then consider distance.
			//we have included priority because the queue was storing all nodes and only current neighbor nodes should be processed first rather than previous neighbor
			//we are maintaining order from LOW -> HIGH
			if(o.priority > this.priority) {
				return 1;
			}
			else if(o.priority < this.priority) {
				return -1;
			}
			else {
				return this.distanceFromSource - o.distanceFromSource;
			}
		}
	}
}

