package com.algo.ds.graph;

import java.util.List;

import com.algo.ds.graph.GraphUsingList.Edge;
import com.algo.ds.graph.GraphUsingList.GraphType;
import com.algo.ds.graph.GraphUsingList.Vertex;

public class BellmanFord {

	public static void main(String[] args) {
		GraphUsingList graph = new GraphUsingList(7,GraphType.DIRECTED);
		graph.addWeightedEdge(3,1,1);
		graph.addWeightedEdge(3,5,7);
		graph.addWeightedEdge(1,0,-1);
		graph.addWeightedEdge(1,2,2);
		graph.addWeightedEdge(5,4,3);
		graph.addWeightedEdge(5,6,-6);
		bellmanFord(graph,3);
		System.out.println("The distance between 3 and 6 is : "+graph.vertices[6].distanceFromSource);
	}
	public static boolean bellmanFord(GraphUsingList graph,int source) {
		Vertex[] vertices = graph.vertices;
		List<Edge> edges = graph.edges;
		boolean allIterationsNotCompleted = false;
		//mark source as visited and distance  0
		vertices[source].distanceFromSource = 0;
		//iterate over the nodes until the distance of node is changing and not iterate more than no of vertices-1 times.
		for (int i = 1; i < vertices.length-1; i++) {
			boolean anyEdgeRelaxed = false;
			for (Edge edge : edges) {
				boolean result = relaxEdge(vertices, edge);
				if(result) {
					anyEdgeRelaxed = true;
				}
			}
			//break early if no edge is getting relaxed
			if(!anyEdgeRelaxed) {
				allIterationsNotCompleted = true;
				break;
			}
		}
		return allIterationsNotCompleted;
	}
	private static boolean relaxEdge(Vertex[] vertices,Edge edge) {
		boolean edgeRelaxed = false;
		if(vertices[edge.startIndex].distanceFromSource!=Integer.MAX_VALUE && 
				vertices[edge.endIndex].distanceFromSource > vertices[edge.startIndex].distanceFromSource + edge.weight) {
			vertices[edge.endIndex].distanceFromSource = vertices[edge.startIndex].distanceFromSource + edge.weight;
			edgeRelaxed = true;
		}
		return edgeRelaxed;
	}
	
}
