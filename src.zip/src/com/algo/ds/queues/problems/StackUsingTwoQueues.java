package com.algo.ds.queues.problems;

import java.util.LinkedList;
import java.util.Queue;

public class StackUsingTwoQueues {

	//strategy is to keep at one queue empty and while pushing push to one which is not empty and while popping transfer n-1
	//elements to empty queue and remove the last element from non empty queue and empty it. O(n) is pop
	private Queue<Integer> queue1 = new LinkedList<>();
	private Queue<Integer> queue2 = new LinkedList<>();
	
	public boolean isEmpty(){
		if(queue1.isEmpty() && queue2.isEmpty()) {
			return true;
		}
		return false;
	}
	public void push(int data){
		if (queue1.isEmpty()) {
			queue2.offer(data);
		}
		else {
			queue1.offer(data);
		}
	}
	//O(n)
	public int pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stack underflow!");
		}
		int size = 0;
		int i = 0;
		if(queue1.isEmpty()) {
			size = queue2.size();
			while(i<size-1) {
				queue1.offer(queue2.poll());
				i++;
			}
			return queue2.poll();
		}
		else{
			size = queue1.size();
			while(i<size-1) {
				queue2.offer(queue1.poll());
				i++;
			}
			return queue1.poll();
		}
	}
}
