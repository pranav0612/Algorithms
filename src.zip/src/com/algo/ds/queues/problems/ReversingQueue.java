package com.algo.ds.queues.problems;

import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class ReversingQueue {

	public static void main(String[] args) {
		Queue<Integer> queue = new ArrayDeque<>();//we can use ArrayDeque instead of Linked List as this is fast.
		queue.offer(1);
		queue.offer(2);
		queue.offer(3);
		queue.offer(4);
		queue.offer(5);
		queue.offer(6);
		queue.offer(7);
		System.out.println("Queue: "+queue+" After reversing :"+reverseQueue(queue));
	}
	private static Queue<Integer> reverseQueue(Queue<Integer> queue){
		Stack<Integer> stack = new Stack<>();
		while (!queue.isEmpty()) {
			stack.push(queue.poll());
		}
		while (!stack.isEmpty()) {
			queue.offer(stack.pop());
		}
		return queue;
	}


}
