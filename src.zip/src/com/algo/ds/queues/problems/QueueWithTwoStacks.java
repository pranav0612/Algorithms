package com.algo.ds.queues.problems;

import java.util.Stack;

public class QueueWithTwoStacks {
	
	private Stack<Integer> stack1 = new Stack<>();
	private Stack<Integer> stack2 = new Stack<>();
	
	public void enqueue(int data){
		stack1.push(data);
	}
	public boolean isEmpty() {
		if(stack2.isEmpty() && stack1.isEmpty()) {
			return true;
		}
		return false;
	}
	public int dequeue() throws Exception{
		if(isEmpty()) {
			throw new Exception("Queue is empty!");
		}
		if(!stack2.isEmpty()) {
			return stack2.pop();
		}
		else {
			while (!stack1.isEmpty()) {
				stack2.push(stack1.pop());
			}
			return stack2.pop();
		}
	}
}
