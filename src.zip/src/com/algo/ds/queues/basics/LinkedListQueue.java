package com.algo.ds.queues.basics;

import com.algo.ds.common.Node;

public class LinkedListQueue {

	private Node front;
	private Node rear;
	
	public boolean isEmpty(){
		return front == null;
	}
	//add to rear
	public void enqueue(int data){
		Node node = new Node(data);
		if(isEmpty()){
			front = node;
			rear = node;
		}
		else {
			rear.setNext(node);
			rear = node;
		}
	}
	//remove from front
	public int dequeue() throws Exception{
		if(isEmpty()){
			throw new Exception("Queue is empty!");
		}
		else {
			Node node = front;
			front = front.getNext();
			return node.getData();
		}
	}
}
