package com.algo.ds.queues.basics;

public class CircularArrayQueue {
	
	private int front;
	private int rear;
	private int[] array;
	private int capacity;

	public CircularArrayQueue(int size) {
		this.front = -1;
		this.rear = -1;
		this.array = new int[size];
		this.capacity = size;
	}
	public boolean isEmpty(){
		//front was -1 when dequeue was done at last element
		return (front ==-1);
	}
	public boolean isFull() {
		//circular array, so if it is full increasing rear will reach to front.
		return ((rear+1)%capacity == front);
	}
	public int getQueueSize() {
		if(isEmpty()) {
			return 0;
		}
		else{
			int size  = (capacity +rear-front+1)%capacity;
			if(size == 0){
				return capacity;
			}
			else{
				return size;
			}
		}
	}
	//increase rear in enqueue
	public void enqueue(int data) throws Exception {
		if(isFull()){
			throw new Exception("Queue is full");
		}
		rear = (rear+1)%capacity;
		array[rear] = data;
		if(front==-1){
			front = rear;
		}
	}
	//increase front in dequeue
	public int dequeu() throws Exception{
		if(isEmpty()){
			throw new Exception("Queue is empty");
		}
		int data = array[front];
		if(front == rear){
			//only one element is there so reset queue
			front = rear =-1;
		}
		else{
			front = (front +1)%capacity;
		}
		return data;
	}
	
}
