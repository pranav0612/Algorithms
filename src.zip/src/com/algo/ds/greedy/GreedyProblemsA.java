package com.algo.ds.greedy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class GreedyProblemsA {

	public static void main(String[] args) {
		List<Segment> segments = new ArrayList<>();
		segments.add(new Segment(1, 5));
		segments.add(new Segment(3, 7));
		segments.add(new Segment(2, 8));
		segments.add(new Segment(1, 4));
		segments.add(new Segment(5, 7));
		segments.add(new Segment(8, 10));
		System.out.println("The segments are"+getMaximumSegmentsSubset(segments));
		
		List<KnapsackItem> knapsackItems = new ArrayList<>();
		knapsackItems.add(new KnapsackItem(60, 10));
		knapsackItems.add(new KnapsackItem(100, 20));
		knapsackItems.add(new KnapsackItem(120, 30));
		System.out.println("The maximum value for knapsack is : "+getMaximumValueForKnapsack(knapsackItems,50));
		
		double arrivals[] = {9,9.40,9.50,11.00,15.00,18.00};
		double departures[] = {9.10,12.00,11.20,11.30,19.00,20.00};
		System.out.println("The minimum no of platforms required : "+getMinimumNoOfPlatforms(arrivals, departures));
		
	}
	//interval scheduling algorithm: Given a set of n intervals S={(starti,endi)| 1<=i<=n}, find a maximum subset S` such that
	//no pair of intervals in S` overlaps 
	private static List<Segment> getMaximumSegmentsSubset(List<Segment> segments) {
		List<Segment> result = new ArrayList<>();

		//sort the segments according to the end positions
		Collections.sort(segments);
		int currentPosition = segments.get(0).end;

		//add the first one to the result
		result.add(segments.get(0));

		//check for the overlapping condition, add to the result if the left end of the current segment is after right end of 
		//previously selected segment
		for (int i = 0; i <segments.size()-1; i++) {
			if(segments.get(i+1).start>currentPosition){
				currentPosition = segments.get(i+1).end;
				result.add(segments.get(i+1));
			}
		}
		return result;
	}

	private static class Segment implements Comparable<Segment>{
		int start, end;

		Segment(int start, int end) {
			this.start = start;
			this.end = end;
		}
		@Override
		public int compareTo(Segment o) {
			return this.end-o.end;
		}                                                                                                    
		@Override
		public String toString() {
			return "Segment [start=" + start + ", end=" + end + "]";
		}

	}
	//The coin change problem --> Greedy algorithm works only when we have limited coins of each denominations.
	//When we have unlimited coins then we have to used dynamic programming.Refer Change.java for greedy approach.

	//Fractional knapsack
	//When we can put fractions of items. so greedy approach will work here.Take out maximum the highest density items as 
	//much as possible, then next largest and so on until we cannot add further.
	private static double getMaximumValueForKnapsack(List<KnapsackItem> list,int capacity) {
		double value = 0;
		//sort according to density
		Collections.sort(list);
		int index = list.size()-1;
		
		//iterate until knapsack is full or no more items left
		while(capacity>0 && index>-1) {
			KnapsackItem item = list.get(index);
			int minWeight = Math.min(item.weight,capacity);
			capacity = capacity - minWeight;
			value += minWeight*item.valueByWeight;
			index--;	
		}
		
		//round off values to 2 decimal places
		value = Math.round(value * 10000.0) / 10000.0;
		return value;
	}

	private static class KnapsackItem implements Comparable<KnapsackItem>{
		@SuppressWarnings("unused")
		private int value;
		private int weight;
		private double valueByWeight;

		public KnapsackItem(int value, int weight) {
			this.value = value;
			this.weight = weight;
			this.valueByWeight = ((double)value/(double)weight);
		}
		@Override
		public int compareTo(KnapsackItem o) {
			if(this.valueByWeight>o.valueByWeight) {
				return 1;
			}
			else if(o.valueByWeight>this.valueByWeight){
				return -1;
			}
			else{
				return 0;
			}
		}
	}
	//Problem : We have fixed arrivals and departures of the train, find out the minimum no of platforms required so that all
	//trains can be accommodated according to their schedule.
	private static int getMinimumNoOfPlatforms(double arrivals[],double departures[]){
		int noOfPlatforms = 0;
		//Sol: minimum no of platforms required =  maximum no of trains at railway station at any time.
		
		//first sort both of the arrays
		Arrays.sort(arrivals);
		Arrays.sort(departures);
		
		//now we iterate over arrays and record the maximum no of trains at a time
		int i=0,j = 0,platforms = 0;
		while (i<arrivals.length && j< departures.length) {
			if(arrivals[i]<departures[j]){
				platforms++;
				i++;
				noOfPlatforms = Math.max(noOfPlatforms,platforms);
			}
			else {
				platforms--;
				j++;
			}
		}
		return noOfPlatforms;
	}
}
