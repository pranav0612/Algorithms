package com.algo.ds.greedy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class HuffmanCoding {

	public static void main(String[] args) {
		Node[] nodes = new Node[6];
		nodes[0] = new Node('a',5);
		nodes[1] = new Node('b',9);
		nodes[2] = new Node('c',12);
		nodes[3] = new Node('d',13);
		nodes[4] = new Node('e',16);
		nodes[5] = new Node('f',45);
		
		System.out.println("The huffman codes are : "+getHuffmanCodesForCharacters(nodes));
	}

	private static Map<Character,String> getHuffmanCodesForCharacters(Node[] nodes){
		Map<Character,String> result = new HashMap<>();
		Node root = getHuffmanTreeForCharacters(nodes);
		generateHuffmanCodesFromTree(root,new ArrayList<>(),result);
		return result;
	}
	private static void generateHuffmanCodesFromTree(Node root,List<Integer> list,Map<Character,String> result){
		if(root.left!=null){
			list.add(0);
			generateHuffmanCodesFromTree(root.left, list, result);
			list.remove(list.size()-1);
		}
		if(root.right!=null){
			list.add(1);
			generateHuffmanCodesFromTree(root.right, list, result);
			list.remove(list.size()-1);
		}
		//leaf node
		if(root.left==null && root.right==null){
			result.put(root.data,convertListOfIntsToString(list));
		}
	}
	private static String convertListOfIntsToString(List<Integer> list){
		StringBuilder builder = new StringBuilder();
		for (Integer val : list) {
			builder.append(val);
		}
		return builder.toString();
	}
	private static Node getHuffmanTreeForCharacters(Node[] nodes){
		PriorityQueue<Node> queue = new PriorityQueue<>();
		//add all leaf nodes to the queue
		for (Node node : nodes) {
			queue.offer(node);
		}
		while (queue.size()>1) {
			Node left = queue.remove();
			Node right = queue.remove();
			//new node with special $ symbol
			Node newNode =  new Node('$',left.frequency+right.frequency);
			newNode.left = left;
			newNode.right = right;
			queue.offer(newNode);
		}
		return queue.remove();
	}
	
	private static class Node implements Comparable<Node>{
		char data;
		int frequency;
		Node left;
		Node right;
		
		public Node(char data, int frequency) {
			this.data = data;
			this.frequency = frequency;
		}
		@Override
		public int compareTo(Node o) {
			return this.frequency - o.frequency;
		}
	}
}
