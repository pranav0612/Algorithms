package com.algo.ds.selectionandhashing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashingProblems {

	public static void main(String[] args) {
		System.out.println("Arrays have same set of elements : "+checkArraysWithSameSetOfNumbers(new int[]{1,2,3,1,7,8,2,0},new int[]{2,1,2,3,7,8,0,1}));
		List<Pair> pairs = new ArrayList<>();
		pairs.add(new Pair(1,3));
		pairs.add(new Pair(2,6));
		pairs.add(new Pair(3,5));
		pairs.add(new Pair(7,4));
		pairs.add(new Pair(5,3));
		pairs.add(new Pair(8,7));
		System.out.println("Symmetric pairs are :"+getSymmetricPairs(pairs));
		System.out.println("The pair constituting 6 is : "+getPairConstitutingSumK(new int[]{1,2,3,4},new int[]{4,5,6,7,2}, 6));
		System.out.println("The first non repeating char is : "+getFirstNonRepeatingChar("abzddab".toCharArray()));
		System.out.println("The first repeating char is : "+getFirstRepeatingChar("abzdqwazb".toCharArray()));
	}
	//We have given 2 arrays, check if they have same set of elements
	//idea : use hash table
	private static boolean checkArraysWithSameSetOfNumbers(int arr1[],int arr2[]){
		//construct a hashmap with first array
		Map<Integer,Integer> map = new HashMap<>();
		for (int i = 0; i < arr1.length; i++) {
			Integer count = map.get(arr1[i]);
			if(count!=null){
				map.put(arr1[i],++count);
			}
			else{
				map.put(arr1[i],1);
			}
		}
		for (int i = 0; i < arr2.length; i++) {
			Integer count = map.get(arr2[i]);
			if(count!=null){
				map.put(arr2[i],--count);
			}
			else{
				return false;
			}
		}
		for (int i : map.keySet()) {
			if(map.get(i)!=0){
				return false;
			}
		}
		return true;
	}
	//symmetric pairs = i,j such that i,j exists and j,i also exist in the list
	private static List<Pair> getSymmetricPairs(List<Pair> pairs){
		List<Pair> symmetricPairs = new ArrayList<>();
		//Idea : Insert all pairs in hash table with first element as key and second as value. While inserting also check if we make
		//second element as key then if the value exists then if it's equal to first element then our pair exist
		Map<Integer,Integer> map = new HashMap<>();
		for (Pair pair : pairs) {
			Integer value =  map.get(pair.second);
			if(value!=null && value == pair.first){
				//we got a symmetric pair
				symmetricPairs.add(pair);
			}
			else{
				map.put(pair.first,pair.second);
			}
		}
		return symmetricPairs;
	}
	static class Pair{
		int first;
		int second;
		
		public Pair(int first, int second) {
			this.first = first;
			this.second = second;
		}

		@Override
		public String toString() {
			return "Pair [first=" + first + ", second=" + second + "]";
		}
		
	}
	//We have 2 sets of numbers,find a pair which is from different set and whose sum = k
	private static Pair getPairConstitutingSumK(int firstSet[],int secondSet[],int k){
		Map<Integer,Integer> map = new HashMap<>();
		boolean firstSetUsed = false;
		//insert the smaller set in hash table
		if(firstSet.length < secondSet.length){
			firstSetUsed = true;
			for (int i = 0; i < firstSet.length; i++) {
				map.put(firstSet[i],firstSet[i]);
			}
		}
		else {
			for (int i = 0; i < secondSet.length; i++) {
				map.put(secondSet[i],secondSet[i]);
			}
		}
		//lets find element with key k-element whose value is in hash table
		if(firstSetUsed){
			for (int i = 0; i < secondSet.length; i++) {
				if(map.get(k-secondSet[i])!=null){
					return new Pair(secondSet[i], k-secondSet[i]);
				}
			}
		}
		return null;
	}
	//idea is to use hash table, store the elements and their count. Iterate again to find the first element whose count is 1
	private static char getFirstNonRepeatingChar(char arr[]){
		//use an array as hash table as chars are limited
		int hashTable[] =  new int[256];
		for (int i = 0; i < arr.length; i++) {
			if(hashTable[arr[i]]!=0){
				hashTable[arr[i]]++;
			}
			else{
				hashTable[arr[i]] = 1;
			}
		}
		for (int i = 0; i < arr.length; i++) {
			if(hashTable[arr[i]]==1){
				return arr[i];
			}
		}
		return 0;
	}
	private static char getFirstRepeatingChar(char arr[]){
		//use an array as hash table as chars are limited
		int hashTable[] =  new int[256];
		for (int i = 0; i < arr.length; i++) {
			if(hashTable[arr[i]]>0){
				return arr[i];
			}
			else{
				hashTable[arr[i]] = 1;
			}
		}
		return 0;
	}
}
