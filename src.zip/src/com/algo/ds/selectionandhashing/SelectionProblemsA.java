package com.algo.ds.selectionandhashing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;

public class SelectionProblemsA {

	private static Random random = new Random();

	public static void main(String[] args) {
		System.out.println("The smallest and the largest elements in array are : "+Arrays.toString(findSmallestAndLargestElementsInArrayWithPairComparisions(new int[]{3,1,6,7,10,8,9,-1})));
		System.out.println("Second largest element in array : "+getSecondLargestElement(new int[]{1,5,7,10,12,5,29,11}));
		System.out.println("The first 4 smallest elements of array : "+getKSmallestElementsUsingHeap(new int[]{1,5,7,10,12,3,29,11}, 4));
		System.out.println("The first 4 smallest elements of array : "+getKSmallestElementsUsingPartition(new int[]{1,5,7,10,12,3,29,11}, 4));
		System.out.println("The first 4 smallest elements of array : "+getKthSmallestElementsUsingMedianOfMedians(new int[]{1,5,7,10,12,3,29,11}, 4));
	}
	//aim is to do less comparisons 
	private static int[] findSmallestAndLargestElementsInArrayWithPairComparisions(int arr[]){
		int smallest =arr[0],largest = arr[0];
		//compare in pairs and increment by 2 at once
		for (int i = 0; i < arr.length && i+1< arr.length; i+=2) {
			if(arr[i]<arr[i+1]){
				if(arr[i]<smallest){
					smallest = arr[i];
				}
				else if(arr[i+1]>largest){
					largest = arr[i+1];
				}
			}
			else{
				if(arr[i+1]<smallest){
					smallest = arr[i+1];
				}
				else if(arr[i]>largest){
					largest = arr[i];
				}
			}
		}
		return new int[]{smallest,largest};
	}
	private static int getSecondLargestElement(int arr[]){
		int largest = arr[0],secondLargest=arr[0];
		for (int i = 1; i < arr.length; i++) {
			if(arr[i]>largest){
				secondLargest = largest;
				largest = arr[i];
			}
			else if(arr[i]>secondLargest){
				secondLargest = arr[i];
			}
		}
		return secondLargest;
	}
	//using the tournament method-- no of comparisons is less than any other algorithm
	public static int getSecondLargestElementUsingTournamentMethod(int arr[]){
		//it seems to be more complex than expected, i am not gonna code it. Complex solution for simple question.
		//Idea : If the input has 8 keys ,there are 4 comparisons in first round,2 in second round,1 in last round.
		//The second largest is the element which lost the last tournament. Total comparisons = n+logn-2
		return 0;
	}

	//Idea is to use max-heap and insert first k elements in the max heap
	//now iterate rest of the elements of array if the element is smaller than largest element of the tree then,
	//remove the largest element of tree and insert the element in Heap.
	private static List<Integer> getKSmallestElementsUsingHeap(int arr[],int k){
		List<Integer> result = new ArrayList<>();
		PriorityQueue<Integer> queue = new PriorityQueue<>(new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o2-o1;
			}
		});
		for (int i = 0; i < k; i++) {
			queue.offer(arr[i]);
		}
		for (int i = k; i < arr.length; i++) {
			if(arr[i]<queue.peek()){
				queue.poll();
				queue.offer(arr[i]);
			}
		}
		result.addAll(queue);
		return result;
	}
	//we will graph the kth smallest element and then prepare the list
	private static List<Integer> getKSmallestElementsUsingPartition(int arr[],int k){
		List<Integer> result = new ArrayList<>();
		int kthSmallest = getKthSmallestElementUsingPartition(arr, 0, arr.length-1, k);
		populateElementsLessThanKth(arr, result, kthSmallest);
		return result;
	}
	public static void populateElementsLessThanKth(int[] arr, List<Integer> result, int kthSmallest) {
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]<kthSmallest){
				result.add(arr[i]);
			}
		}
		result.add(kthSmallest);
	}

	//getting kth smallest number many ways. We can use quick sort for that. In QuickSort, we pick a pivot element, 
	//then move the pivot element to its correct position and partition the array around it. 
	//The idea is, not to do complete quicksort, but stop at the point where pivot itself is k’th smallest element. 
	//Also, not to recur for both left and right sides of pivot, but recur for one of them according to the position of pivot. 
	//The worst case time complexity of this method is O(n2), but it works in O(n) on average.

	//we can use simple quick sort or we can use randomized quick sort. I am going for randomized quick sort. both are same except
	//the pivot in latter is randomly selected.
	private static int getKthSmallestElementUsingPartition(int arr[],int l,int r,int k){
		//Partition the array around a random element and
		//get position of pivot element in sorted array
		int pos = doRandomPartition(arr, l, r);

		// If position is same as k
		if (pos-l == k-1) {
			return arr[pos];
		}
		// If position is more, recur for left subarray
		if (pos-l > k-1){
			return getKthSmallestElementUsingPartition(arr, l, pos-1, k);
		}
		// Else recur for right subarray
		return getKthSmallestElementUsingPartition(arr, pos+1, r, k-pos+l-1);
	}
	private static int doRandomPartition(int[] a, int l, int r){
		int pivot = random.nextInt(r - l + 1) + l;
		swap(a, pivot, l);
		return doPartition(a, l, r,null);
	}
	// Standard partition process of QuickSort().  It considers the first element as pivot and moves all smaller element 
	// to left of it and greater elements to right.
	private static int doPartition(int[] a, int l, int r,Integer pivot) {
		//if we have pivot then place it to first place
		if(pivot!=null){
			int i = 0;
			for (;i < a.length; i++) {
				if(a[i]== pivot){
					break;
				}
			}
			swap(a, i,l);
		}
		//x is the pivot
		int x = a[l];
		int j = l;
		for (int i = l + 1; i <= r; i++) {
			//iterate and shift all values which are less than chosen pivot to the left
			if (a[i] <= x) {
				j++;
				swap(a, i, j);
			}
		}
		//at last interchange the chosen pivot to its correct index. Now one element is at its rightful position that is pivot
		swap(a, l, j);
		return j;
	}
	private static void swap(int arr[], int i, int j){
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	//refer the doc
	private static List<Integer> getKthSmallestElementsUsingMedianOfMedians(int arr[],int k){
		int kthSmallest = doPartitionAroundMediansOfMedians(arr, 0, arr.length-1, k);
		List<Integer> result = new ArrayList<>();
		populateElementsLessThanKth(arr, result, kthSmallest);
		return result;
	}
	private static int doPartitionAroundMediansOfMedians(int arr[],int l,int r,int k){

		int n = r-l+1,i; // Number of elements in arr[l..r]

		//Divide arr[] in groups of size 5, calculate median of every group and store it in median[] array.There will be floor((n+4)/5) groups
		int [] median = new int[(n+4)/5]; 
		for (i=0; i<n/5; i++) {
			median[i] = getMedian(arr,l+i*5,5);
		}
		//For last group with less than 5 element
		if (i*5 < n){
			median[i] = getMedian(arr,l+i*5,n%5);
			i++;
		}    
		// Find median of all medians using recursive call.If median[] has only one element, then no need of recursive call
		int medOfMed = (i == 1)? median[i-1]: doPartitionAroundMediansOfMedians(median, 0, i-1, i/2);

		// Partition the array around pivot element and get position of pivot element in sorted array
		int pos = doPartition(arr, l, r, medOfMed);

		// If position is same as k
		if (pos-l == k-1){
			return arr[pos];
		}
		if (pos-l > k-1){
			return doPartitionAroundMediansOfMedians(arr, l, pos-1, k);// If position is more, recur for left
		}	
		// Else recur for right subarray
		return doPartitionAroundMediansOfMedians(arr, pos+1, r, k-pos+l-1);
	}
	private static int getMedian(int arr[],int l,int n){
		Arrays.sort(arr, l,l+n);
		return arr[l+(n/2)];
	}
}
