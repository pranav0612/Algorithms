package com.algo.ds.disjointsets;

public class DisjointSetWithTrees {
	
	public class Node {
		Node parent;
		int rank;//not same as height. rank of the parents matter , ranks of the leaves doesn't matter
		//acts same as height but when path compression occurs rank is screwed and will be not same as height
		int data;
		
		//path compression
		public Node getParent(){
			if(parent!=this) {
            	parent = find(this);
            }
            return parent;
		}
		public Node(int data) {
			this.data = data;
			//initially all pointing to itself
			parent = this;
		}
		//Find with path compression
		public Node find(Node node){
			if(node.parent==node){
				return node;
			}
			else{
				node.parent = find(node.parent);
				return node.parent;
			}
		}
		@Override
		public String toString() {
			return "Node [parentIndex=" + parent.data + ", rank=" + rank + ", data=" + data + "]";
		}
	}
	
	public void union(Node node1,Node node2){
		Node parent1 = node1.getParent();
        Node parent2 = node2.getParent();
        if (parent1 == parent2) {
            return;
        }
        if(parent1.rank>parent2.rank) {
        	parent2.parent = parent1;
        }
        else if(parent1.rank<parent2.rank) {
        	parent1.parent = parent2;
        }
        //rank is same
        else {
        	parent1.parent = parent2;
        	parent2.rank +=1;
        }
	}
}
