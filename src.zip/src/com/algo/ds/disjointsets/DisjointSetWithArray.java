package com.algo.ds.disjointsets;

public class DisjointSetWithArray {

	private int arr[];
	
	public DisjointSetWithArray(int capacity) {
		this.arr = new int[capacity];
	}
	//initialize with -1
	public void makeSet(int size) throws Exception{
		if(size>arr.length){
			throw new Exception("Invalid size. Valid range 0 to "+arr.length);
		}
		for (int i = 0; i < size; i++) {
			arr[i] =-1;
		}
	}
	//with path compression
	public int find(int x) throws Exception{
		if(x<0 || x>=arr.length){
			throw new Exception("Invalid x. Valid range 0 to "+arr.length);
		}
		//parents are with negative values
		if(arr[x]<0){
			return x;
		}
		else {
			return arr[x] = find(arr[x]);
		}
	}
	public void union(int node1,int node2) throws Exception{
		//these are indexes of parent. find returns index of parent.
		int parent1 = find(node1);
		int parent2 = find(node2);
		
		//same parent
		if(parent1 == parent2){
			return;
		}
		//check the size.bigger one should swallow the smaller one
		if(Math.abs(arr[parent1]) > Math.abs(arr[parent2])){
			arr[parent2] = parent1;
			//we are actually increasing the absolute value
			arr[parent1] -= Math.abs(arr[parent2]);
		}
		else if(Math.abs(arr[parent1]) <= Math.abs(arr[parent2])){
			arr[parent1] = parent2;
			//we are actually increasing the absolute value
			arr[parent2] -= Math.abs(arr[parent1]);
		}
	}
}
