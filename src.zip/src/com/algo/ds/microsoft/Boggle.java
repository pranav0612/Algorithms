package com.algo.ds.microsoft;

import java.util.HashMap;

//Given a dictionary, a method to do lookup in dictionary and a M x N board where every cell has one character. 
//Find all possible words that can be formed by a sequence of adjacent characters. Note that we can move to any of 8 adjacent characters, but a word should not have multiple instances of same cell.
//Input: dictionary[] = {"GEEKS", "FOR", "QUIZ", "GO"};
//       boggle[][]   = {{'G','I','Z'},
//                       {'U','E','K'},
//                       {'Q','S','E'}};
//      isWord(str): returns true if str is present in dictionary
//                   else false.

//Output:  Following words of dictionary are present
//         GEEKS
//         QUIZ

public class Boggle {

	public static void main(String[] args) {
		char[][] boggle = {{'G','I','Z'},
				{'U','E','K'},
				{'Q','S','T'}};
		System.out.println("Is GUEST possible : "+isWordPossible("GUEST", boggle ));
	}

	//we can use trie DS to solve this, Build the trie using all words and then check the given word if it is possible
	//I will use hash map and i will map each character with its index.
	//traverse over map and check the characters index
	private static boolean isWordPossible(String word, char[][] boggle){
		HashMap<Character,CharacterIndex> map = new HashMap<>();
		for (int i = 0; i < boggle.length; i++) {
			for (int j = 0; j < boggle[i].length; j++) {
				CharacterIndex index = map.get(boggle[i][j]);
				map.put(boggle[i][j],index);
			}
		}

		//now traverse over word to see if it is present
		char[] charArr = word.toCharArray();

		//check 2 characters at a time. See if they are reachable or not
		for (int i = 0; i < charArr.length-1; i++) {
			CharacterIndex fromCharacterIndex = map.get(charArr[i]);
			CharacterIndex toCharacterIndex = map.get(charArr[i+1]);

			if(fromCharacterIndex == null || toCharacterIndex==null){
				return false;
			}
			if(!isReachable(fromCharacterIndex, toCharacterIndex)){
				return false;
			}
		}
		return true;
	}
	//8 cases
	private static boolean isReachable(CharacterIndex fromCharacterIndex,CharacterIndex toCharacterIndex){
		if(fromCharacterIndex.i-1 == toCharacterIndex.i && fromCharacterIndex.j-1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i == toCharacterIndex.i && fromCharacterIndex.j-1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i-1 == toCharacterIndex.i && fromCharacterIndex.j == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i+1 == toCharacterIndex.i && fromCharacterIndex.j+1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i == toCharacterIndex.i && fromCharacterIndex.j+1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i+1 == toCharacterIndex.i && fromCharacterIndex.j == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i-1 == toCharacterIndex.i && fromCharacterIndex.j+1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		if(fromCharacterIndex.i+1 == toCharacterIndex.i && fromCharacterIndex.j-1 == toCharacterIndex.j &&!toCharacterIndex.visited){
			toCharacterIndex.visited = true;
			return true;
		}
		return false;
	}
	static class CharacterIndex{
		int i;
		int j;
		boolean visited;
		public CharacterIndex(int i, int j) {
			this.i = i;
			this.j = j;
			this.visited = false;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + i;
			result = prime * result + j;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CharacterIndex other = (CharacterIndex) obj;
			if (i != other.i)
				return false;
			if (j != other.j)
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "CharacterIndex [i=" + i + ", j=" + j + ", visited=" + visited + "]";
		}


	}
}
