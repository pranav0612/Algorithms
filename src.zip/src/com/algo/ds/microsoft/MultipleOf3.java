package com.algo.ds.microsoft;
//Write an Efficient Method to Check if a Number is Multiple of 3.  If sum of digits in a number is multiple of 3 then number 
//is multiple of 3 e.g., for 612 sum of digits is 9 so it�s a multiple of 3. But this solution is not efficient.

//There is a pattern in binary representation of the number that can be used to find if number is a multiple of 3. 
//If difference between count of odd set bits (Bits set at odd positions) and even set bits is multiple of 3 then is the number.
public class MultipleOf3 {

	public static void main(String[] args) {
		System.out.println("Is 45 multiple of 3 : "+isMultipleOf3(45));
	}
	private static boolean isMultipleOf3(int n){
		if(n==0){
			return true;
		}
		if(n==1){
			return false;
		}
		//making its positive is no harm as we have to check if it's multiple of 3. Again 
		if(n<0){
			n = -n;
		}
		int countOddSetBits = 0;
		int countEvenSetBits = 0;
		
		while(n>0){
			//odd ones. & by 1 means check the first bit, if set then increment else shift right
			if((n&1) > 0){
				countOddSetBits++;
			}
			n = n>>1;
			//even ones. & by 1 means check the first bit, if set then increment else shift right
			if((n&1) > 0){
				countEvenSetBits++;
			}
			n = n>>1;
		}
		return isMultipleOf3(countEvenSetBits - countOddSetBits);
	}
}
//Let�s take the example of 2 digit numbers in decimal
//AB = 11A -A + B = 11A + (B � A)
//So if (B � A) is a multiple of 11 then is AB.
//
//Let us take 3 digit numbers.
//
//ABC = 99A + A + 11B � B + C = (99A + 11B) + (A + C � B)
//So if (A + C � B) is a multiple of 11 then is (A+C-B)
//
//Let us take 4 digit numbers now.
//ABCD = 1001A + D + 11C � C + 999B + B � A
//= (1001A � 999B + 11C) + (D + B � A -C )
//So, if (B + D � A � C) is a multiple of 11 then is ABCD.



//Not using % operator because
//Two reasons for this:
//1) Bit operation is faster.
//2) % will not work for large numbers.