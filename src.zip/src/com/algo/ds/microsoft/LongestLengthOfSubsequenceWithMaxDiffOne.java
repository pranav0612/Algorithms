package com.algo.ds.microsoft;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class LongestLengthOfSubsequenceWithMaxDiffOne {

	public static void main(String[] args) {
		int a[] = {6,10,6,9,7,8};
		System.out.println(new LongestLengthOfSubsequenceWithMaxDiffOne().solution(a));
	}
	 public int solution(int[] A) {
		int count = 0;
		if(A.length == 1){
			return 1;
		}
		if(A.length ==2){
			if(Math.abs(A[0] - A[1]) < 2){
				return 2;
			}
		}
		HashMap<Integer,Element> map = new HashMap<>();
		for (int i = 0; i < A.length; i++) {
			Element element = map.get(A[i]);
			if(element!=null){
				//ignore the index as we want to store the lowest index
				element.count++;
			}
			else{
				map.put(A[i],new Element(1,i));
			}
		}
		//Now we get the values of map and sort them according to count
		List<Element> elements = new ArrayList<>();
		Set<Integer> keys = map.keySet();
		for (Integer key : keys) {
			elements.add(map.get(key));
		}
		Collections.sort(elements);
		
		//add the biggest count to our counter
		Element firstElement = elements.get(0);
		count = firstElement.count;
		//check the higher element present
		Element nextHigherElement = map.get(A[firstElement.index]+1);
		if(nextHigherElement!=null){
			count+= nextHigherElement.count;
		}
		return count;
	}
	 class Element implements Comparable<Element>{
		 int count;
		 int index;
		public Element(int count, int index) {
			this.count = count;
			this.index = index;
		}
		@Override
		public int compareTo(Element o) {
			return o.count - this.count;
		}
	 }
}
