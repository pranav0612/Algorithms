package com.algo.ds.microsoft;

import java.util.HashMap;
import java.util.Map;

//LRU Cache: In computing, cache replacement algorithms are optimizing algorithms that a computer program or a hardware 
//maintained structure can follow in order to manage a cache of information stored on the computer. When the cache is full, 
//the algorithm must choose which items to discard to make room for the new ones.

//Least Recently Used cache replacement algorithm is a cache replacement strategy by which the least recently accessed page 
//is removed from the cache when a new page is accessed which is not already present in the cache.


public class LRUCache<K,V> {

	DLLNode<K,V> head;
	DLLNode<K,V> tail;
	Map<K,DLLNode<K,V>> map = new HashMap<>();
	private final int capacity;
	private int currentSize;

	@Override
	public String toString() {
		return "LRUCache [head=" + head + ", map=" + map + ", capacity=" + capacity + ", currentSize=" + currentSize
				+ "]";
	}
	public LRUCache(int capacity) {
		this.capacity = capacity;
	}
	public V getValue(K key){
		if(head == null){
			return null;
		}
		DLLNode<K,V> node = map.get(key);
		if(node != null){
			removeNode(node);
			insertAtHead(node);
			return node.data;
		}
		return null;
	}
	public void putValue(K key,V value){
		//check if the element is already present
		if(map.containsKey(key)){
			//just move the node to the start of dll and update the map
			DLLNode<K,V> node = map.get(key);
			//update the node
			node.data = value;
			removeNode(node);
			insertAtHead(node);
			map.put(key, head);
		}
		else{
			//if size is full
			if(currentSize==capacity){
				//remove from map
				map.remove(tail.key);
				//remove from tail
				removeNodeFromTail();
				DLLNode<K,V> node = (new DLLNode<K,V>(key,value));
				map.put(key, node);
				//insert this node in beginning
				insertAtHead(node);
			}
			else{
				//increase the size
				currentSize++;
				DLLNode<K,V> node = (new DLLNode<K,V>(key,value));
				map.put(key, node);
				insertAtHead(node);
			}
		}
	}
	private  void removeNode(DLLNode<K,V> node){
		DLLNode<K,V> previous = node.previous;
		if(previous.next !=null){
			previous.next = node.next;
		}
		if(node.next != null){
			node.next.previous = previous;
		}
		//check for tail pointer
		if(tail == node){
			tail = previous;
		}
		if(head == node){
			head = null;
		}
		node = null;
	}
	private void insertAtHead(DLLNode<K,V> node){
		if(head!=null){
			head.previous = node;
		}
		node.next = head;
		node.previous = null;
		head = node;
		if(tail == null){
			tail = node;
		}
	}
	private  void removeNodeFromTail(){
		if(tail!=null){
			DLLNode<K,V> previous = tail.previous;
			if(previous!=null){
				previous.next = null;
			}
			tail = previous;
		}
	}
	public static void main(String[] args) {
		LRUCache<Integer,String> cache = new LRUCache<>(5);
		System.out.println("Current state of cache : "+cache);
		System.out.println("Getting the value of 1  : "+cache.getValue(1));
		System.out.println("Putting item1");
		cache.putValue(1,"item1");
		System.out.println("Putting item2");
		cache.putValue(2,"item2");
		System.out.println("Putting item3");
		cache.putValue(3,"item3");
		System.out.println("Putting item4");
		cache.putValue(4,"item4");
		System.out.println("Putting item5");
		cache.putValue(5,"item5");
		System.out.println("Current state of cache : "+cache);
		System.out.println("Putting item6");
		cache.putValue(6,"item6");
		System.out.println("Current state of cache : "+cache);
	}
	
	class DLLNode<C,T>{

		private DLLNode<C,T> next;
		private DLLNode<C,T> previous;
		T data;
		C key;
		public DLLNode(C key,T data) {
			this.data = data;
			this.key = key;
		}
		@Override
		public String toString() {
			String result = "DLLNode :["+data+"] ";
			if(next != null){
				result += next.toString();
			}
			return result;
		}
	}
}
//For implementing an LRU cache, we can use a doubly linked list and a hash map.
//Doubly Linked List - List of pages with most recently used page at the start of the list. So, as more pages are added to the list, least recently used pages are moved to the end of the list with page at tail being the least recently used page in the list.
//Hash Map (key: page number, value: page) - For O(1) access to pages in cache

//When a page is accessed, there can be 2 cases:
//1. Page is present in the cache - If the page is already present in the cache, we move the page to the start of the list.
//2. Page is not present in the cache - If the page is not present in the cache, we add the page to the list. 
//How to add a page to the list:
//a. If the cache is not full, add the new page to the start of the list.
//b. If the cache is full, remove the last node of the linked list and move the new page to the start of the list.