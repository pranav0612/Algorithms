package com.algo.ds.microsoft;

import java.util.ArrayList;
import java.util.List;

import com.algo.ds.trees.basics.BinaryTreeNode;
import com.algo.ds.trees.basics.TreeTraversalNonRecursive;

//Two of the nodes of a Binary Search Tree (BST) are swapped. Fix (or correct) the BST.
public class CorrectBSTWithTwoNodesSwapped {

	public static void main(String[] args) {
		System.out.println("Before fixing the BST : ");
		BinaryTreeNode tree = createSwappedBST();
		TreeTraversalNonRecursive.inOrderTraversal(tree);
		System.out.println();
		System.out.println("After fixing : ");
		correctBST(tree);
		TreeTraversalNonRecursive.inOrderTraversal(tree);
	}
	//3 pointer approach
	private static void correctBST(BinaryTreeNode node){
		//traverse over the BST and get the Inorder traversal array
		List<BinaryTreeNode> list = new ArrayList<>();
		inOrderTraversal(node, list);
		
		//now maintain 3 pointers
		BinaryTreeNode first = null;
		BinaryTreeNode middle = null;
		BinaryTreeNode last = null;
		
		for (int i = 0; i < list.size()-1; i++) {
			//we found a discrepancy- maximum 2 discrepancies will be found
			if(list.get(i+1).getData() < list.get(i).getData()){
				//check if its the first one
				if(first == null){
					first = list.get(i);
					middle = list.get(i+1);
				}
				else{
					last = list.get(i+1);
				}
			}
		}
		//case of discrepancy in adjacent element
		if(last==null){
			//swap first and middle
			int temp = first.getData();
			first.setData(middle.getData());
			middle.setData(temp);
		}
		else{
			//swap first and last
			int temp = first.getData();
			first.setData(last.getData());
			last.setData(temp);
		}
	}
	private static void inOrderTraversal(BinaryTreeNode node,List<BinaryTreeNode> list){
		if(node==null){
			return;
		}
		inOrderTraversal(node.getLeft(), list);
		list.add(node);
		inOrderTraversal(node.getRight(), list);
	}
	//We can solve this in O(n) time and with a single traversal of the given BST. Since inorder traversal of BST is always 
	//a sorted array, the problem can be reduced to a problem where two elements of a sorted array are swapped. 
	//There are two cases that we need to handle:

	//1. The swapped nodes are not adjacent in the inorder traversal of the BST.
	// For example, Nodes 5 and 25 are swapped in {3 5 7 8 10 15 20 25}. 
	// The inorder traversal of the given tree is 3 25 7 8 10 15 20 5 
	//If we observe carefully, during inorder traversal, we find node 7 is smaller than the previous visited node 25. 
	//Here save the context of node 25 (previous node). Again, we find that node 5 is smaller than the previous node 20. 
	//This time, we save the context of node 5 ( current node ). Finally swap the two node�s values.
	
	//2. The swapped nodes are adjacent in the inorder traversal of BST.
	//  For example, Nodes 7 and 8 are swapped in {3 5 7 8 10 15 20 25}. 
	//  The inorder traversal of the given tree is 3 5 8 7 10 15 20 25 
	
	//solution : We will maintain three pointers, first, middle and last. When we find the first point where current node 
	//value is smaller than previous node value, we update the first with the previous node & middle with the current node.
	//When we find the second point where current node value is smaller than previous node value, we update the last with 
	//the current node. In case #2, we will never find the second point. So, last pointer will not be updated. 
	//After processing, if the last node value is null, then two swapped nodes of BST are adjacent.
	
	public static BinaryTreeNode createSwappedBST() {
		//3 is swapped with 9
		BinaryTreeNode root = new BinaryTreeNode(4);
		BinaryTreeNode node1 = new BinaryTreeNode(1);
		BinaryTreeNode node2 = new BinaryTreeNode(2);
		BinaryTreeNode node3 = new BinaryTreeNode(9);
		BinaryTreeNode node0 = new BinaryTreeNode(0);
		BinaryTreeNode node5 = new BinaryTreeNode(5);
		BinaryTreeNode node6 = new BinaryTreeNode(6);
		BinaryTreeNode node7 = new BinaryTreeNode(7);
		BinaryTreeNode node8 = new BinaryTreeNode(8);
		BinaryTreeNode node9 = new BinaryTreeNode(3);
		BinaryTreeNode node10 = new BinaryTreeNode(10);

		root.setLeft(node2);
		root.setRight(node8);
		node2.setLeft(node1);
		node2.setRight(node3);
		node1.setLeft(node0);
		
		node8.setLeft(node6);
		node8.setRight(node9);
		node6.setLeft(node5);
		node6.setRight(node7);
		node9.setRight(node10);
		return root;
	}
}
