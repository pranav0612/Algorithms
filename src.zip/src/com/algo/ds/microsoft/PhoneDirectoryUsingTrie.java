package com.algo.ds.microsoft;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

//Given a list of contacts which exist in a phone directory. The task is to implement search query for the phone directory. 
//The search query on a string �str� displays all the contacts which prefix as �str�. One special property of the search 
//function is that, when a user searches for a contact from the contact list then suggestions 
//(Contacts with prefix as the string entered so for) are shown after user enters each character.
//Note : Contacts in the list consist of only lower case alphabets.

//Input : contacts [] = {�gforgeeks� , �geeksquiz� }
//Query String = �gekk�
//Output : Suggestions based on "g" are 
// geeksquiz
// gforgeeks
//
// Suggestions based on "ge" are 
// geeksquiz
//
// No Results Found for "gek" 

public class PhoneDirectoryUsingTrie {

	public static void main(String[] args) {
		PhoneDirectoryUsingTrie app = new PhoneDirectoryUsingTrie();
		String[] contacts =  {"gforgeeks" , "geeksquiz","geksyu","pranav","aditi","pramiti"};
		Node trie = app.buildTrie(contacts);
		System.out.println("The suggestions for ge : "+getSuggestionsForInputString("ge", trie));
	}

	private static List<String> getSuggestionsForInputString(String s,Node trie){
		List<String> result = new ArrayList<>();
		char[] charArr = s.toCharArray();
		//traverse till our search string
		for (int i = 0; i < charArr.length; i++) {
			Node node = trie.edgeMap.get(charArr[i]);
			if(node==null){
				return result;
			}
			else{
				trie = node;
			}
		}
		//now record all branches of the trie
		StringBuilder builder = null;
		Map<Character,Node> edgeMap = trie.edgeMap;
		if(edgeMap.isEmpty()){
			result.add(s);
			return result;
		}
		Set<Character> keys = edgeMap.keySet();
		for (Character key : keys) {
			builder = new StringBuilder(s);
			builder.append(key);
			Node nextNode = edgeMap.get(key);
			exploreTrie(nextNode, builder, result);
		}

		return result;
	}
	private static void exploreTrie(Node trie,StringBuilder builder,List<String> result){
		Map<Character,Node> edgeMap = trie.edgeMap;
		if(!edgeMap.isEmpty()){
			Set<Character> keys = edgeMap.keySet();
			for (Character key : keys) {
				builder = new StringBuilder(builder.toString());
				builder.append(key);
				Node nextNode = edgeMap.get(key);
				exploreTrie(nextNode, builder, result);
			}
		}
		//we have reached to end
		else{
			result.add(builder.toString());
		}
	}
	class Node{
		private Map<Character,Node> edgeMap;
		public Node(Map<Character,Node> edgeMap) {
			this.edgeMap = edgeMap;
		}
	}
	private  Node buildTrie(String[] contacts) {
		//add the first Node as root node with index 0
		Node root = new Node(new HashMap<Character,Node>());

		for (String contact : contacts) {
			char[] charArr = contact.toCharArray();

			//start node is always root node
			Node startNode = root;

			for (int i = 0; i < charArr.length; i++) {
				Map<Character, Node> edgeMap = startNode.edgeMap;

				//if there are no edges from current node
				if(edgeMap.isEmpty()) {
					Node endNode = new Node(new HashMap<Character,Node>());
					edgeMap.put(charArr[i], endNode);
					startNode = endNode;
				}
				else {
					//fetch node corresponding to character
					Node endNode = edgeMap.get(charArr[i]);
					//if null then add a new node
					if(endNode == null) {
						endNode = new Node(new HashMap<Character,Node>());
						edgeMap.put(charArr[i], endNode);
						startNode = endNode;
					}
					else {
						startNode = endNode;
					}
				}
			}
		}
		return root;
	}
	
}
