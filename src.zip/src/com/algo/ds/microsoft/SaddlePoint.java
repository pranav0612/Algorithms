package com.algo.ds.microsoft;

public class SaddlePoint {

	public static void main(String[] args) {
		SaddlePoint a = new SaddlePoint();
		int[][] arr = {{0,1,9},{7,5,8},{9,2,9},{4,6,7}};
		//int[][] arr = {{0,1,9,3},{7,5,8,3},{9,2,9,4},{4,6,7,1}};
		System.out.println(a.solution(arr ));
	}
	 public int solution(int[][] arr) {
		 int n = arr.length;
		 int m = arr[0].length;
		 int count =0 ;
		 if(n==1 && m ==1){
			 return 0;
		 }
		 
		 for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				//check each element - check for all corner cases
				if(i-1>=0 && j-1>=0 && i+1<n && j+1<m){
					//local maximum in row and local minimum in column
					if(arr[i][j] > arr[i+1][j] && arr[i][j] > arr[i-1][j] && arr[i][j] < arr[i][j-1] && arr[i][j] < arr[i][j+1]){
						count++;
					}
					//local minimum in row and local maximum in column
					else if(arr[i][j] < arr[i+1][j] && arr[i][j] < arr[i-1][j] && arr[i][j] > arr[i][j-1] && arr[i][j] > arr[i][j+1]){
						count++;
					}
				}
				else if(i-1>=0 && j-1>=0 && i+2<n){
					//local maximum in row and local minimum in column
					if(arr[i][j] > arr[i+1][j] && arr[i][j] > arr[i-1][j] && arr[i][j] < arr[i][j-1]){
						count++;
					}
					//local minimum in row and local maximum in column
					else if(arr[i][j] < arr[i+1][j] && arr[i][j] < arr[i-1][j] && arr[i][j] > arr[i][j-1]){
						count++;
					}
				}
//				else if(i-1>=0 && j-1>=0 && j+1<m){
//					//local maximum in row and local minimum in column
//					if(arr[i][j] > arr[i-1][j] && arr[i][j] < arr[i][j-1] && arr[i][j] < arr[i][j+1]){
//						count++;
//					}
//					//local minimum in row and local maximum in column
//					else if(arr[i][j] < arr[i-1][j] && arr[i][j] > arr[i][j-1] && arr[i][j] > arr[i][j+1]){
//						count++;
//					}
//				}
//				else if(i+1<n && j+1<m && i-1>=0){
//					//local maximum in row and local minimum in column
//					if(arr[i][j] > arr[i+1][j] && arr[i][j] > arr[i-1][j]  && arr[i][j] < arr[i][j+1]){
//						count++;
//					}
//					//local minimum in row and local maximum in column
//					else if(arr[i][j] < arr[i+1][j] && arr[i][j] < arr[i-1][j] && arr[i][j] > arr[i][j+1]){
//						count++;
//					}
//				}
//				else if(i+1<n && j+1<m && j-1>=0){
//					//local maximum in row and local minimum in column
//					if(arr[i][j] > arr[i+1][j]  && arr[i][j] < arr[i][j-1] && arr[i][j] < arr[i][j+1]){
//						count++;
//					}
//					//local minimum in row and local maximum in column
//					else if(arr[i][j] < arr[i+1][j] && arr[i][j] > arr[i][j-1] && arr[i][j] > arr[i][j+1]){
//						count++;
//					}
//				}
			}
		}
		return count;
	      
	}
}
