package com.algo.ds.pqandheaps;

public class MinHeap {
	private int array [];
	private int size;
	private int noOfElements;
	
	public MinHeap(int size){
		if(size ==0) {
			throw new IllegalArgumentException("size should be greater than 1");
		}
		this.array = new int[size];
		this.size = size;
	}
	public MinHeap(int arr[]) {
		if(arr==null){
			throw new IllegalArgumentException("input array cannot be null");
		}
		if(arr.length == 0){
			throw new IllegalArgumentException("input array should have size greater than 1");
		}
		this.array = arr;
		this.size = arr.length;
		this.noOfElements = arr.length;
		heapifyArray();
	}
	private void heapifyArray(){
		//percolate down the parent of last element and repeat till root
		int lastElementParentIndex = getParentIndex(noOfElements-1);
		for (int i = lastElementParentIndex; i >= 0; i--) {
			percolateDown(i);
		}
	}
	public int getParentIndex(int index){
		if(index<1 || index>= this.noOfElements){
			return -1;
		}
		return (index-1)/2;
	}
	public int getLeftChildIndex(int index){
		int left = 2*index + 1;
		if(left >= this.noOfElements) {
			return -1;
		}
		return left;
	}
	public int getRightChildIndex(int index){
		int right = 2*index + 2;
		if(right >= this.noOfElements) {
			return -1;
		}
		return right;
	}
	public int getMinimum() {
		if(size == 0){
			return -1;
		}
		return array[0];
	}
	public int getNoOfElements(){
		return noOfElements;
	}
	private void percolateDown(int i) {
		//the array[i] should be percolated down
		//check for invalid i
		if(i< 0 || i > size) {
			return;
		}
		int leftChildIndex = getLeftChildIndex(i);
		int rightChildIndex = getRightChildIndex(i);
		int indexToBeSwaped = -1;
		
		//check if heap property is satisfied or not 
		
		//no children, so can't go down
		if(leftChildIndex==-1 && rightChildIndex==-1) {
			return;
		}
		//heap property is satisfied, so return
		if(checkHeapPropertyForIndex(i, leftChildIndex, rightChildIndex)) {
			return;
		}
		//if left exists and greater than current element
		if( leftChildIndex!=-1 && array[leftChildIndex] < array[i]){
			indexToBeSwaped = leftChildIndex;
		}
		//if right exists and greater than current swapping element
		if(rightChildIndex!=-1 && array[rightChildIndex] < array[i] && array[rightChildIndex] < array[leftChildIndex]) {
			indexToBeSwaped = rightChildIndex;
		}
		//now swap
		int temp = array[indexToBeSwaped];
		array[indexToBeSwaped] = array[i];
		array[i] = temp;
		
		//recursively percolate down the element
		percolateDown(indexToBeSwaped);
	}
	
	private void percolateUp(int i) {
		//go up until it is root or heap property is satisfied
		while(i>0 && array[getParentIndex(i)] > array[i]){
			//swap the parent and child
			int temp = array[i];
			array[i] = array[getParentIndex(i)];
			array[getParentIndex(i)] = temp;
			
			//update i
			i  = getParentIndex(i);
		}
	}
	public void insert(int data){
		if(size==noOfElements){
			resizeHeap();
		}
		//insert the element to end of array i.e. end of tree and then percolate up
		noOfElements++;
		array[noOfElements-1] = data;// 0 based index
		//percolate up
		percolateUp(noOfElements-1);
	}
	//copy first element to some variable to return
	//copy last element to first then percolate down
	public int deleteMin(){
		//remove the root as it is the max
		int data = array[0];
		array[0] = array[noOfElements-1];
		noOfElements--;
		percolateDown(0);
		return data;
	}
	
	private void resizeHeap(){
		int[] oldArr = array;
		int[] newArr = new int[array.length*2];
		size = size*2;
		//copy elements
		for (int i = 0; i < oldArr.length; i++) {
			newArr[i] = oldArr[i];
		}
		array = newArr;
		oldArr = null;
	}
	private boolean checkHeapPropertyForIndex(int i,int leftChildIndex,int rightChildIndex){
		boolean propertySatified = true;
		if(leftChildIndex!=-1 && array[i] > array[leftChildIndex]){
			propertySatified = false;
		}
		if(rightChildIndex!=-1 && array[i] > array[rightChildIndex]){
			propertySatified = false;
		}
		return propertySatified;
	}
	public boolean isEmpty(){
		return noOfElements==0;
	}
	public int get(int i){
		if(i<0 || i>=noOfElements ){
			throw new IllegalArgumentException("Invalid index");
		}
		return array[i];
	}
	//first search the element, get it's index, then call removeAt
	public void remove(int element){
		int i = 0;
		boolean found = false;
		for (;i < array.length;i++) {
			if(array[i] == element){
				found = true;
				break;
			}
		}
		if(!found){
			System.out.println("Element not found in min heap");
			return;
		}
		removeAt(i);
	}
	public void removeAt(int index) {
		//replace this last element
		array[index] = array[noOfElements-1];
		//remove the last element
		noOfElements--;
		//now the last element was bigger so we have to percolate it down
		percolateDown(index);
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("The level order traversal of Min Heap : ");
		for (int i = 0; i < noOfElements; i++) {
			builder.append(array[i]);
			builder.append(" ");
		}
		return builder.toString();
	}
}
