package com.algo.ds.pqandheaps;

import java.util.Arrays;

public class HeapBasics {

	public static void main(String[] args) {
		//test max heap
		MaxHeap maxHeap = new MaxHeap(6);
		maxHeap.insert(1);
		maxHeap.insert(4);
		maxHeap.insert(3);
		maxHeap.insert(2);
		maxHeap.insert(5);
		maxHeap.insert(6);
		maxHeap.deleteMax();
		maxHeap.deleteMax();
		maxHeap.insert(5);
		maxHeap.insert(6);
		System.out.println(maxHeap);
		MaxHeap maxHeap2 = new MaxHeap(new int[] {1,2,3,4,5,6});
		System.out.println(maxHeap2);
		maxHeap2.remove(3);
		maxHeap2.remove(8);
		System.out.println("After removing 3 : "+maxHeap2);
		
		//test min heap
		MinHeap minHeap = new MinHeap(6);
		minHeap.insert(1);
		minHeap.insert(4);
		minHeap.insert(3);
		minHeap.insert(2);
		minHeap.insert(5);
		minHeap.insert(6);
		minHeap.deleteMin();
		minHeap.deleteMin();
		minHeap.insert(1);
		minHeap.insert(2);
		System.out.println(minHeap);
		MinHeap minHeap2 = new MinHeap(new int[] {1,2,3,4,5,6});
		System.out.println(minHeap2);
		minHeap2.remove(3);
		minHeap2.remove(8);
		System.out.println("After removing 3 : "+minHeap2);
		
		System.out.println("Sorting the array 5,2,1,4,3 using heap sort : "+Arrays.toString(heapSort(new int[]{5,4,2,1,4,3})));
	}
	public static int[] heapSort(int[] arrayToBeSorted){
		//build a heap with the help of array
		MaxHeap heap = new MaxHeap(arrayToBeSorted);
		// now delete max and return the new array
		int result[]  = new int[arrayToBeSorted.length];
		for (int i = 0; i < arrayToBeSorted.length; i++) {
			result[i] = heap.deleteMax();
		}
		return result;
	}
}
