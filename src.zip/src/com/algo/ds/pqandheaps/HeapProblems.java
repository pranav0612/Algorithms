package com.algo.ds.pqandheaps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
@SuppressWarnings("unchecked")
public class HeapProblems {

	public static void main(String[] args) throws Exception {
		MinHeap minHeap = new MinHeap(new int [] {4,1,2,3,6,5});
		System.out.println("The max element in heap is : "+getMaxElementFromMinHeap(minHeap));
		System.out.println("Printing all elements samller than 4 : ");
		printAllElementsSmallerThan_K(minHeap,4,0);
		System.out.println();
		//check the stack
		StackUsingPriorityQueue<Integer> stack = new StackUsingPriorityQueue<>();
		stack.push(1);
		stack.push(6);
		stack.push(5);
		stack.push(3);
		stack.push(10);
		stack.push(11);
		stack.push(9);

		System.out.print("The contents of stack in order : ");
		while (!stack.isEmpty()) {
			System.out.print(stack.pop()+" ");
		}
		System.out.println();
		LinkedList<Integer> [] lists = new LinkedList[3];
		lists[0] = new LinkedList<Integer>();
		lists[0].add(4);
		lists[0].add(5);
		lists[0].add(6);
		lists[0].add(7);
		lists[0].add(8);
		lists[1] = new LinkedList<Integer>();
		lists[1].add(0);
		lists[1].add(1);
		lists[1].add(2);
		lists[1].add(3);
		lists[1].add(4);
		lists[2] = new LinkedList<Integer>();
		lists[2].add(9);
		lists[2].add(10);
		lists[2].add(11);
		lists[2].add(23);
		lists[2].add(84);

		System.out.println("Merged sorted list "+mergeKSortedLists(lists));

		int[] arr1 = { 1, 3, 5, 7 };
		int[] arr2 = { 2, 4, 6, 8 };
		int[] arr3 = { 0, 9, 10, 11 };

		int[] result = mergeKSortedArray(new int[][] { arr1, arr2, arr3 });
		System.out.println("Merged sorted array : "+Arrays.toString(result));
		System.out.println("The maximum sliding window : "+getMaximumSlidingWindow(new int[]{8, 5, 10, 7, 9, 4, 15, 12, 90, 13}, 4));
	}

	//the max element will be one of the leaves, so just examine all leaves get the max
	//the node after the last parent is the first leaf node.
	private static int getMaxElementFromMinHeap(MinHeap minHeap){
		int max = 0;
		int lastParentIndex = minHeap.getParentIndex(minHeap.getNoOfElements()-1);
		int firstChildIndex = lastParentIndex+1;
		for (int i = firstChildIndex; i < minHeap.getNoOfElements(); i++) {
			max = Math.max(max, minHeap.get(i));
		}
		return max;
	}

	//one way to scan array elements = O(n)
	//other way, start with root, go down until element is smaller
	private static void printAllElementsSmallerThan_K(MinHeap minHeap,int k,int index){
		//base case
		if(index < 0 || index >= minHeap.getNoOfElements()){
			return;
		}
		if(minHeap.get(index)< k){
			//print the node
			System.out.print(minHeap.get(index)+" ");
			//check the left and right children
			int leftChilIndex = minHeap.getLeftChildIndex(index);
			if(leftChilIndex!=-1){
				printAllElementsSmallerThan_K(minHeap, k, leftChilIndex);
			}
			int rightChildIndex = minHeap.getRightChildIndex(index);
			if(rightChildIndex!=-1){
				printAllElementsSmallerThan_K(minHeap, k, rightChildIndex);
			}
		}
	}
	//Similarly we can implement queue just reverse the compareTo method.
	private static class StackUsingPriorityQueue<T> {
		private static class Element<T> implements Comparable<Element<T>>{
			private T t;
			private int priority;
			@Override
			public int compareTo(Element<T> o) {
				return o.priority - this.priority;
			}
		}
		private int montonicPriority = 0;
		private PriorityQueue<Element<T>> queue = new PriorityQueue<>();
		public void push(T t){
			Element<T> element =  new Element<>();
			element.t = t;
			element.priority = ++montonicPriority;
			queue.offer(element);
		}
		public boolean isEmpty(){
			return queue.isEmpty();
		}
		public T pop() throws Exception{
			if(!isEmpty()){
				montonicPriority--;
				return queue.poll().t;
			}
			else{
				throw new Exception("Stack underflow!");
			}
		}

	}
	//this is n*log(k).
	private static List<Integer> mergeKSortedLists(LinkedList<Integer> [] lists){
		if(lists==null||lists.length==0) {
			return null;
		}
		List<Integer> result =  new ArrayList<Integer>();
		PriorityQueue<LinkedList<Integer>> queue = new PriorityQueue<>(new Comparator<LinkedList<Integer>>() {
			@Override
			public int compare(LinkedList<Integer> o1,LinkedList<Integer> o2) {
				return o1.getFirst() - o2.getFirst();
			}
		});
		for(LinkedList<Integer> list: lists){
			if(list!=null){
				queue.offer(list);
			}
		}
		while(!queue.isEmpty()){
			//this will eject the list with max first element
			LinkedList<Integer> n = queue.poll();
			//this will remove the max element
			result.add(n.remove());
			if(!n.isEmpty()) {
				//this will add back the list if it's not empty
				queue.offer(n);
			}
		}
		return result;
	}
	private static class ArrayContainer implements Comparable<ArrayContainer> {
		int[] arr;
		int index;

		public ArrayContainer(int[] arr, int index) {
			this.arr = arr;
			this.index = index;
		}

		@Override
		public int compareTo(ArrayContainer o) {
			return this.arr[this.index] - o.arr[o.index];
		}
	}
	public static int[] mergeKSortedArray(int[][] arr) {
		//PriorityQueue is heap in Java 
		PriorityQueue<ArrayContainer> queue = new PriorityQueue<ArrayContainer>();
		int total=0;

		//add arrays to heap
		for (int i = 0; i < arr.length; i++) {
			queue.add(new ArrayContainer(arr[i], 0));
			total = total + arr[i].length;
		}

		int m=0;
		int result[] = new int[total];

		//while heap is not empty
		while(!queue.isEmpty()){
			ArrayContainer ac = queue.poll();
			result[m++]=ac.arr[ac.index];

			if(ac.index < ac.arr.length-1){
				queue.add(new ArrayContainer(ac.arr, ac.index+1));
			}
		}

		return result;
	}
	/*
	 We create a Dequeue, Qi of capacity k, that stores only useful elements of current window of k elements. 
	 An element is useful if it is in current window and is greater than all other elements on left side of it in current window.
	 We process all array elements one by one and maintain Qi to contain useful elements of current window and 
	 these useful elements are maintained in sorted order. The element at front of the Qi is the largest 
	 and element at rear of Qi is the smallest of current window.  
	*/
	private static List<Integer> getMaximumSlidingWindow(int a[],int w) {
		List<Integer> result = new ArrayList<Integer>();
		Deque<Integer> queue = new LinkedList<Integer>();
		//process first w elements
		for (int i = 0; i < w; i++) {
			//the main code that does the magic-> that reduces the time complexity to O(n)
			//remove not useful elements from queue - remove from last, and we store indexes in queue
			while (!queue.isEmpty() && a[i]>=a[queue.getLast()]) {
				queue.pollLast();
			}
			// Add new element at rear of queue
			queue.addLast(i);
		}
		
		// Process rest of the elements
		for (int i = w; i < a.length; i++) {
			//the front of the queue will always contain the max element, we will add it to result
			result.add(a[queue.getFirst()]);
			
			//remove elements which are out of the window, front will be the oldest index so it should be greater than i-w
			//i-w is current index from which window starts
			while (!queue.isEmpty() && queue.getFirst()<=i-w ) {
				queue.pollFirst();
			}
			//remove not useful elements
			while (!queue.isEmpty() && a[i]>=a[queue.getLast()]) {
				queue.pollLast();
			}
			//Add current element at the rear of queue
	        queue.addLast(i);
		}
		//add the maximum of last window
		result.add(a[queue.getFirst()]);
		return result;
	}
}
