package com.algo.ds.divideandconquer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DivideAndConquerProblemsA {

	public static void main(String[] args) {
		System.out.println("Fixed point in array :"+getFixedPoint(new int[]{10, -1, 0, 3 , 10, 11, 30, 50, 100}, 0,8));
		System.out.println("The median of 2 arrays : "+getMedianOFTwoSortedArrays(new int []{1, 2, 3, 6},0,3,new int []{4, 6, 8, 10},0,3));
		System.out.println("Maximum profit : "+getMaximumProfitFromStocksWithOneTransaction(new int[]{1, 2, 90, 10, 110}));
		System.out.println("Maximum profit using V2 : "+getMaximumProfitFromStocksWithOneTransactionVersion2(new int[]{1, 2, 90, 10, 110}));
		System.out.println("Buying and selling days for maximum profit are : "+getMaximumProfitFromStocksWithMultipleTransactions(new int[]{100, 180, 260, 310, 40, 535, 695}));
		System.out.println("9 is a square : "+checkNumberIsSquare(9));
		System.out.println("The maximum contiguous sum : "+getMaximumValueContiguosSubsequence(new int[]{-2, -3, 4, -1, -2, 1, 5, -3},0, 7));
		System.out.print("After shuffling : ");
		int a[] = {1,2,3,4,1,2,3,4};
		shuffleArray(a,0,7);
		System.out.println(Arrays.toString(a));
	}
	//problem : find an index where a[i] = i in sorted array in log(n)
	private static int getFixedPoint(int a[],int low,int high){
		//use divide and conquer
		if(high>=low){
			int mid = low+ (high-low)/2;
			if(mid==a[mid]){
				return mid;
			}
			else if(mid>a[mid]){
				return getFixedPoint(a, mid+1, high);
			}
			else{
				return getFixedPoint(a, low, mid-1);
			}
		}
		return -1;
	}
	//Find the median of 2 sorted arrays
	//D&Q gives O(logn) complexity.
	//Algo : refer doc
	private static double getMedianOFTwoSortedArrays(int a[],int start1,int end1,int b[],int start2,int end2){
		int l1 = end1-start1;
		int l2 = end2-start2;
		
		//base case when we have 1 element in each array
		if(l1==0 && l2==0){
			return (a[0]+b[0])/2;
		}
		//base case when we have 2 elements in each array
		if(l1==1 && l2==1){
			return 1.0*(Math.max(a[start1],b[start2]) + Math.min(a[end1], b[end2]))/2;
		}
		double m1 = getMedianOFArray(a,start1,end1);
		double m2 = getMedianOFArray(b,start2,end2);
		
		if(m1==m2){
			return m1;
		}
		//so we have to consider 2 subarrays
		//consider from m1 to last element of ar1 and first element to m2 in ar2
		if(m1<m2){
			//case for even 
			if(l1%2==0){
				start1 = start1 + l1/2;
				end2 = start2 + l2/2;
			}
			else{
				start1 = start1 + l1/2;
				end2 = start2 + (l2/2) +1;
			}
		}
		//consider from first element to m1 of ar1 and m2 to last element in ar2
		else {
			//case for even 
			if(l2%2==0){
				start2 = start2 + l2/2;
				end2 = start1 + l2/2;
			}
			else{
				start2 = start2 + l2/2;
				end1 = start1 + (l1/2) +1;
			}
		}
		return getMedianOFTwoSortedArrays(a, start1, end1, b, start2, end2);
	}
	private static double getMedianOFArray(int[] a,int start,int end){
		int n = end-start;
		if(n%2==0){
			return a[start+(n/2)];
		}
		else {
			return 1.0*(a[start+(n/2)]+a[start+(n/2) +1])/2;
		}
	}
	
	//Variant 1 : Only one transaction allowed
	//Problem boils downs to finding maximum difference between elements where larger element appears after smaller number
	private static int getMaximumProfitFromStocksWithOneTransaction(int[] stockPrices){
		//initial values
		int maxiDiff = stockPrices[1] - stockPrices[0];
		int smallestBase = stockPrices[0];
		
		//now update these values , iterate to find the maxdiff 
		for (int i = 1; i < stockPrices.length; i++) {
			if(stockPrices[i] - smallestBase > maxiDiff){
				//update the max diff
				maxiDiff = stockPrices[i] - smallestBase;
			}
			if(stockPrices[i] < smallestBase){
				//update smallest base
				smallestBase = stockPrices[i];
			}
		}
		return maxiDiff;
	}
	//another solution for above problem : this is based of diff between adjacent elements and taking the maximum sum of diff
	private static int getMaximumProfitFromStocksWithOneTransactionVersion2(int[] stockPrices){
		//initial values
		int diff = stockPrices[1] - stockPrices[0];
		int currentDiffSum = diff;
		int maximumDiffSum = diff;
		
		//now update values by iterating
		for (int i = 1; i < stockPrices.length-1; i++) {
			diff = stockPrices[i+1] - stockPrices[i];
			//we will keep on adding diff if the currentDiffsum is greater than 0
			if(currentDiffSum > 0){
				currentDiffSum += diff;
			}
			//else we will start again
			else {
				currentDiffSum = diff;
			}
			//capture the maximum currentDiifSum
			if(currentDiffSum>maximumDiffSum){
				maximumDiffSum = currentDiffSum;
			}
		}
		return maximumDiffSum;
	}
	private static List<BuySellDayPair> getMaximumProfitFromStocksWithMultipleTransactions(int[] stockPrices){
		//find local maxima and local minima. These are pairs.
		List<BuySellDayPair> result = new ArrayList<>();
		//initial values
		int localMinima = 0;
		int localMaxima = 0;
		for (int i = 0; i < stockPrices.length-1; i++) {
			//find a local minima first
			while (i < stockPrices.length-1 && !(stockPrices[i]<stockPrices[i+1])) {
				i++;
			}
			localMinima = i;
			//lets find out local maxima
			i++;
			while (i < stockPrices.length-1 && !(stockPrices[i]>stockPrices[i+1])) {
				i++;
			}
			localMaxima = i;
			result.add(new BuySellDayPair(localMinima,localMaxima));
		}
		return result;
	}
	private static class BuySellDayPair{
		
		public BuySellDayPair(int buyDayIndex,int sellDayIndex) {
			this.buyDayIndex = buyDayIndex;
			this.sellDayIndex = sellDayIndex;
		}
		int buyDayIndex;
		int sellDayIndex;
		
		@Override
		public String toString() {
			return "Buy day : "+buyDayIndex+" Selling day : "+sellDayIndex;
		}
	}
	private static boolean checkNumberIsSquare(int n){
		//start with 1 and go until i*i < n
		for (int i = 1;; i++) {
			if(i*i == n){
				return true;
			}
			if(i*i >n){
				break;
			}
		}
		return false;
	}
	//Problem : find the sum of contiguous subarray within a one-dimensional array of numbers which has the largest sum.
	//e.g. {-2, -3, 4, -1, -2, 1, 5, -3} gives  {4 + (-1) + (-2)+ 1+5} = 7
	//D&Q algorithm - O(nlog(n)). using DP we can solve it in O(n)
	//1.Recursively compute the maximum contiguous subsequence in first half
	//2.Recursively compute the maximum contiguous subsequence in second half
	//3.Compute via 2 loops maximum contiguous subsequence that begins in first half and end in second half
	//4.Choose the largest of the sums.
	private static int getMaximumValueContiguosSubsequence(int a[],int left,int right){
		
		int mid = left+ (right-left)/2;
		//base case when we have reached to one element. In that case return the element if it is positive else return 0(ignore it)
		if(left == right){
			return a[left]>0 ? a[left] : 0;
		}
		//recursively compute left max sum
		int maxLeftSum = getMaximumValueContiguosSubsequence(a,left,mid);
		
		//recursively compute right max sum
		int maxRightSum = getMaximumValueContiguosSubsequence(a,mid+1, right);
		
		//now 2 consecutive loops
		int maxLeftBorderSum = 0;
		int sum = 0;
		//very important: We are going from mid to left not from left to mid, the order matters as we have to consider contiguous sequence :) 
		//so all contiguous sequence is considered from mid to left and mid to right combined
		for (int i = mid; i >=left; i--) {
			sum += a[i];
			if(sum>maxLeftBorderSum){
				maxLeftBorderSum = sum;
			}
		}
		int maxRightBorderSum = 0;
		sum = 0;
		for (int i = mid+1; i <=right; i++) {
			sum += a[i];
			if(sum>maxRightBorderSum){
				maxRightBorderSum = sum;
			}
		}
		return Math.max(maxLeftBorderSum+maxRightBorderSum,Math.max(maxLeftSum, maxRightSum));
	}

	//Problem : we have array of 2n elements format a1,a2,a3..an,b1,b2,b3...bn. Shuffle it as a1,b1,a2,b2,...an,bn
	//below solution works when n = 2^i.
	//Algorithm : split array in half, exchange elements around center, recursively do for left and right
	private static void shuffleArray(int a[],int left,int right){
		int midIndex = (left + right)/2;
		int quaterIndex = left + (midIndex-left)/2 +1;
		//base case
		if(left == right){
			return;
		}
		for (int i = quaterIndex,j = midIndex+1; i<=midIndex; i++,j++) {
			//swap elements around center
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
		shuffleArray(a, left,midIndex);
		shuffleArray(a,midIndex+1,right);
	}
}
