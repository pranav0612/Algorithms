package com.algo.ds.divideandconquer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class ClosestPair {

	public static void main(String[] args) {
		int numPoints = (args.length == 0) ? 1000 : Integer.parseInt(args[0]);
		List<Point> points = new ArrayList<Point>();
		
		//generate random points
		Random r = new Random();
		for (int i = 0; i < numPoints; i++){
			points.add(new Point(r.nextDouble(), r.nextDouble()));
		}
			
		System.out.println("Generated " + numPoints + " random points");
		long startTime = System.currentTimeMillis();
		Pair bruteForceClosestPair = bruteForce(points);
		long elapsedTime = System.currentTimeMillis() - startTime;
		System.out.println("Brute force (" + elapsedTime + " ms): " + bruteForceClosestPair);
		
		startTime = System.currentTimeMillis();
		Pair dqClosestPair = divideAndConquer(points);
		elapsedTime = System.currentTimeMillis() - startTime;
		System.out.println("Divide and conquer (" + elapsedTime + " ms): " + dqClosestPair);
		
		if (bruteForceClosestPair.distance != dqClosestPair.distance){
			System.out.println("MISMATCH");
		}
	}

	private static Pair divideAndConquer(List<Point> points) {
		//we need 2 lists one sorted by x coordinates and second by y coordinates. This is pre-processing
		List<Point> sortedByXPoints = new ArrayList<Point>(points);
		sortListByXCoordinate(sortedByXPoints);
		
		List<Point> sortedByYPoints = new ArrayList<Point>(points);
		sortListByYCoordinate(sortedByYPoints);
		
		//now finally find the closest pair using D&Q
		return divideNConquer(sortedByXPoints, sortedByYPoints);
	}
	private static Pair divideNConquer(List<Point> sortedByXPoints,List<Point> sortedByYPoints) {
		int noOfPoints = sortedByXPoints.size();
		//base case when size <=3
		if(noOfPoints<=3) {
			return bruteForce(sortedByXPoints);
		}
		//find the midpoint according to x-coordinates, so we are dividing whole list into 2 halves
		int dividingIndex = noOfPoints/2;
		
		//create 2 halves
		List<Point> leftHalf = sortedByXPoints.subList(0, dividingIndex);
		List<Point> rightHalf = sortedByXPoints.subList(dividingIndex,noOfPoints);
		
		//create temporary list for sorting with y coordinates for left half
		List<Point> tempList = new ArrayList<>(leftHalf);
		sortListByYCoordinate(tempList);
		
		//recursively calculate the closest in left half
		Pair closestPairInleft = divideNConquer(leftHalf, tempList);
		
		//Now do the same for right half. We have to get the closest pair in right half
		tempList.clear();
		tempList.addAll(rightHalf);
		sortListByYCoordinate(tempList);
		Pair closestPairInRight = divideNConquer(rightHalf,tempList);
		
		//chose the pair whose distance is less
		Pair closestPair = null;
		if(closestPairInleft.distance<closestPairInRight.distance){
			closestPair = closestPairInleft;
		}
		else{
			closestPair = closestPairInRight;
		}
		//clear the list for further use
		tempList.clear();
		
		double shortestDistance = closestPair.distance;
		//now the first element in right half is the center point
		double centerX = rightHalf.get(0).x;
		
		//filter only those points which are nearer to center point than current closest pair distance. We are comparing the 
		//the distances horizontally first. These are the elements of strip
		for (Point point : sortedByYPoints) {
			if (Math.abs(centerX - point.x) < shortestDistance){
				tempList.add(point);
			}
		}
		
		//Below code finds the distance between the closest points of strip of given size. All points in strip are sorted according
		//to y coordinate. They all have an upper bound on minimum distance as shortestDistance.This seems to be a O(n^2), 
		//but it's a O(n) as the inner loop runs at most 6 times
		for (int i = 0; i < tempList.size()-1; i++) {
			Point point1 = tempList.get(i);
			for (int j = i + 1; j < tempList.size(); j++) {
				Point point2 = tempList.get(j);
				if ((point2.y - point1.y) >= shortestDistance) {
					break;
				}
				double distance = Pair.calculateDistance(point1, point2);
				if (distance < closestPair.distance){
					closestPair.update(point1, point2);
					shortestDistance = distance;
				}
			}
		}
				
		return closestPair;
	}

	private static Pair bruteForce(List<Point> points) {
		int noOfPoints = points.size();
		if(noOfPoints<2) {
			return null;
		}
		Pair closestPair = new Pair(points.get(0),points.get(1));
		if(noOfPoints>2) {
			for(int i=0;i<noOfPoints-1;i++) {
				for(int j=i+1;j<noOfPoints;j++) { // i+1 because we already compared ith with all
					if(Pair.calculateDistance(points.get(i),points.get(j)) < closestPair.distance) {
						closestPair.update(points.get(i), points.get(j));
					}
				}
			}
		}
		return closestPair;
	}
	private static class Point{
		double x;
		double y;

		Point(double x, double y){
			this.x = x;
			this.y = y;
		}
		public String toString(){  
			return "(" + x + ", " + y + ")";
		}
	}
	private static class Pair {
		Point point1;
		Point point2;
		double distance = 0.0;
		
		public Pair(Point point1, Point point2){
			this.point1 = point1;
			this.point2 = point2;
			calculateDistanceAndSet();
		}
		public void update(Point point1, Point point2){
			this.point1 = point1;
			this.point2 = point2;
			calculateDistanceAndSet();
		}
		public void calculateDistanceAndSet(){  
			this.distance = calculateDistance(point1, point2); 
		}
		private static double calculateDistance(Point point1, Point point2) {
			return Math.hypot(point1.x-point2.x,point1.y-point2.y);
		}
		public String toString(){  
			return point1 + "-" + point2 + " : " + distance;
		}
	}
	public static void sortListByXCoordinate(List<Point> points){
		Collections.sort(points,new Comparator<Point>() {
			@Override
			public int compare(Point point1, Point point2) {
				if (point1.x < point2.x){
					return -1;
				}	
				if (point1.x > point2.x){
					return 1;
				}
				return 0;
			}
		});
	}
	public static void sortListByYCoordinate(List<Point> points){
		Collections.sort(points,new Comparator<Point>() {
			@Override
			public int compare(Point point1, Point point2) {
				if (point1.y < point2.y){
					return -1;
				}	
				if (point1.y > point2.y){
					return 1;
				}
				return 0;
			}
		});
	}
}
