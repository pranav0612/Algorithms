package com.algo.ds.divideandconquer;

import java.util.Arrays;

public class MatrixMultplicationStrassen {
	private static int[][] multiply(int a[][],int b[][]) {
		int n = a.length;
		int c[][] = new int[n][n];
		if(a.length==1) {
			c[0][0] = a[0][0] * b[0][0];
		}
		else {
			// partition array A into 4 parts
			int a11[][] = new int[n/2][n/2];
			int a12[][] = new int[n/2][n/2];
			int a21[][] = new int[n/2][n/2];
			int a22[][] = new int[n/2][n/2];

			split(a, a11, 0, 0);
			split(a, a12,0,n/2);
			split(a, a21, n/2,0);
			split(a, a22, n/2, n/2);

			// split B in four parts
			int b11[][] = new int[n/2][n/2];
			int b12[][] = new int[n/2][n/2];
			int b21[][] = new int[n/2][n/2];
			int b22[][] = new int[n/2][n/2];

			split(b, b11, 0, 0);
			split(b, b12,0,n/2);
			split(b, b21, n/2,0);
			split(b, b22, n/2, n/2);

			/** 
            M1 = (A11 + A22)(B11 + B22)
            M2 = (A21 + A22) B11
            M3 = A11 (B12 - B22)
            M4 = A22 (B21 - B11)
            M5 = (A11 + A12) B22
            M6 = (A21 - A11) (B11 + B12)
            M7 = (A12 - A22) (B21 + B22)
			 **/
			// 7 recursive calls
			int m1[][] = multiply(add(a11, a22), add(b11, b22));
			int m2[][] = multiply(add(a21, a22), b11);
			int m3[][] = multiply(a11, sub(b12, b22));
			int m4[][] = multiply(a22, sub(b21, b11));
			int m5[][] = multiply(add(a11, a12), b22);
			int m6[][] = multiply(sub(a21, a11), add(b11, b12));
			int m7[][] = multiply(sub(a12, a22), add(b21, b22));

			/**
            C11 = M1 + M4 - M5 + M7
            C12 = M3 + M5
            C21 = M2 + M4
            C22 = M1 - M2 + M3 + M6
			 **/
			int [][] c11 = add(sub(add(m1, m4), m5), m7);
			int [][] c12 = add(m3, m5);
			int [][] c21 = add(m2, m4);
			int [][] c22 = add(sub(add(m1, m3), m2), m6);

			join(c11, c, 0, 0);
			join(c12, c, 0, n/2);
			join(c21, c, n/2, 0);
			join(c22, c, n/2, n/2);
		}
		return c;
	}
	public static void main(String[] args) {
		int a[][] = {
				{2,3,1,6},
				{4,0,0,2},
				{4,2,0,1},
				{0,3,5,2}
		};
		int b[][] = {
				{3,0,4,3},
				{1,2,0,2},
				{0,3,1,4},
				{5,1,3,2}
		};
		int result[][] = multiply(a, b);
		for (int i = 0; i < result.length; i++) {
			System.out.println(Arrays.toString(result[i]));
			System.out.println();
		}
	}
	private static void split(int arrayToBeSplited[][],int resultArray[][],int startRow,int startColumn){
		for (int i = 0,i1=startRow; i < resultArray.length; i++,i1++) {
			for (int j = 0,j1=startColumn; j < resultArray.length; j++,j1++) {
				resultArray[i][j] = arrayToBeSplited[i1][j1];
			}
		}
	}
	private static void join(int childArray[][],int parentArray[][],int startRow,int startColumn) {
		for (int i = 0,i1=startRow; i < childArray.length; i++,i1++) {
			for (int j = 0,j1=startColumn; j < childArray.length; j++,j1++) {
				parentArray[i1][j1] = childArray[i][j];
			}
		}
	}
	private static int[][] add(int[][] A, int[][] B) {
		int[][] C = new int[A.length][A.length];
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A.length; j++) {
				C[i][j] = A[i][j] + B[i][j];
			}
		}
		return C;
	}
	private static int[][] sub(int[][] A, int[][] B) {
		int[][] C = new int[A.length][A.length];
		for (int i = 0; i < A.length; i++) {
			for (int j = 0; j < A.length; j++) {
				C[i][j] = A[i][j] - B[i][j];
			}
		}
		return C;
	}
}
