package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;
import com.algo.ds.linkedlist.basics.InsertIntoLinkedList;
import com.algo.ds.linkedlist.basics.LinkedListUtils;

//Given two linked lists, insert nodes of second list into first list at alternate positions of first list.
//For eg, if first list is 5->7->17->13->11 and second is 12->10->2->4->6, the first list should become 5->12->7->10->17->2->13->4->11->6 and
// second list should become empty. The nodes of second list should only be inserted when there are positions available. For example,
// if the first list is 1->2->3 and second list is 4->5->6->7->8, then first list should become 1->4->2->5->3->6 and second list to 7->8.
//Use of extra space is not allowed (Not allowed to create additional nodes), i.e., insertion must be done in-place.
// Expected time complexity is O(n) where n is number of nodes in first list.
public class MergeTwoLLWithAltPosition {

    static Node n1;
    static Node n2;
    public static void main(String[] args) {
       n1 = new Node(3);
       n1 = pushANewNodeToGivenNode(n1,2);
       n1 = pushANewNodeToGivenNode(n1,1);

        n2 = new Node(8);
        n2 = pushANewNodeToGivenNode(n2,7);
        n2 = pushANewNodeToGivenNode(n2,6);
        n2 = pushANewNodeToGivenNode(n2,5);
        n2 = pushANewNodeToGivenNode(n2,4);
        System.out.println("First list before merge : "+n1);
        System.out.println("Second list before merge : "+n2);
        mergeTwoList(n1,n2);
        System.out.println("First list after merge : "+n1);
        System.out.println("Second list after merge : "+n2);
    }

    private static Node mergeTwoList(Node n1, Node n2){
        if(n1 == null){
            return null;
        }
        if(n2 == null){
            return n1;
        }
        Node next1 = n1.getNext();
        MergeTwoLLWithAltPosition.n2 = n2.getNext();
        n1.setNext(n2);
        n2.setNext(mergeTwoList(next1,n2.getNext()));
        MergeTwoLLWithAltPosition.n1 = n1;
        return n1;
    }
    private static Node pushANewNodeToGivenNode(Node givenNode,int data){
        Node node = new Node(data);
        node.setNext(givenNode);
        return node;
    }
}
