package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;

public class NthNodeFromLast {

	public static void main(String[] args) {
		Node head = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
		Node node4 = new Node(4);
		Node node5 = new Node(5);
		Node node6 = new Node(6);
		head.setNext(node2);
		node2.setNext(node3);
		node3.setNext(node4);
		node4.setNext(node5);
		node5.setNext(node6);
		System.out.println("Linked list : "+head);
		System.out.println(nthNodeFromLast(head, 2));
	}
	//one approach is just find length and go to length-n+1 node
    // best way -- do it in one scan
	private static Node nthNodeFromLast(Node head,int n) {
		Node firstPointer = head;
		Node secondPointer = head;
		int count = 1;
		while(firstPointer.getNext()!=null) {
			if(count == n) {
				secondPointer = secondPointer.getNext();
				firstPointer = firstPointer.getNext();
			}
			else{
				count++;
				firstPointer = firstPointer.getNext();
			}
		}
		return secondPointer;
	}
}
