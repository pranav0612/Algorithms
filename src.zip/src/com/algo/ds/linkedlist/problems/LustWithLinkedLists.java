package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.CLLNode;
import com.algo.ds.common.Node;
import com.algo.ds.linkedlist.basics.LinkedListUtils;

public class LustWithLinkedLists {

	public static void main(String[] args) {
		Node head = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
		Node node4 = new Node(4);
		Node node5 = new Node(5);
		head.setNext(node2);
		node2.setNext(node3);
		node3.setNext(node4);
		node4.setNext(node5);
		System.out.println("Reversing the list : "+head+" in pairs : "+(head = reverseLinkedListInPairRecursive(head)));
		System.out.println("Reversing the list : "+head+" in pairs again  : "+(head = reverseLinkedListInPairIterative(head)));

		CLLNode node1c = new CLLNode(1);
		CLLNode node2c = new CLLNode(2);
		CLLNode node3c = new CLLNode(3);
		CLLNode node4c = new CLLNode(4);
		CLLNode node5c = new CLLNode(5);
		node1c.setNext(node2c);
		node2c.setNext(node3c);
		node3c.setNext(node4c);
		node4c.setNext(node5c);
		node5c.setNext(node1c);

		System.out.println("The original circular linked list is "+node1c);
		CLLNode heads[] = splitCircularLinkedListIntoTwoCircularLinkedList(node1c);
		System.out.println("First half : "+heads[0]+" Second half : "+heads[1]);

		//creating a palindrome list
		Node palindrome = new Node(1);
		Node p2 = new Node(2);
		Node p3 = new Node(3);
		Node p4 = new Node(2);
		Node p5 = new Node(1);
		palindrome.setNext(p2);
		p2.setNext(p3);
		p3.setNext(p4);
		p4.setNext(p5);

		System.out.println("The list : "+palindrome+ " is palindrome : "+isLinkedListPalindrome(palindrome));

		Node node6 = new Node(6);
		node5.setNext(node6);
		Node node7 = new Node(7);
		node6.setNext(node7);
		//reverse linked list k nodes at a time
		int k = 3;
		System.out.println("Reversing the list : "+head+" "+k+" Nodes at a time : "+reverseKBlocksAtATimeLinkedList(head, k));
		//create a new linked list for joseph circle
		CLLNode node1a = new CLLNode(1);
		CLLNode node2a = new CLLNode(2);
		CLLNode node3a = new CLLNode(3);
		CLLNode node4a = new CLLNode(4);
		CLLNode node5a = new CLLNode(5);
		node1a.setNext(node2a);
		node2a.setNext(node3a);
		node3a.setNext(node4a);
		node4a.setNext(node5a);
		node5a.setNext(node1a);
		
		System.out.println("Removing nodes from list :"+node1a+" The result is : "+getLastOneFromJosephCircle(node1a, 2));
		
	}

	private static Node reverseLinkedListInPairRecursive(Node head) {
		if(head==null || head.getNext()==null) {
			return head;
		}
		//reverse the first pair
		Node nextNode = head.getNext();
		Node temp = nextNode.getNext();
		nextNode.setNext(head);
		head.setNext(reverseLinkedListInPairRecursive(temp));
		return nextNode;
	}
	private static Node reverseLinkedListInPairIterative(Node head) {
		if(head==null) {
			return null;
		}
		Node currentPointer = head;
		Node previousNode = null;
		Node result = null;
		while(currentPointer!=null && currentPointer.getNext()!=null) {

			//reverse the pair and move ahead
			Node nextNode = currentPointer.getNext();
			currentPointer.setNext(nextNode.getNext());
			nextNode.setNext(currentPointer);
			if(previousNode!=null) {
				previousNode.setNext(nextNode);
			}
			previousNode = currentPointer;
			currentPointer = currentPointer.getNext();
			if(result==null) {
				result = nextNode;
			}
		}
		return result;
	}
	private static CLLNode[] splitCircularLinkedListIntoTwoCircularLinkedList(CLLNode head) {
		if(head==null) {
			System.err.println("Fuck off list is empty");
		}
		//take 2 pointers one fast and one slow
		CLLNode slowPtr = head;
		CLLNode fastPtr = head;
		CLLNode head1 = null;
		CLLNode head2 = null;
		//first condition for odd and second for even
		while(fastPtr.getNext()!=head && fastPtr.getNext().getNext()!=head) {
			fastPtr = fastPtr.getNext().getNext();
			slowPtr = slowPtr.getNext();
		}
		//this means its odd as fast pointer hops only on odd numbered nodes
		if(fastPtr.getNext()==head) {
			head1 = head;
			head2 = slowPtr.getNext();
			//make lists circular
			slowPtr.setNext(head1);
			fastPtr.setNext(head2);
		}
		//even
		else{
			head1 = head;
			head2 = slowPtr.getNext();
			// make the lists circular
			slowPtr.setNext(head1);
			fastPtr.getNext().setNext(head2);
		}
		return new CLLNode[]{head1,head2};
	}
	private static boolean isLinkedListPalindrome(Node head) {
		boolean isPalindrome = true;
		//get in the middle of linked list using 2 pointers
		Node slowPtr = head;
		Node fastPtr = head;
		while(fastPtr.getNext()!=null && fastPtr.getNext().getNext()!=null) {
			fastPtr = fastPtr.getNext().getNext();
			slowPtr = slowPtr.getNext();
		}
		//reverse the second half
		Node reversedListHead = FunWithLinkedList.reverseLinkedList(slowPtr.getNext());
		Node listToBeReversedAgain = reversedListHead;
		Node firstListHead = head;
		while(reversedListHead!=null) {
			if(firstListHead.getData()!=reversedListHead.getData()) {
				isPalindrome =  false;
				break;
			}
			firstListHead = firstListHead.getNext();
			reversedListHead = reversedListHead.getNext();
		}
		//reverse the second half again and join
		slowPtr.setNext(FunWithLinkedList.reverseLinkedList(listToBeReversedAgain));
		return isPalindrome;
	}
	private static Node reverseKBlocksAtATimeLinkedList(Node head,int k) {
		if(k==0 || k==1) {
			return head;
		}
		Node currentNode = head;
		Node previousNode = null;
		KthNode kthNode = checkAndReturnKthNode(head, k);
		Node newHead = kthNode.kthNode;
		if(kthNode.proceedWithReversal) {
			while(true) {
				int i = 1;
				Node intermediateLinkedNode = null;
				//reverse nodes till kth node
				while(i<=k) {
					if(intermediateLinkedNode==null) {
						intermediateLinkedNode = currentNode;
					}
					Node temp = currentNode;
					//move one step
					currentNode =  currentNode.getNext();
					//reverse previous
					temp.setNext(previousNode);
					previousNode = temp;
					i++;

					if(newHead==null) {
						newHead = previousNode;
					}
				}
				kthNode = checkAndReturnKthNode(currentNode, k);
				intermediateLinkedNode.setNext(kthNode.kthNode);
				if(!kthNode.proceedWithReversal){
					break;
				}
			}
			//attach left over nodes
			if(currentNode!=null) {
				previousNode.setNext(currentNode);
			}

		}

		return newHead;
	}
	private static class KthNode{
		private Node kthNode;
		private boolean proceedWithReversal;
	}
	private static KthNode checkAndReturnKthNode(Node start,int k) {
		int i = 1;
		while(start!=null && i!=k) {
			start = start.getNext();
			i++;
		}
		KthNode result = new KthNode();
		result.kthNode = start;
		if(start==null) {
			result.proceedWithReversal = false;
			return result;
		}
		else {
			result.proceedWithReversal = true;
			return result;
		}
	}
	private static CLLNode getLastOneFromJosephCircle(CLLNode head,int m) {
		// get the length of the circular linked list
		int n = LinkedListUtils.getLength(head);
		// Iteratively remove the mth node
		
		for(int i=0 ; i<n-1;i++) {
			for (int j = 0; j < m-1; j++) {
				head = head.getNext();
			}
			head.setNext(head.getNext().getNext());
		}
		return head;
	}
}
