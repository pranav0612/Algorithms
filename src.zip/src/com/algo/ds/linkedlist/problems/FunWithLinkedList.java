package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;

public class FunWithLinkedList {

	public static void main(String[] args) throws Exception {

		//create a sorted linked list
		Node head = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
		head.setNext(node2);
		node2.setNext(node3);

		//insert an element in sorted linked list
		Node node4 = new Node(4);
		System.out.println(head = insertNodeInSortedLinkedList(head, node4));

		//Insert another 
		Node anotherNode = new Node(5);
		head = insertNodeInSortedLinkedList(head, anotherNode);
		//reverse the linked list
		System.out.println(head=reverseLinkedList(head));

		//creating an intersecting linked list
		Node head1=reverseLinkedList(head);
		Node head2 = new Node(11);
		Node node22 = new Node(22);
		Node node33 = new Node(33);
		head2.setNext(node22);
		node22.setNext(node33);
		node33.setNext(node4);

		System.out.println("The intersection of linked list : "+findIntersectionOfLinkedList(head1, head2));

		System.out.println("Middle of linked list "+head1+" is : "+findMiddleOfLinkedList(head1));
		System.out.println("Printing the linked list from back : ");
		displayLinkedListFromLast(head1);
		System.out.println();
		System.out.println("The linked list : "+head1+ " is even : "+isLinkedListEven(head2));
		Node lastNodeWillBeInserted = new Node(6);
		System.out.println("head1  :"+head1+" , lastNodeWillBeInserted: "+lastNodeWillBeInserted);
		System.out.println("Merged list : "+mergeTwoLists(head1, lastNodeWillBeInserted));
	}

	public static Node insertNodeInSortedLinkedList(Node head,Node nodeToBeInserted) {
		if(head==null) {
			System.out.println("List is empty");
			return nodeToBeInserted;
		}
		else {
			Node currentNode = head;
			Node previousNode = null;
			//traverse till u find a bigger node than current one
			while(currentNode!=null && currentNode.getData() < nodeToBeInserted.getData()) {
				previousNode = currentNode;
				currentNode = currentNode.getNext();
			}

			//Now insert the new one before that bigger one
			nodeToBeInserted.setNext(currentNode);
			//if there was no node before --this is the case when the first element in the list was bigger than nodeToBeInserted
			if(previousNode==null) {
				return nodeToBeInserted;
			}
			previousNode.setNext(nodeToBeInserted);
		}
		return head;
	}
	//move ahead, reverse the previous , update head with currentNode , return previousNode
	public static Node reverseLinkedList(Node head) {
		if(head==null) {
			System.out.println("Fuck off, list is empty");
		}
		Node previousNode = null;
		Node currentNode = null;
		while(head!=null) {
			//move ahead
			currentNode = head.getNext();
			//reverse the previous
			head.setNext(previousNode);
			previousNode = head;

			//update the head.. so head will be changing in each iteration
			head = currentNode;
		}
		return previousNode;
	}
	public static Node findIntersectionOfLinkedList(Node head1,Node head2) throws Exception {
		if(head1==null) {
			throw new Exception("Fuck off, list 1 is empty");
		}
		if(head2==null) {
			throw new Exception("Fuck off, list 2 is empty");
		}
		//2 pointer approach
		Node pointer1 = head1;
		Node pointer2 = head2;
		//move them so that the shorter list reach its end
		while(pointer1!=null && pointer2!=null) {
			pointer1 = pointer1.getNext();
			pointer2 = pointer2.getNext();
		}
		//now we have position difference between 2 pointers which is difference between length of linked list.
		//let r = difference in lengths of linked lists. so now lets cover this distance r in bigger list so that
		//the 2 pointers will start with same parallel starting position
		// the bellow if and else will cover the r distance in bigger list and make both pointers equidistant from end
		if(pointer1==null) {
			pointer1 = head2;
			while(pointer2!=null) {
				pointer1 = pointer1.getNext();
				pointer2 = pointer2.getNext();
			}
			pointer2 = head1;
		}
		else{
			pointer2 = head1;
			while(pointer1!=null) {
				pointer2 = pointer2.getNext();
				pointer1 = pointer1.getNext();
			}
			pointer1 = head2;
		}
		//now the both pointers are equally distant from intersection
		while(pointer1!=pointer2) {
			pointer1 = pointer1.getNext();
			pointer2 = pointer2.getNext();
		}
		return pointer1;
	}
	public static Node findMiddleOfLinkedList(Node head) {
		//one way is to find the length of linked list and iterate half way -- 2 scans
		//doing it one scan -- two pointers approach
		Node fastPointer = head;
		Node slowPointer = head;
		while(fastPointer!=null) {
			fastPointer = fastPointer.getNext();
			if(fastPointer==null) {
				break;
			}
			slowPointer = slowPointer.getNext();
			fastPointer = fastPointer.getNext();
		}
		return slowPointer;
	}
	public static void displayLinkedListFromLast(Node head) {
		//can be done using stack but best done using recursion
		if(head==null) {
			return;
		}
		displayLinkedListFromLast(head.getNext());
		System.out.print("Node ["+head.getData()+"] ");
	}
	public static boolean isLinkedListEven(Node head) {
		//take a 2x pointer if last node is null then odd else even
		while(head!=null && head.getNext()!=null){
			head = head.getNext().getNext();
		}
		if(head==null) {
			return true;
		}
		else{
			return false;
		}
	}
	public static Node mergeTwoLists(Node nodeList1, Node nodeList2) {
		if(nodeList1 == null) return nodeList2;
		if(nodeList2 == null) return nodeList1;
		Node result = null;
		if(nodeList1.getData() <= nodeList2.getData()){
			result = nodeList1;
			result.setNext(mergeTwoLists(nodeList1.getNext(), nodeList2));
		}
		else{
			result = nodeList2;
			result.setNext(mergeTwoLists(nodeList1, nodeList2.getNext()));
		}
		return result;
	}
}
