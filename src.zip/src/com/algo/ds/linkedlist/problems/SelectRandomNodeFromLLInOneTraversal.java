package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;

import java.util.Random;

//Below is a Simple Solution
//1) Count number of nodes by traversing the list. Select a random number let ot se i
//2) Traverse the list again and return the ith node. But this approach takes 2 iterations. We can solve it in one iteration.
//The idea is to use Reservoir Sampling. Following are the steps. This is a simpler version of Reservoir Sampling as we need to select only one key instead of k keys.
public class SelectRandomNodeFromLLInOneTraversal {

    public static void main(String[] args) {
        Node n1 = pushANewNodeToGivenNode(null,7);
        n1 = pushANewNodeToGivenNode(n1,8);
        n1 = pushANewNodeToGivenNode(n1,9);
        n1 = pushANewNodeToGivenNode(n1,3);
        n1 = pushANewNodeToGivenNode(n1,6);
        n1 = pushANewNodeToGivenNode(n1,31);
        n1 = pushANewNodeToGivenNode(n1,20);
        System.out.println("Original List : "+n1);
        System.out.println("Random data : "+selectRandomNodeData(n1));
    }

    private static int selectRandomNodeData(Node node){
       if (node == null){
           return -1;
       }
       int result = node.getData();
       for (int n =2; node != null; n++){
           if (new Random().nextInt() % n ==0){
               result = node.getData();
           }
           node = node.getNext();
       }
       return result;
    }
    private static Node pushANewNodeToGivenNode(Node givenNode, int data){
        Node node = new Node(data);
        node.setNext(givenNode);
        return node;
    }
}
