package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;

//Merge sort is often preferred for sorting a linked list. The slow random-access performance of a linked list makes some other
// algorithms (such as quicksort) perform poorly, and others (such as heapsort) completely impossible.
public class MergeSortInLL {
    public static void main(String[] args) {
        Node n1 = pushANewNodeToGivenNode(null,7);
        n1 = pushANewNodeToGivenNode(n1,8);
        n1 = pushANewNodeToGivenNode(n1,9);
        n1 = pushANewNodeToGivenNode(n1,3);
        n1 = pushANewNodeToGivenNode(n1,6);
        n1 = pushANewNodeToGivenNode(n1,31);
        n1 = pushANewNodeToGivenNode(n1,20);

        System.out.println(sortList(n1));
    }

    private static Node sortList(Node n){
        if(n == null){
            return n;
        }
        if(n.getNext()== null){
            return n;
        }
        Pair<Node,Node> listPair = spiltListIntoHalf(n);
        Node firstSorted = sortList(listPair.first);
        Node secondSorted = sortList(listPair.second);
        return FunWithLinkedList.mergeTwoLists(firstSorted,secondSorted);
    }

    private static Pair<Node,Node> spiltListIntoHalf(Node n){
        if (n == null){
            return new Pair<>(null,null);
        }
        if(n.getNext()==null){
            return new Pair<>(n,null);
        }
        Node fastPtr = n;
        Node slowPtr = n;
        Node previousNode = null;
        while (fastPtr!=null){
            fastPtr = fastPtr.getNext();
            if (fastPtr == null){
                break;
            }
            fastPtr = fastPtr.getNext();
            previousNode = slowPtr;
            slowPtr = slowPtr.getNext();
        }
        previousNode.setNext(null);
        return new Pair<>(n,slowPtr);
    }
    private static Node pushANewNodeToGivenNode(Node givenNode, int data){
        Node node = new Node(data);
        node.setNext(givenNode);
        return node;
    }
    static class Pair<K,V>{
        K first;
        V second;
        Pair(K k, V v){
            this.first = k;
            this.second = v;
        }
    }
}
