package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;

import static com.algo.ds.linkedlist.basics.LinkedListUtils.getLength;
//Input:
//  First List: 5->6->3  // represents number 563
//  Second List: 8->4->2 //  represents number 842
//Output
//  Resultant list: 1->4->0->5  // represents number 1405
public class SumTwoNumberRepresentedByLL {

    static Node finalNode ;
    static int currentCarry;

    public static void main(String[] args) {
        Node n1 = pushANewNodeToGivenNode(null,7);
        n1 = pushANewNodeToGivenNode(n1,8);
        n1 = pushANewNodeToGivenNode(n1,9);
        n1 = pushANewNodeToGivenNode(n1,3);

        Node n2 = pushANewNodeToGivenNode(null,5);
        n2 = pushANewNodeToGivenNode(n2,6);
        n2 = pushANewNodeToGivenNode(n2,7);
        //n1 is 3987, n2 is 765 sum is 4752
        addNodes(n1,n2);
        System.out.println(finalNode);
    }

    private static void addNodesWithSameSize(Node node1, Node node2){
        if(node1 == null && node2 == null){
            currentCarry = 0;
            return;
        }
        addNodesWithSameSize(node1.getNext(),node2.getNext());
        int data = node1.getData() + node2.getData() + currentCarry;
        finalNode = pushANewNodeToGivenNode(finalNode,data%10);
        currentCarry = data / 10;
    }

    private static void addNodes(Node node1, Node node2){
        int l1 = getLength(node1);
        int l2 = getLength(node2);
        if(l1==l2){
            addNodesWithSameSize(node1, node2);
        }
        else{
            int diff= Math.abs(l1-l2);
            Node current = null;
            if(l1 > l2){
                current = node1;
                while (diff > 0){
                    current = current.getNext();
                    diff--;
                }
                addNodesWithSameSize(current,node2);
                propagateCarryToLeftList(node1,current);
            }
            else {
                current = node2;
                while (diff > 0){
                    current = current.getNext();
                    diff--;
                }
                addNodesWithSameSize(node1,current);
                propagateCarryToLeftList(node2,current);
            }
        }
        if(currentCarry != 0){
            finalNode = pushANewNodeToGivenNode(finalNode,currentCarry);
        }
    }

    private static void propagateCarryToLeftList(Node node, Node current) {
        if(node != current){
            propagateCarryToLeftList(node.getNext(),current);
            int data = node.getData()+ currentCarry;
            finalNode = pushANewNodeToGivenNode(finalNode,data % 10);
            currentCarry = currentCarry/10;
        }
    }

    private static Node pushANewNodeToGivenNode(Node givenNode,int data){
        Node node = new Node(data);
        node.setNext(givenNode);
        return node;
    }
}
