package com.algo.ds.linkedlist.problems;

import com.algo.ds.common.Node;
//For finding the start of the node
//S= distance traveled by slow pointer, f= distance traveled by fast pointer. m = distance between first node to start of cycle
//k = offset point in loop where they met. So S = m+p*l + k, p=no of times s moves in cycle. Similarly 
//F = m+ q*l + k. q =  no of times f moves in cycle. Now we know F = 2S. Solving the equation we get 
//m+k = (q-2p)*l and q >= 2p as speed of F = 2* speed of S. So m+k is integral multiple of l. So if f will travel m+k distance it will be
//at same position as it is now at offset. And if it travels m distance(k less than m+k), then it will be at the starting of the
//loop. And also as per definition of m, if s will travel m then it will be also at start of loop. So both will meet at start of the loop.
public class CycleInLinkedList {

	public static void main(String[] args) {
		// create a linked list in cycle
		Node head = new Node(1);
		Node node2 = new Node(2);
		Node node3 = new Node(3);
		Node node4 = new Node(4);
		Node node5 = new Node(5);
		Node node6 = new Node(6);
		Node node7 = new Node(7);
		Node node8 = new Node(8);
		Node node9 = new Node(9);
		head.setNext(node2);
		node2.setNext(node3);
		node3.setNext(node4);
		node4.setNext(node5);
		node5.setNext(node6);
		node6.setNext(node7);
		node7.setNext(node8);
		node8.setNext(node9);
		node9.setNext(node4);
		
		System.out.println("The linked list has a cycle : "+cycleExistsInLinkedList(head));
		System.out.println("The start node of loop in linked list : "+findStartOfCycleInLinkedList(head).toStringForLoopedLinkedList());
		System.out.println("The length of the loop "+getLengthOfLoopOfLinkedList(head));
	}

	//Another techniques are using brute force(n^2),Using hash map O(n) and space complexity O(n).
	//Below is flyod cycle finding algorithm
	public static boolean cycleExistsInLinkedList(Node head) {
		//2 pointers approach with different speed
		Node slowPointer = head;
		Node fastPointer = head;
		while(slowPointer!=null && fastPointer!=null) {
			fastPointer = fastPointer.getNext();
			if(fastPointer==slowPointer) {
				return true;
			}
			if(fastPointer==null) {
				return false;
			}
			fastPointer = fastPointer.getNext();
			if(fastPointer==slowPointer) {
				return true;
			}
			slowPointer = slowPointer.getNext();
		}
		return false;
	}
	public static Node findStartOfCycleInLinkedList(Node head) {
		// Not using the above method as we have to move fast pointer 2 steps always
		boolean isLoopExist = false;
		Node slowPointer = head;
		Node fastPointer = head;
		while(slowPointer!=null && fastPointer!=null) {
			fastPointer = fastPointer.getNext();
			if(fastPointer==null) {
				break;
			}
			fastPointer = fastPointer.getNext();
			slowPointer = slowPointer.getNext();
			if(fastPointer==slowPointer) {
				isLoopExist =  true;
				break;
			}
		}
		if(isLoopExist) {
			slowPointer = head;
			while(slowPointer!=fastPointer) {
				slowPointer = slowPointer.getNext();
				fastPointer = fastPointer.getNext();
			}
			return fastPointer;
		}
		else{
			System.out.println("Loop doesn't exists. Fuck off");
			return head;
		}
	}
	public static int getLengthOfLoopOfLinkedList(Node head) {
		boolean isLoopExist = false;
		Node slowPointer = head;
		Node fastPointer = head;
		while(slowPointer!=null && fastPointer!=null) {
			fastPointer = fastPointer.getNext();
			if(fastPointer==null) {
				break;
			}
			fastPointer = fastPointer.getNext();
			slowPointer = slowPointer.getNext();
			if(fastPointer==slowPointer) {
				isLoopExist =  true;
				break;
			}
		}
		if(isLoopExist) {
			int counter = 1;
			slowPointer = slowPointer.getNext();
			while(slowPointer!=fastPointer) {
				slowPointer = slowPointer.getNext();
				counter++;
			}
			return counter;
		}
		else{
			System.out.println("Loop doesn't exists. Fuck off");
			return 0;
		}
	}
}
