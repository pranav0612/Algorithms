package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.CLLNode;

public class InsertDeleteCircularLinkedList {

	public static void main(String[] args) {
		CLLNode node1 = new CLLNode(1);
		CLLNode node2 = new CLLNode(2);
		CLLNode node3 = new CLLNode(3);
		CLLNode node4 = new CLLNode(4);
		node1.setNext(node2);
		node2.setNext(node3);
		node3.setNext(node1);
		
		System.out.println(node1);
		CLLNode head = insertInBeginning(node1,node4);
		System.out.println(head);
		
		head = deleteFromBegining(head);
		System.out.println(head);
		
		head = insertAtEnd(head, node4);
		System.out.println(head);
		
		head = deleteFromEnd(head);
		System.out.println(head);
	}
	private static CLLNode insertInBeginning(CLLNode head,CLLNode nodeToBeInserted) {
		if(head==null) {
			System.out.println("List empty");
			nodeToBeInserted.setNext(nodeToBeInserted);
			return nodeToBeInserted;
		}
		System.out.println("Now inserting in beginning");
		CLLNode currentNode = head;
		while(head!=currentNode.getNext()) {
			currentNode = currentNode.getNext();
		}
		currentNode.setNext(nodeToBeInserted);
		nodeToBeInserted.setNext(head);
		return nodeToBeInserted;
	}
	private static CLLNode insertAtEnd(CLLNode head,CLLNode nodeToBeInserted) {
		System.out.println("Now inserting at end");
		if(head==null) {
			System.out.println("List empty");
			nodeToBeInserted.setNext(nodeToBeInserted);
			return nodeToBeInserted;
		}
		CLLNode currentNode = head;
		while(head!=currentNode.getNext()) {
			currentNode = currentNode.getNext();
		}
		currentNode.setNext(nodeToBeInserted);
		nodeToBeInserted.setNext(head);
		return head;
	}
	private static CLLNode deleteFromBegining(CLLNode head) {
		System.out.println("Now deleting from beginning");
		if(head==null) {
			System.out.println("List empty");
			return head;
		}
		CLLNode currentNode = head;
		while(head!=currentNode.getNext()) {
			currentNode = currentNode.getNext();
		}
		currentNode.setNext(head.getNext());
		head = null;
		return currentNode.getNext();
	}
	private static CLLNode deleteFromEnd(CLLNode head) {
		System.out.println("Now deleting from end");
		if(head==null) {
			System.out.println("List empty");
			return head;
		}
		CLLNode currentNode = head;
		int length = LinkedListUtils.getLength(head);
		int count=1;
		while(count!=length-1) {
			currentNode = currentNode.getNext();
			count++;
		}
		currentNode.setNext(head);
		return head;
	}
}
