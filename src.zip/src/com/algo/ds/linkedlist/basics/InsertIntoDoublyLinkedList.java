package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.DLLNode;

public class InsertIntoDoublyLinkedList {

	public static void main(String[] args) {
		DLLNode node1 = new DLLNode(1);
		DLLNode node2 = new DLLNode(2);
		node1.setNext(node2);
		node2.setPrevious(node1);
		DLLNode node3 = new DLLNode(3);
		System.out.println(insert(node1, node3, 3));
	}

	public static DLLNode insert(DLLNode head,DLLNode toInsert,int position) {
		if(head==null) {
			System.out.println("List is empty");
			return null;
		}
		int length = LinkedListUtils.getLength(head);
		if(position<1 || position>length+1 ) {
			System.out.println("Invalid position. Please enter position between 1 and "+length+1);
			return head;
		}
		if(position==1) {
			head.setPrevious(toInsert);
			toInsert.setNext(head);
			toInsert.setPrevious(null);
			return toInsert;
		}
		int countPosition  = 1;
		DLLNode currentNode = head;
		while(countPosition!=position-1) {
			currentNode = currentNode.getNext();
			countPosition++;
		}
		toInsert.setNext(currentNode.getNext());
		currentNode.setNext(toInsert);
		toInsert.setPrevious(currentNode);
		return head;
	}
}
