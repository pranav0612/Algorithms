package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.CLLNode;
import com.algo.ds.common.DLLNode;
import com.algo.ds.common.Node;

public class LinkedListUtils {

	public static int getLength(Node head) {
		int length = 0;
		Node temp = head;
		if(head!=null) {
			while(temp!=null) {
				length++;
				temp = temp.getNext();
			}
		}
		return length;
	}
	public static int getLength(DLLNode head) {
		int length = 0;
		DLLNode temp = head;
		if(head!=null) {
			while(temp!=null) {
				length++;
				temp = temp.getNext();
			}
		}
		return length;
	}
	public static int getLength(CLLNode head) {
		int length = 0;
		CLLNode temp = head;
		while(head!=null) {
			length++;
			temp = temp.getNext();
			if(head==temp) {
				break;
			}
		}
		return length;
	}
	public static DLLNode findMiddleOfDLL(DLLNode head) {
		//one way is to find the length of linked list and iterate half way -- 2 scans
		//doing it one scan -- two pointers approach
		DLLNode fastPointer = head;
		DLLNode slowPointer = head;
		while(fastPointer!=null) {
			fastPointer = fastPointer.getNext();
			if(fastPointer==null) {
				break;
			}
			slowPointer = slowPointer.getNext();
			fastPointer = fastPointer.getNext();
		}
		return slowPointer;
	}
	public static DLLNode createSortedDLL(){
		DLLNode head = new DLLNode(9);
		head = add(8, head);
		head = add(7, head);
		head = add(6, head);
		head = add(5, head);
		head = add(4, head);
		head = add(3, head);
		head = add(2, head);
		head = add(1, head);
		return head;
	}
	private static DLLNode add(int data,DLLNode head) {
		DLLNode n = new DLLNode(data); 
		head.setPrevious(n);
		n.setNext(head);
		return n;
	}

}
