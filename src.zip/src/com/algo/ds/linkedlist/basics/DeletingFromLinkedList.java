package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.Node;

public class DeletingFromLinkedList {

	public static void main(String[] args) {
		Node head = new Node(1);
		Node next = new Node(2);
		Node next1 = new Node(3);
		head.setNext(next);
		next.setNext(next1);
		System.out.println("Initial state of linked list : "+head);
		head = deleteFromLinkedList(head, 2);
		System.out.println("Final state of linked list : "+head);
	}
    public static Node deleteFromLinkedList(Node head,int position) {
    	int size = LinkedListUtils.getLength(head);
    	if(position>size || position < 1) {
    		System.out.println("Invalid delete postion. Please enter between 1 and "+size);
    		return head;
    	}
    	if(position==1) {
			Node currentNode = head.getNext();
			head = null;
			return currentNode;
		}
    	else{
    		int count = 1;
    		Node currentNode = head;
    		while(count!=position-1) {
    			currentNode = currentNode.getNext();
    			count++;
    		}
    		Node toBeDeleted = currentNode.getNext();
    		currentNode.setNext(toBeDeleted.getNext());
    		toBeDeleted = null;
    		return head;
    	}
    }
}
