package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.DLLNode;

public class DeleteFromDoublyLinkedList {

	public static void main(String[] args) {
		DLLNode node1 = new DLLNode(1);
		DLLNode node2 = new DLLNode(2);
		DLLNode node3 = new DLLNode(3);
		
		node1.setNext(node2);
		node2.setPrevious(node1);
		node2.setNext(node3);
		node3.setPrevious(node2);
		System.out.println(delete(node1,2));
	}

	public static DLLNode delete(DLLNode head,int position) {
		if(head==null) {
			System.out.println("List is empty");
			return head;
		}
		int length = LinkedListUtils.getLength(head);
		if(position<1 || position>length) {
			System.out.println("Invalid position. Valid range : 1 to "+length);
		}
		else {
			int count = 1;
			DLLNode currentNode = head;
			while(count!=position-1) {
				currentNode = currentNode.getNext();
				count++;
			}
			DLLNode nodeToBeDeleted = currentNode.getNext();
			currentNode.setNext(nodeToBeDeleted.getNext());
			if(nodeToBeDeleted.getNext()!=null) {
				nodeToBeDeleted.getNext().setPrevious(currentNode);
			}
			nodeToBeDeleted.setNext(null);
			nodeToBeDeleted.setPrevious(null);
			nodeToBeDeleted = null;
		}
		return head;
	}
}
