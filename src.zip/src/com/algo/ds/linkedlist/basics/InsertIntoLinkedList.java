package com.algo.ds.linkedlist.basics;

import com.algo.ds.common.Node;

public class InsertIntoLinkedList {

	//to insert in 3rd position traverse to 2 nodes and then insert
	public static void main(String[] args) {
		Node head = new Node(1);
		Node next = new Node(2);
		head.setNext(next);
		System.out.println("Initial state of linked list : "+head);
		Node toInsert = new Node(3);
		head = insert(head, toInsert,1);
		Node anotherOne = new Node(4);
		System.out.println("State of linked list : "+head);
		head = insert(head, anotherOne, 2);
		System.out.println("Final state of linked list : "+head);
	}
	public static Node insert(Node head,Node toInsert,int position) {
		if(head==null) {
			System.out.println("List empty");
			return head;
		}
		int length = LinkedListUtils.getLength(head);
		if(position<0 || position >length+1) {
			System.out.println("Invalid insert position!!");
			return head;
		}
		//inserting in the beginning
		if(position==1) {
			toInsert.setNext(head);
			return toInsert;
		}
		else{
			int count = 1;
			Node previousNode = head;
			while(count!=position-1)  {
				previousNode = previousNode.getNext();
				count++;
			}
			toInsert.setNext(previousNode.getNext());
			previousNode.setNext(toInsert);
			return head;
		}
	}
	
}
